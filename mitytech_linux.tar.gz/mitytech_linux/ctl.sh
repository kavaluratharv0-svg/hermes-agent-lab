#!/usr/bin/env bash
# ==============================================================================
# ctl.sh – Linux Terminal Control Script for MityTech Automation Engine
# ==============================================================================

set -e

export LC_ALL=C.UTF-8
export LANG=C.UTF-8
export PYTHONIOENCODING=utf-8

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

# Detect Python interpreter (virtual environment preferred)
if [ -f "$DIR/.venv/bin/python3" ]; then
    PYTHON="$DIR/.venv/bin/python3"
elif command -v python3 >/dev/null 2>&1; then
    PYTHON="python3"
else
    PYTHON="python"
fi

case "$1" in
    start)
        shift
        # Check if daemon flag or run foreground
        if [ "$1" = "-d" ] || [ "$1" = "--daemon" ]; then
            $PYTHON ctl.py start --daemon "${@:2}"
        else
            $PYTHON ctl.py start "$@"
        fi
        ;;
    stop)
        $PYTHON ctl.py stop
        ;;
    restart)
        $PYTHON ctl.py stop || true
        sleep 2
        $PYTHON ctl.py start --daemon
        ;;
    status)
        $PYTHON ctl.py status
        ;;
    workers)
        shift
        $PYTHON ctl.py workers "$@"
        ;;
    proxy)
        shift
        $PYTHON ctl.py proxy "$@"
        ;;
    urls)
        shift
        $PYTHON ctl.py urls "$@"
        ;;
    logs)
        $PYTHON ctl.py logs
        ;;
    test-proxy)
        $PYTHON ctl.py test-proxy
        ;;
    *)
        echo "=========================================================="
        echo "  MityTech Linux Terminal Control Center"
        echo "=========================================================="
        echo "Usage: ./ctl.sh [command]"
        echo ""
        echo "Commands:"
        echo "  ./ctl.sh start               – Run in terminal foreground (Ctrl+C to stop)"
        echo "  ./ctl.sh start -d            – Run non-stop in background daemon mode"
        echo "  ./ctl.sh stop                – Safely stop running background workers"
        echo "  ./ctl.sh restart             – Restart background daemon"
        echo "  ./ctl.sh status              – View live performance, workers & pass rates"
        echo "  ./ctl.sh workers [N|auto]    – Dynamically change worker count (1-200)"
        echo "  ./ctl.sh proxy [file|reload] – Switch proxy file or reload active pools"
        echo "  ./ctl.sh urls [file|reload]  – Switch or reload target URLs"
        echo "  ./ctl.sh logs                – Tail live application logs"
        echo "  ./ctl.sh test-proxy          – Concurrently test all configured proxies"
        echo "=========================================================="
        exit 1
        ;;
esac
