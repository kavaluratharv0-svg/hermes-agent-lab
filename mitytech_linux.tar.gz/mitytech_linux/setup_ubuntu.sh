#!/usr/bin/env bash
# ==============================================================================
# setup_ubuntu.sh – One-Click Automated Setup for Ubuntu / Debian VPS & Linux VMs
# ==============================================================================

set -e

echo "=========================================================================="
echo "  🚀 Installing MityTech Linux Automation Suite on Ubuntu/Debian VPS"
echo "=========================================================================="

# 1. Root check & sudo helper
SUDO=""
if [ "$EUID" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
        SUDO="sudo"
    else
        echo "⚠️ Please run as root or install sudo."
        exit 1
    fi
fi

# 2. Update repositories and install essential system libraries
echo "📦 Updating system packages & installing Chromium headless dependencies..."
$SUDO apt-get update -y
$SUDO apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    curl \
    wget \
    git \
    libnss3 \
    libnspr4 \
    libatk1.0-0 \
    libatk-bridge2.0-0 \
    libcups2 \
    libdrm2 \
    libxkbcommon0 \
    libxcomposite1 \
    libxdamage1 \
    libxfixes3 \
    libxrandr2 \
    libgbm1 \
    libpango-1.0-0 \
    libcairo2 \
    libx11-6 \
    libx11-xcb1 \
    libxcb1 \
    libxext6 \
    libxshmfence1 \
    libdbus-1-3 \
    fonts-liberation

# Handle libasound2 and libatspi across Ubuntu 20/22/24 (noble uses libasound2t64 / libatspi2.0-0)
$SUDO apt-get install -y libasound2 2>/dev/null || $SUDO apt-get install -y libasound2t64 2>/dev/null || true
$SUDO apt-get install -y libatspi2.0-0 2>/dev/null || true

# 3. Create Python Virtual Environment
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo "🐍 Setting up Python Virtual Environment in .venv..."
if [ ! -d ".venv" ]; then
    python3 -m venv .venv
fi

# 4. Activate venv & install dependencies
source .venv/bin/activate
pip install --upgrade pip
echo "📥 Installing Python requirements..."
pip install -r requirements.txt

# 5. Install Playwright Chromium headless engine and system dependencies
echo "🌐 Installing Playwright Chromium browser..."
playwright install chromium
playwright install-deps chromium || true

# 6. Set execute permissions on scripts
chmod +x ctl.sh ctl.py

# 7. Verification test
echo "🧪 Running self-test verification..."
python3 -c "
import playwright
import httpx
import psutil
from app.hardware_advisor import hardware_profile
print('  ✅ Playwright, httpx & psutil loaded successfully!')
print(f'  ✅ Hardware: {hardware_profile.spec_label}')
print(f'  ✅ Auto-Tuned Worker Capacity: {hardware_profile.optimal_workers} Workers')
"

echo "=========================================================================="
echo "  🎉 SETUP COMPLETE! Ready for 24/7 Linux VPS Operation"
echo "=========================================================================="
echo ""
echo "Quick Commands:"
echo "  • Run in foreground : ./ctl.sh start"
echo "  • Run 24/7 in background: ./ctl.sh start -d"
echo "  • Check live status : ./ctl.sh status"
echo "  • Set worker count  : ./ctl.sh workers 40"
echo "  • Safely stop       : ./ctl.sh stop"
echo "  • View live logs    : ./ctl.sh logs"
echo "  • Web Dashboard     : http://<your-vps-ip>:8765/"
echo "=========================================================================="
