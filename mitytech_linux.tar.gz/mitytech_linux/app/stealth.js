// stealth.js – Injected into each page before scripts execute
// Standardizes properties to prevent automation flags and prototype tampering penalties.

(() => {
  // Hide automation webdriver flag
  try {
    const newProto = Object.getPrototypeOf(navigator);
    delete newProto.webdriver;
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined,
      configurable: true,
    });
  } catch (e) {}

  // Ensure chrome runtime object isn't completely undefined if spoofing Chromium
  if (!window.chrome) {
    window.chrome = {
      runtime: {},
      loadTimes: function() {},
      csi: function() {},
      app: {},
    };
  }

  // Consistent hardwareConcurrency reporting (e.g., 4, 8, 12, 16)
  if (!navigator.hardwareConcurrency || navigator.hardwareConcurrency < 2) {
    Object.defineProperty(navigator, 'hardwareConcurrency', {
      get: () => 8,
      configurable: true,
    });
  }

  // Consistent deviceMemory
  if (!navigator.deviceMemory) {
    Object.defineProperty(navigator, 'deviceMemory', {
      get: () => 8,
      configurable: true,
    });
  }
})();
