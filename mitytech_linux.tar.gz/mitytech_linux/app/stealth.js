// stealth.js – Enterprise Anti-Detection & Fingerprint Shield for Headless Chromium
// Injected into every page & frame at Document Start before any remote scripts run.

(() => {
  'use strict';

  // 1. Hide automation webdriver flag
  try {
    const navProto = Object.getPrototypeOf(navigator);
    delete navProto.webdriver;
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined,
      configurable: true,
      enumerable: false,
    });
  } catch (e) {}

  // 2. Realistic window.chrome object
  try {
    if (!window.chrome) {
      window.chrome = {};
    }
    if (!window.chrome.runtime) {
      window.chrome.runtime = {
        OnInstalledReason: { INSTALL: "install", UPDATE: "update", CHROME_UPDATE: "chrome_update", SHARED_MODULE_UPDATE: "shared_module_update" },
        OnRestartRequiredReason: { APP_UPDATE: "app_update", OS_UPDATE: "os_update", PERIODIC: "periodic" },
        PlatformArch: { ARM: "arm", ARM64: "arm64", MIPS: "mips", MIPS64: "mips64", X86_32: "x86-32", X86_64: "x86-64" },
        PlatformNaclArch: { ARM: "arm", MIPS: "mips", MIPS64: "mips64", X86_32: "x86-32", X86_64: "x86-64" },
        PlatformOs: { ANDROID: "android", CROS: "cros", LINUX: "linux", MAC: "mac", OPENBSD: "openbsd", WIN: "win" },
        RequestUpdateCheckStatus: { THROTTLED: "throttled", NO_UPDATE: "no_update", UPDATE_AVAILABLE: "update_available" },
        connect: function() { throw new TypeError("Error in invocation of runtime.connect"); },
        sendMessage: function() { throw new TypeError("Error in invocation of runtime.sendMessage"); }
      };
    }
    if (!window.chrome.loadTimes) {
      window.chrome.loadTimes = function() {
        return {
          requestTime: performance.now() / 1000,
          startLoadTime: performance.now() / 1000,
          commitLoadTime: performance.now() / 1000,
          finishDocumentLoadTime: performance.now() / 1000,
          finishLoadTime: performance.now() / 1000,
          firstPaintTime: performance.now() / 1000,
          firstPaintAfterLoadTime: 0,
          navigationType: "Other"
        };
      };
    }
    if (!window.chrome.csi) {
      window.chrome.csi = function() {
        return {
          startE: Date.now(),
          onloadT: Date.now() + 200,
          pageT: 250,
          tran: 15
        };
      };
    }
  } catch (e) {}

  // 3. Realistic navigator.plugins & mimeTypes (never empty)
  try {
    if (!navigator.plugins || navigator.plugins.length === 0) {
      const mockPlugins = [
        { name: "PDF Viewer", filename: "internal-pdf-viewer", description: "Portable Document Format" },
        { name: "Chrome PDF Viewer", filename: "internal-pdf-viewer", description: "Portable Document Format" },
        { name: "Chromium PDF Viewer", filename: "internal-pdf-viewer", description: "Portable Document Format" },
        { name: "Microsoft Edge PDF Viewer", filename: "internal-pdf-viewer", description: "Portable Document Format" },
        { name: "WebKit built-in PDF", filename: "internal-pdf-viewer", description: "Portable Document Format" }
      ];

      const pluginArray = Object.create(PluginArray.prototype);
      mockPlugins.forEach((p, idx) => {
        const plugin = Object.create(Plugin.prototype);
        Object.defineProperties(plugin, {
          name: { value: p.name, enumerable: true },
          filename: { value: p.filename, enumerable: true },
          description: { value: p.description, enumerable: true },
          length: { value: 0, enumerable: true }
        });
        pluginArray[idx] = plugin;
        pluginArray[p.name] = plugin;
      });
      Object.defineProperty(pluginArray, 'length', { value: mockPlugins.length, enumerable: true });

      Object.defineProperty(navigator, 'plugins', {
        get: () => pluginArray,
        enumerable: true,
        configurable: true
      });
    }
  } catch (e) {}

  // 4. Permissions API Spoofing (Notifications)
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const originalQuery = navigator.permissions.query;
      navigator.permissions.query = (parameters) => (
        parameters.name === 'notifications' ?
          Promise.resolve({ state: Notification.permission === 'granted' ? 'granted' : 'prompt', onchange: null }) :
          originalQuery(parameters)
      );
    }
  } catch (e) {}

  // 5. Hardware Concurrency & Device Memory
  try {
    if (!navigator.hardwareConcurrency || navigator.hardwareConcurrency < 4) {
      Object.defineProperty(navigator, 'hardwareConcurrency', {
        get: () => 8,
        configurable: true,
        enumerable: true
      });
    }
    if (!navigator.deviceMemory || navigator.deviceMemory < 4) {
      Object.defineProperty(navigator, 'deviceMemory', {
        get: () => 8,
        configurable: true,
        enumerable: true
      });
    }
  } catch (e) {}

  // 6. WebGL SwiftShader / llvmpipe Masking
  try {
    const getParameterProto = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(parameter) {
      // UNMASKED_VENDOR_WEBGL
      if (parameter === 37445) {
        return 'Qualcomm';
      }
      // UNMASKED_RENDERER_WEBGL
      if (parameter === 37446) {
        return 'Adreno (TM) 730';
      }
      return getParameterProto.apply(this, [parameter]);
    };

    if (typeof WebGL2RenderingContext !== 'undefined') {
      const getParameterProto2 = WebGL2RenderingContext.prototype.getParameter;
      WebGL2RenderingContext.prototype.getParameter = function(parameter) {
        if (parameter === 37445) {
          return 'Qualcomm';
        }
        if (parameter === 37446) {
          return 'Adreno (TM) 730';
        }
        return getParameterProto2.apply(this, [parameter]);
      };
    }
  } catch (e) {}

  // 7. Prevent iframe contentWindow detection leaks
  try {
    const originalAppendChild = Node.prototype.appendChild;
    Node.prototype.appendChild = function(child) {
      const res = originalAppendChild.apply(this, arguments);
      if (child && child.tagName === 'IFRAME') {
        try {
          if (child.contentWindow && !child.contentWindow.chrome) {
            child.contentWindow.chrome = window.chrome;
          }
        } catch (e) {}
      }
      return res;
    };
  } catch (e) {}

})();
