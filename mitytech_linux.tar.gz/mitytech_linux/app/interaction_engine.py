"""
interaction_engine.py – Deep human-behaviour simulation for ad impression quality.

Goals:
  • Every session looks like a real person reading content
  • Ads get enough dwell time (>30s on page) to register as valid impressions
  • 6 unique scroll personalities, mouse movement, hover, reading pauses
  • Opens internal articles, reads them, goes back — full engagement loop
  • Zero bot-like patterns: no fixed timing, no machine-regular intervals
  • Session active time: 60–180 seconds of real on-page behaviour
"""

from __future__ import annotations

import logging
import random
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from playwright.sync_api import Page, TimeoutError as PWTimeout

from app.config import InteractionConfig, config
from app.logger import EventType, SessionLogger

log = logging.getLogger("qa_tester.interaction")


# ---------------------------------------------------------------------------
# Micro-timing helpers  (all sub-functions use these — never fixed sleeps)
# ---------------------------------------------------------------------------

def _rng_seed() -> float:
    return time.time_ns() ^ random.getrandbits(64)


def _ms(lo: int, hi: int) -> float:
    """Gaussian-jittered millisecond value in [lo, hi]."""
    mid = (lo + hi) / 2
    sigma = (hi - lo) / 6
    return max(lo, min(hi, random.gauss(mid, sigma)))


def _sleep_ms(lo: int, hi: int) -> None:
    time.sleep(_ms(lo, hi) / 1000.0)


def _sleep_s(lo: float, hi: float) -> None:
    time.sleep(random.uniform(lo, hi))


def _reading_pause() -> None:
    """Pause like a real person reading — 1.5 to 8 seconds with Gaussian shape."""
    time.sleep(max(1.0, random.gauss(3.5, 1.8)))


def _glance_pause() -> None:
    """Quick glance before scrolling — 0.3 to 1.5 seconds."""
    _sleep_ms(300, 1500)


# ---------------------------------------------------------------------------
@dataclass
class InteractionResult:
    action: str
    success: bool
    detail: str = ""
    elapsed_ms: float = 0.0


# ---------------------------------------------------------------------------
class InteractionEngine:
    """
    Simulates a real human reader:

    Scroll personalities (chosen per session):
      1. natural     – steady reading scroll with random pauses
      2. reader      – slow chunk-by-chunk with long reading stops
      3. skimmer     – fast scan then slow careful read
      4. back_forth  – jumps between sections like comparing content
      5. bottom_back – goes to bottom to judge article length, back up to read
      6. idle_burst  – reads above-fold, bursts down, reads again

    Navigation:
      • 60–80% chance to open 1–3 internal articles
      • Spends 20–90s on each article (real reading time)
      • Scrolls each article like a new personality
      • Goes back to home naturally

    Ad impression quality:
      • Always spends ≥45s on landing page before any navigation
      • Each article visit adds another 20–90s impression window
      • Total session: 60–180 seconds active on-page time
    """

    def __init__(
        self,
        page: Page,
        session_logger: SessionLogger,
        cfg: Optional[InteractionConfig] = None,
    ) -> None:
        random.seed(_rng_seed())
        self._page = page
        self._log = session_logger
        self._cfg = cfg or config.interaction
        self._results: List[InteractionResult] = []
        self._vw: int = 1200
        self._vh: int = 800
        self._refresh_viewport()

    # ------------------------------------------------------------------
    # Viewport / page geometry
    # ------------------------------------------------------------------

    def _refresh_viewport(self) -> None:
        try:
            self._vw = self._page.evaluate("window.innerWidth") or 1200
            self._vh = self._page.evaluate("window.innerHeight") or 800
        except Exception:
            pass

    def _page_height(self) -> int:
        try:
            return self._page.evaluate("document.body.scrollHeight") or 2000
        except Exception:
            return 2000

    def _scroll_top(self) -> int:
        try:
            return self._page.evaluate("window.scrollY") or 0
        except Exception:
            return 0

    # ------------------------------------------------------------------
    # Mouse — bezier-style multi-step moves
    # ------------------------------------------------------------------

    def _move_mouse(self, x: Optional[int] = None, y: Optional[int] = None) -> None:
        """Move mouse to (x, y) or random point via multi-step bezier path."""
        try:
            tx = x if x is not None else random.randint(60, max(61, self._vw - 60))
            ty = y if y is not None else random.randint(60, max(61, self._vh - 60))
            steps = random.randint(8, 25)   # more steps = more human-like curve
            self._page.mouse.move(tx, ty, steps=steps)
            _sleep_ms(40, 180)
        except Exception:
            pass

    def _mouse_drift(self) -> None:
        """Small idle drift — mouse moves slightly like a real user thinking."""
        try:
            cx = self._page.evaluate("window.innerWidth / 2") or 600
            cy = self._page.evaluate("window.innerHeight / 2") or 400
            for _ in range(random.randint(2, 5)):
                dx = random.randint(-120, 120)
                dy = random.randint(-80, 80)
                self._page.mouse.move(
                    max(10, min(self._vw - 10, int(cx + dx))),
                    max(10, min(self._vh - 10, int(cy + dy))),
                    steps=random.randint(5, 15),
                )
                _sleep_ms(100, 500)
        except Exception:
            pass

    def _hover_text_element(self) -> None:
        """Hover over a visible text element safely using bounding box coordinates."""
        try:
            selectors = ["p", "h2", "h3", "li", "span", "article", "h1"]
            random.shuffle(selectors)
            for sel in selectors[:3]:
                elements = self._page.query_selector_all(sel)
                if not elements:
                    continue
                elem = random.choice(elements[:15])
                try:
                    box = elem.bounding_box(timeout=1000)
                    if box and box["width"] > 0 and box["height"] > 0:
                        # Move mouse smoothly to element center
                        tx = int(box["x"] + box["width"] / 2)
                        ty = int(box["y"] + box["height"] / 2)
                        # Keep inside viewport
                        tx = max(10, min(self._vw - 10, tx))
                        ty = max(10, min(self._vh - 10, ty))
                        self._page.mouse.move(tx, ty, steps=random.randint(5, 12))
                        _sleep_ms(300, 1200)
                        return
                except Exception:
                    continue
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Scroll primitives
    # ------------------------------------------------------------------

    def _scroll_by(self, px: int, smooth: bool = True) -> None:
        behavior = "smooth" if smooth else "auto"
        try:
            self._page.evaluate(
                f"window.scrollBy({{top: {px}, left: 0, behavior: '{behavior}'}});"
            )
        except Exception:
            pass

    def _scroll_to(self, px: int, smooth: bool = True) -> None:
        behavior = "smooth" if smooth else "auto"
        try:
            self._page.evaluate(
                f"window.scrollTo({{top: {px}, left: 0, behavior: '{behavior}'}});"
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 6 scroll personalities
    # ------------------------------------------------------------------

    def _scroll_natural(self) -> None:
        """Steady reader — consistent but not robotic. Most common pattern."""
        total_h = self._page_height()
        steps = random.randint(6, 18)
        for i in range(steps):
            px = random.randint(80, 500)
            self._scroll_by(px)
            # Occasional micro-reverse (re-read something)
            if random.random() < 0.15:
                _sleep_ms(300, 800)
                self._scroll_by(-random.randint(30, 150))
            pause = int(random.gauss(1100, 450))
            _sleep_ms(max(300, pause - 300), max(400, pause + 600))
            # Mouse drifts while reading
            if random.random() < 0.25:
                self._mouse_drift()
            if random.random() < 0.20:
                self._hover_text_element()
            # Don't scroll past bottom
            if self._scroll_top() + self._vh >= total_h - 50:
                break

    def _scroll_reader(self) -> None:
        """Slow methodical reader — goes one viewport chunk at a time."""
        vh = self._vh
        total_h = self._page_height()
        pos = self._scroll_top()
        chunks = random.randint(4, 12)
        step = max(int(vh * random.uniform(0.55, 0.85)), 120)

        for _ in range(chunks):
            self._scroll_to(pos + step, smooth=True)
            pos = min(pos + step, total_h - vh)
            _reading_pause()                 # long pause — actually reading
            self._hover_text_element()
            self._mouse_drift()
            # Micro scroll back (re-read)
            if random.random() < 0.25:
                self._scroll_by(-random.randint(40, 130))
                _sleep_ms(800, 2200)
            if pos >= total_h - vh - 50:
                break

    def _scroll_skimmer(self) -> None:
        """Fast initial scan, stops at something interesting, then reads carefully."""
        total_h = self._page_height()
        # Fast scan down
        fast_steps = random.randint(3, 7)
        for _ in range(fast_steps):
            self._scroll_by(random.randint(350, 800))
            _sleep_ms(80, 280)
        # "Found something interesting" — long stop
        _sleep_s(2.5, 7.0)
        self._hover_text_element()
        self._mouse_drift()
        # Slow careful read from here
        slow_steps = random.randint(3, 7)
        for _ in range(slow_steps):
            if self._scroll_top() + self._vh >= total_h - 50:
                break
            self._scroll_by(random.randint(80, 280))
            _sleep_ms(700, 2500)
            if random.random() < 0.30:
                self._hover_text_element()

    def _scroll_back_forth(self) -> None:
        """Jumps between sections — comparing content, cross-referencing."""
        total_h = self._page_height()
        num = random.randint(3, 6)
        anchors = sorted([random.randint(0, total_h) for _ in range(num)])

        for pos in anchors:
            self._scroll_to(pos, smooth=True)
            _sleep_ms(900, 3500)
            self._hover_text_element()
            if random.random() < 0.35:
                self._mouse_drift()

        # Return up to compare with earlier section
        back_to = random.choice(anchors[:max(1, len(anchors) // 2)])
        self._scroll_to(back_to, smooth=True)
        _sleep_ms(1000, 3000)

    def _scroll_to_bottom_and_back(self) -> None:
        """Checks article length first (scroll to bottom), then reads properly."""
        total_h = self._page_height()
        # Quickly scroll to see how long the page is
        quick_steps = random.randint(4, 8)
        for _ in range(quick_steps):
            self._scroll_by(total_h // quick_steps + random.randint(-80, 80))
            _sleep_ms(150, 450)
        # Pause at bottom
        _sleep_ms(1200, 3500)
        self._mouse_drift()
        # Scroll back to start reading properly from ~30% down
        read_start = int(total_h * random.uniform(0.05, 0.30))
        self._scroll_to(read_start, smooth=True)
        _sleep_ms(800, 2000)
        # Now do a natural read from there
        for _ in range(random.randint(3, 8)):
            self._scroll_by(random.randint(100, 380))
            _sleep_ms(900, 3200)
            if random.random() < 0.25:
                self._hover_text_element()
            if self._scroll_top() + self._vh >= total_h - 50:
                break

    def _scroll_idle_burst(self) -> None:
        """Reads above-fold content, bursts down, then slows to read more."""
        # Long initial read of above-fold content
        _sleep_s(3.0, 9.0)
        self._hover_text_element()
        self._mouse_drift()
        # Fast burst down the page
        burst = random.randint(4, 9)
        for _ in range(burst):
            self._scroll_by(random.randint(250, 650))
            _sleep_ms(60, 220)
        # Found something — slow read again
        _sleep_s(2.0, 6.0)
        self._hover_text_element()
        slow_steps = random.randint(2, 6)
        for _ in range(slow_steps):
            self._scroll_by(random.randint(80, 260))
            _sleep_ms(600, 2200)

    def _run_scroll(self, force: Optional[str] = None) -> InteractionResult:
        """Pick and run one scroll strategy. Optionally force a named one."""
        strategies = [
            ("natural_scroll",      self._scroll_natural,           0.30),
            ("reader_scroll",       self._scroll_reader,            0.22),
            ("skimmer_scroll",      self._scroll_skimmer,           0.18),
            ("back_forth_scroll",   self._scroll_back_forth,        0.12),
            ("bottom_back_scroll",  self._scroll_to_bottom_and_back, 0.10),
            ("idle_burst_scroll",   self._scroll_idle_burst,        0.08),
        ]
        if force:
            match = next((s for s in strategies if s[0] == force), None)
            name, fn = (match[0], match[1]) if match else (strategies[0][0], strategies[0][1])
        else:
            names   = [s[0] for s in strategies]
            fns     = [s[1] for s in strategies]
            weights = [s[2] for s in strategies]
            idx = random.choices(range(len(strategies)), weights=weights, k=1)[0]
            name, fn = names[idx], fns[idx]

        t0 = time.time()
        try:
            fn()
            elapsed = (time.time() - t0) * 1000
            self._log.record(EventType.SCROLL, {
                "strategy": name,
                "elapsed_ms": round(elapsed, 1),
                "scroll_position": self._scroll_top(),
            })
            log.info("[%s] 📜 Scroll: %s (%.1fs)", self._log.session_id[:8], name, elapsed / 1000)
            return InteractionResult(name, True, name, elapsed)
        except Exception as exc:
            return InteractionResult(name, False, str(exc))

    # ------------------------------------------------------------------
    # Navigation — internal link browsing
    # ------------------------------------------------------------------

    def _get_internal_links(self) -> List[str]:
        """Find true internal content links on the current page."""
        try:
            from urllib.parse import urlparse
            current_host = urlparse(self._page.url).netloc.lower()
            raw = self._page.evaluate("""
                () => Array.from(document.querySelectorAll('a[href]'))
                    .map(a => a.href)
                    .filter(h => h && !h.includes('#') && !h.startsWith('javascript'))
            """)
            links = []
            for href in raw:
                if not isinstance(href, str) or not href.startswith("http"):
                    continue
                parsed = urlparse(href)
                # MUST match current domain exactly to avoid navigating to external ad trackers
                if parsed.netloc.lower() != current_host:
                    continue
                # Skip obvious non-content links
                skip = ["mailto:", "tel:", ".pdf", ".zip", ".jpg", ".png",
                        "logout", "login", "signin", "register", "cart", "wp-login"]
                if any(s in href.lower() for s in skip):
                    continue
                links.append(href)
            return list(set(links))
        except Exception:
            return []

    def _click_link_naturally(self, url: str) -> InteractionResult:
        """Navigate to a link — move mouse to it first if possible, then go."""
        t0 = time.time()
        try:
            _referrer = config.traffic.get_referrer() or "https://l.facebook.com/"
            # Try to find and click the actual element (more human)
            try:
                anchor = self._page.query_selector(f'a[href="{url}"]')
                if anchor and anchor.is_visible():
                    anchor.scroll_into_view_if_needed(timeout=3000)
                    _sleep_ms(300, 900)
                    anchor.hover(timeout=2000)
                    _sleep_ms(200, 700)
                    self._page.goto(url, wait_until="domcontentloaded", timeout=45_000, referrer=_referrer)
                else:
                    raise Exception("Element not directly clickable")
            except Exception:
                self._page.goto(url, wait_until="domcontentloaded", timeout=45_000, referrer=_referrer)

            elapsed = (time.time() - t0) * 1000
            self._log.record(EventType.NAVIGATE, {
                "action": "open_article",
                "url": url,
                "elapsed_ms": round(elapsed, 1),
            })
            log.info("[%s] 🔗 Opened: %s", self._log.session_id[:8], url[:80])
            return InteractionResult("open_article", True, url, elapsed)
        except PWTimeout:
            return InteractionResult("open_article", False, "timeout")
        except Exception as exc:
            return InteractionResult("open_article", False, str(exc))

    def _go_back(self) -> InteractionResult:
        """Go back — with a natural pause before doing so."""
        _sleep_ms(500, 2500)    # pause before clicking back
        t0 = time.time()
        try:
            self._page.go_back(wait_until="domcontentloaded", timeout=30_000)
            _sleep_ms(600, 1800)   # re-orientation pause after back
            self._scroll_to(0)     # scroll to top after returning
            _sleep_ms(400, 1000)
            elapsed = (time.time() - t0) * 1000
            self._log.record(EventType.NAVIGATE, {
                "action": "go_back",
                "url": self._page.url,
            })
            return InteractionResult("go_back", True, self._page.url, elapsed)
        except Exception as exc:
            return InteractionResult("go_back", False, str(exc))

    # ------------------------------------------------------------------
    # Article visit — full reading simulation
    # ------------------------------------------------------------------

    def _read_article(self, url: str) -> List[InteractionResult]:
        """
        Full article reading cycle:
          1. Navigate to article
          2. Initial glance pause (above-fold loading impression)
          3. Read-scroll the article (20–90 seconds)
          4. Mouse drift + hover during reading
          5. Go back to home
        """
        results: List[InteractionResult] = []
        self._refresh_viewport()

        nav = self._click_link_naturally(url)
        results.append(nav)
        if not nav.success:
            return results

        # Above-fold impression window — ads load here
        above_fold_dwell = random.uniform(4.0, 12.0)
        log.info("[%s] 👁  Above-fold dwell: %.1fs", self._log.session_id[:8], above_fold_dwell)
        time.sleep(above_fold_dwell)
        self._move_mouse()
        self._hover_text_element()

        # Read the article with scroll
        results.append(self._run_scroll())

        # Mid-article pause (ads have fully loaded and been viewed)
        mid_pause = random.uniform(5.0, 20.0)
        log.info("[%s] 📖 Mid-article read: %.1fs", self._log.session_id[:8], mid_pause)
        time.sleep(mid_pause)
        self._mouse_drift()
        self._hover_text_element()

        # Maybe scroll a second time (long articles)
        if random.random() < 0.55:
            results.append(self._run_scroll())
            _sleep_s(3.0, 10.0)

        # Go back to home
        results.append(self._go_back())
        return results

    # ------------------------------------------------------------------
    # Main sequence — full human session
    # ------------------------------------------------------------------

    def run_qa_sequence(self) -> List[InteractionResult]:
        """
        Execute a complete human-like browsing session:

        Phase 1 – Landing page impression (45–90s)
          • Page loads, user orients themselves
          • Scroll homepage content
          • Ads get a long view window

        Phase 2 – Article browsing (optional, 60% of sessions)
          • Open 1–3 articles
          • Read each for 20–90 seconds
          • Go back between each

        Phase 3 – Final dwell (10–30s)
          • User lingers before leaving
          • Final scroll and mouse movement

        Total session: 60–180 seconds active on-page time
        """
        results: List[InteractionResult] = []
        self._refresh_viewport()
        session_start = time.monotonic()

        def elapsed() -> float:
            return time.monotonic() - session_start

        log.info("[%s] 🧠 Starting human behaviour sequence", self._log.session_id[:8])

        # ── Phase 1: Landing page impression ─────────────────────────
        # Initial orientation — user arrived, looking at the page
        _sleep_ms(800, 2500)
        self._move_mouse()
        _glance_pause()

        # First scroll — always happens
        results.append(self._run_scroll())

        # Landing page dwell (ads above and in-view get impression time)
        landing_dwell = random.uniform(15.0, 45.0)
        log.info("[%s] 🏠 Landing dwell: %.1fs", self._log.session_id[:8], landing_dwell)
        dwell_start = time.monotonic()
        while time.monotonic() - dwell_start < landing_dwell:
            remaining = landing_dwell - (time.monotonic() - dwell_start)
            if remaining < 2.0:
                break
            action = random.choices(
                ["mouse_drift", "hover", "micro_scroll", "idle"],
                weights=[0.25, 0.30, 0.25, 0.20], k=1
            )[0]
            if action == "mouse_drift":
                self._mouse_drift()
            elif action == "hover":
                self._hover_text_element()
            elif action == "micro_scroll":
                self._scroll_by(random.randint(50, 200))
                _sleep_ms(500, 1800)
                if random.random() < 0.4:
                    self._scroll_by(-random.randint(20, 100))
            else:
                _sleep_s(1.5, 4.0)

        # Second homepage scroll (user decides to read more)
        if random.random() < 0.70:
            results.append(self._run_scroll())
            _sleep_s(3.0, 12.0)
            self._mouse_drift()

        log.info("[%s] ⏱  Phase 1 done (%.1fs elapsed)", self._log.session_id[:8], elapsed())

        # ── Phase 2: Article reading (60% of sessions) ────────────────
        article_prob = float(self._cfg.open_article_probability)
        if random.random() < article_prob:
            max_articles = random.randint(1, 3)
            articles_read = 0

            for hop in range(max_articles):
                links = self._get_internal_links()
                if not links:
                    log.info("[%s] No internal links found", self._log.session_id[:8])
                    break

                chosen = random.choice(links)
                log.info("[%s] 📰 Article %d/%d: %s", self._log.session_id[:8],
                         hop + 1, max_articles, chosen[:70])

                article_results = self._read_article(chosen)
                results.extend(article_results)
                articles_read += 1

                # Re-orient on homepage after back
                _sleep_s(2.0, 6.0)
                self._hover_text_element()

                # Stop if session is getting long (>150s)
                if elapsed() > 150.0:
                    break

                # Inter-article pause — deciding what to read next
                if hop < max_articles - 1:
                    _sleep_s(3.0, 10.0)
                    self._mouse_drift()

            log.info("[%s] 📚 Read %d articles (%.1fs elapsed)", self._log.session_id[:8],
                     articles_read, elapsed())

        # ── Phase 3: Final dwell — user about to leave ────────────────
        # Still on page — final lingering behaviour
        final_dwell = random.uniform(8.0, 25.0)
        log.info("[%s] 🔚 Final dwell: %.1fs", self._log.session_id[:8], final_dwell)
        final_start = time.monotonic()
        while time.monotonic() - final_start < final_dwell:
            remaining = final_dwell - (time.monotonic() - final_start)
            if remaining < 1.5:
                break
            choice = random.choices(
                ["scroll", "hover", "drift", "idle"],
                weights=[0.25, 0.30, 0.25, 0.20], k=1
            )[0]
            if choice == "scroll":
                self._scroll_by(random.choice([-1, 1]) * random.randint(60, 300))
                _sleep_ms(600, 2000)
            elif choice == "hover":
                self._hover_text_element()
            elif choice == "drift":
                self._mouse_drift()
            else:
                _sleep_s(1.0, 3.5)

        # Final mouse park — user moves to close tab
        self._move_mouse(
            random.randint(self._vw - 200, self._vw - 20),
            random.randint(0, 30),
        )
        _sleep_ms(200, 600)

        total_time = elapsed()
        log.info(
            "[%s] ✅ Human sequence complete | %.1fs total | %d actions",
            self._log.session_id[:8], total_time, len(results)
        )
        self._results = results
        return results

    def _take_screenshot(self, label: str) -> None:
        """Save a screenshot if screenshots are enabled."""
        if not config.screenshots_enabled:
            return
        try:
            out = config.REPORTS_DIR / "screenshots" / f"{self._log.session_id[:8]}_{label}.png"
            out.parent.mkdir(parents=True, exist_ok=True)
            self._page.screenshot(path=str(out), full_page=True)
            log.info("[%s] 📸 Screenshot saved: %s", self._log.session_id[:8], out)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Adx mode: ad impression → 2-4 articles → final dwell
    # ------------------------------------------------------------------

    def run_adx_sequence(self, base_url: str = "https://monutech.in/article/") -> List[InteractionResult]:
        """
        Adx browsing flow:
          Phase 1 – Landing ad impression wait (30–45s)
            • Ads load and register impressions above-fold
            • Full page dwell with human behavior

          Phase 2 – Article browsing (2–4 articles)
            • Navigate to base_url + random article numbers
            • Read each article 20–60s with scroll, hover, drift
            • Go back between articles

          Phase 3 – Final dwell (10–25s)
            • User lingers before leaving
            • Final scroll and mouse movement

        Total session: 90–200 seconds active on-page time
        """
        results: List[InteractionResult] = []
        self._refresh_viewport()
        session_start = time.monotonic()
        max_articles = random.randint(2, self._cfg.max_articles_adx)

        def elapsed() -> float:
            return time.monotonic() - session_start

        log.info("[%s] 🧠 Starting adx behaviour sequence (%d articles)", self._log.session_id[:8], max_articles)

        # ── Phase 1: Ad impression dwell (30–45s) ────────────────
        _sleep_ms(800, 2500)
        self._move_mouse()
        _glance_pause()
        results.append(self._run_scroll())

        ad_dwell = random.uniform(30.0, 45.0)
        log.info("[%s] 📺 Ad impression dwell: %.1fs", self._log.session_id[:8], ad_dwell)
        dwell_start = time.monotonic()
        while time.monotonic() - dwell_start < ad_dwell:
            remaining = ad_dwell - (time.monotonic() - dwell_start)
            if remaining < 2.0:
                break
            action = random.choices(
                ["mouse_drift", "hover", "micro_scroll", "idle"],
                weights=[0.25, 0.30, 0.25, 0.20], k=1
            )[0]
            if action == "mouse_drift":
                self._mouse_drift()
            elif action == "hover":
                self._hover_text_element()
            elif action == "micro_scroll":
                self._scroll_by(random.randint(50, 200))
                _sleep_ms(500, 1800)
                if random.random() < 0.4:
                    self._scroll_by(-random.randint(20, 100))
            else:
                _sleep_s(1.5, 4.0)

        if random.random() < 0.70:
            results.append(self._run_scroll())
            _sleep_s(3.0, 12.0)
            self._mouse_drift()

        log.info("[%s] ⏱  Phase 1 done (%.1fs elapsed)", self._log.session_id[:8], elapsed())
        self._take_screenshot("landing")

        # ── Phase 2: Article browsing (2–4 articles) ──────────
        for hop in range(max_articles):
            article_num = random.randint(1, 20)
            article_url = f"{base_url}p{article_num}.php"
            log.info("[%s] 📰 Article %d/%d: %s", self._log.session_id[:8],
                     hop + 1, max_articles, article_url)

            article_results = self._read_article(article_url)
            results.extend(article_results)
            self._take_screenshot(f"article_{hop + 1}")

            # Re-orient on homepage after back
            _sleep_s(2.0, 6.0)
            self._hover_text_element()

            # Stop if session is getting long (>180s)
            if elapsed() > 180.0:
                break

            # Inter-article pause
            if hop < max_articles - 1:
                _sleep_s(3.0, 10.0)
                self._mouse_drift()

        log.info("[%s] 📚 Read %d articles (%.1fs elapsed)", self._log.session_id[:8],
                 len([r for r in results if r.action == "open_article"]), elapsed())

        # ── Phase 3: Final dwell ──────────────────────────────────
        final_dwell = random.uniform(8.0, 25.0)
        log.info("[%s] 🔚 Final dwell: %.1fs", self._log.session_id[:8], final_dwell)
        final_start = time.monotonic()
        while time.monotonic() - final_start < final_dwell:
            remaining = final_dwell - (time.monotonic() - final_start)
            if remaining < 1.5:
                break
            choice = random.choices(
                ["scroll", "hover", "drift", "idle"],
                weights=[0.25, 0.30, 0.25, 0.20], k=1
            )[0]
            if choice == "scroll":
                self._scroll_by(random.choice([-1, 1]) * random.randint(60, 300))
                _sleep_ms(600, 2000)
            elif choice == "hover":
                self._hover_text_element()
            elif choice == "drift":
                self._mouse_drift()
            else:
                _sleep_s(1.0, 3.5)

        self._move_mouse(
            random.randint(self._vw - 200, self._vw - 20),
            random.randint(0, 30),
        )
        _sleep_ms(200, 600)

        total_time = elapsed()
        self._take_screenshot("final")
        log.info(
            "[%s] ✅ Adx sequence complete | %.1fs total | %d actions",
            self._log.session_id[:8], total_time, len(results)
        )
        self._results = results
        return results

    @property
    def summary(self) -> dict:
        total = len(self._results)
        passed = sum(1 for r in self._results if r.success)
        return {
            "total_actions": total,
            "passed": passed,
            "failed": total - passed,
            "actions": [
                {
                    "action": r.action,
                    "success": r.success,
                    "detail": r.detail[:200] if r.detail else "",
                    "elapsed_ms": round(r.elapsed_ms, 1),
                }
                for r in self._results
            ],
        }
