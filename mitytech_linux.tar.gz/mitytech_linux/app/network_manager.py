"""
network_manager.py – ADB-based mobile network/airplane mode cycling.

Used for testing site performance and behavior across dynamic mobile IP connections.
"""

from __future__ import annotations

import logging
import subprocess
import time
from typing import List, Optional

import httpx

from app.config import ADBConfig, config

log = logging.getLogger("qa_tester.network")


class ADBError(RuntimeError):
    pass


class NetworkManager:
    def __init__(self, adb_cfg: ADBConfig) -> None:
        self._cfg = adb_cfg
        self._enabled = adb_cfg.enabled
        self._serial: Optional[str] = adb_cfg.device_serial
        self._adb_bin: str = adb_cfg.adb_path or "adb"

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, val: bool) -> None:
        self._enabled = bool(val)

    # ------------------------------------------------------------------
    def _run(self, *args: str) -> str:
        cmd: List[str] = [self._adb_bin]
        if self._serial:
            cmd += ["-s", self._serial]
        cmd += list(args)
        log.debug("ADB: %s", " ".join(cmd))
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode != 0:
                raise ADBError(f"adb failed ({result.returncode}): {result.stderr.strip()}")
            return result.stdout.strip()
        except FileNotFoundError:
            raise ADBError(f"ADB executable not found at '{self._adb_bin}'. Ensure Android platform-tools is installed and in PATH.")

    def _shell(self, shell_cmd: str) -> str:
        return self._run("shell", shell_cmd)

    # ------------------------------------------------------------------
    def enable_airplane_mode(self) -> None:
        if not self._enabled:
            return
        log.info("ADB: toggling airplane mode ON")
        # Try modern Android cmd first, fallback to settings + broadcast
        try:
            self._shell("cmd connectivity airplane-mode enable")
        except ADBError:
            try:
                self._shell(self._cfg.airplane_mode_on_cmd)
                self._shell(self._cfg.broadcast_cmd.format(state="true"))
            except ADBError:
                # Cellular data toggle fallback
                self._shell("svc data disable")

    def disable_airplane_mode(self) -> None:
        if not self._enabled:
            return
        log.info("ADB: toggling airplane mode OFF")
        try:
            self._shell("cmd connectivity airplane-mode disable")
        except ADBError:
            try:
                self._shell(self._cfg.airplane_mode_off_cmd)
                self._shell(self._cfg.broadcast_cmd.format(state="false"))
            except ADBError:
                # Cellular data toggle fallback
                self._shell("svc data enable")

    def get_public_ip(self, timeout_s: float = 5.0) -> Optional[str]:
        """Fetch current public IP from external lookup service."""
        endpoints = [
            "https://api.ipify.org",
            "https://icanhazip.com",
            "https://ifconfig.me/ip",
        ]
        try:
            with httpx.Client(timeout=timeout_s) as client:
                for ep in endpoints:
                    try:
                        resp = client.get(ep)
                        if resp.status_code == 200:
                            ip = resp.text.strip()
                            if ip:
                                return ip
                    except Exception:
                        continue
        except Exception:
            pass
        return None

    def wait_for_connectivity(self, timeout_s: Optional[int] = None) -> bool:
        """Poll until device and PC have working internet connectivity."""
        if not self._enabled:
            return True
        deadline = time.time() + (timeout_s or self._cfg.connectivity_wait_s)
        while time.time() < deadline:
            ip = self.get_public_ip(timeout_s=3.0)
            if ip:
                log.info("ADB: network active. Current public IP: %s", ip)
                return True
            time.sleep(1.5)
        log.warning("ADB: timed out waiting for internet connectivity")
        return False

    def cycle_network(self, off_duration_s: Optional[float] = None) -> Optional[str]:
        """
        Cycle airplane mode / mobile data to rotate dynamic cellular IP.
        Returns the new public IP address if reachable.
        """
        if not self._enabled:
            log.debug("ADB disabled – skipping network cycle")
            return None

        duration = off_duration_s or self._cfg.toggle_duration_s
        log.info("ADB: cycling mobile network (airplane mode for %.1fs)...", duration)

        self.enable_airplane_mode()
        time.sleep(duration)
        self.disable_airplane_mode()

        self.wait_for_connectivity()
        new_ip = self.get_public_ip()
        log.info("ADB: network cycle complete. New IP: %s", new_ip or "unknown")
        return new_ip


# Module-level singleton
network_manager = NetworkManager(config.adb)
