"""
metrics.py – Page-load performance metrics collection and aggregation.

Uses the W3C Navigation Timing API (via JS evaluation) and Playwright's
request/response interception to capture DNS, TCP, TLS, TTFB, DCL, Load.
"""

from __future__ import annotations

import logging
import statistics
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

from playwright.sync_api import Page

log = logging.getLogger("qa_tester.metrics")


# ---------------------------------------------------------------------------
# Per-page timing snapshot
# ---------------------------------------------------------------------------
@dataclass
class PageTimingMetrics:
    """Navigation Timing API milestones in milliseconds (relative to nav start)."""
    dns_ms: Optional[float] = None
    tcp_connect_ms: Optional[float] = None
    tls_ms: Optional[float] = None
    ttfb_ms: Optional[float] = None          # Time To First Byte
    dom_content_loaded_ms: Optional[float] = None
    load_event_ms: Optional[float] = None
    dom_interactive_ms: Optional[float] = None
    # Playwright-level wall-clock total
    total_wall_clock_ms: Optional[float] = None
    # Paint metrics
    first_paint_ms: Optional[float] = None
    first_contentful_paint_ms: Optional[float] = None

    url: str = ""
    status_code: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Collector
# ---------------------------------------------------------------------------
JS_NAVIGATION_TIMING = """
() => {
    const e = performance.getEntriesByType('navigation')[0];
    if (!e) return null;
    return {
        dns_ms:  e.domainLookupEnd - e.domainLookupStart,
        tcp_ms:  e.connectEnd - e.connectStart,
        tls_ms:  (e.secureConnectionStart > 0)
                    ? (e.connectEnd - e.secureConnectionStart) : 0,
        ttfb_ms: e.responseStart - e.requestStart,
        dcl_ms:  e.domContentLoadedEventEnd - e.startTime,
        load_ms: e.loadEventEnd - e.startTime,
        interactive_ms: e.domInteractive - e.startTime,
    };
}
"""

JS_PAINT_TIMING = """
() => {
    const entries = {};
    performance.getEntriesByType('paint').forEach(e => {
        entries[e.name] = e.startTime;
    });
    return entries;
}
"""


def collect_metrics(page: Page, url: str, status_code: Optional[int] = None) -> PageTimingMetrics:
    """Evaluate Navigation Timing and Paint Timing APIs in the page context."""
    m = PageTimingMetrics(url=url, status_code=status_code)
    try:
        nav = page.evaluate(JS_NAVIGATION_TIMING)
        if nav:
            m.dns_ms = round(nav.get("dns_ms", 0), 2)
            m.tcp_connect_ms = round(nav.get("tcp_ms", 0), 2)
            m.tls_ms = round(nav.get("tls_ms", 0), 2)
            m.ttfb_ms = round(nav.get("ttfb_ms", 0), 2)
            m.dom_content_loaded_ms = round(nav.get("dcl_ms", 0), 2)
            m.load_event_ms = round(nav.get("load_ms", 0), 2)
            m.dom_interactive_ms = round(nav.get("interactive_ms", 0), 2)
    except Exception as exc:
        log.warning("Navigation Timing unavailable: %s", exc)

    try:
        paint = page.evaluate(JS_PAINT_TIMING)
        if paint:
            m.first_paint_ms = round(paint.get("first-paint", 0), 2)
            m.first_contentful_paint_ms = round(paint.get("first-contentful-paint", 0), 2)
    except Exception as exc:
        log.warning("Paint Timing unavailable: %s", exc)

    return m


# ---------------------------------------------------------------------------
# Aggregator for a batch of sessions
# ---------------------------------------------------------------------------
class MetricsAggregator:
    """Computes summary statistics across multiple PageTimingMetrics."""

    def __init__(self) -> None:
        self._records: List[PageTimingMetrics] = []

    def add(self, m: PageTimingMetrics) -> None:
        self._records.append(m)

    def add_dict(self, d: Dict[str, Any]) -> None:
        try:
            m = PageTimingMetrics(
                dns_ms=d.get("dns_ms"),
                tcp_connect_ms=d.get("tcp_connect_ms"),
                tls_ms=d.get("tls_ms"),
                ttfb_ms=d.get("ttfb_ms"),
                dom_content_loaded_ms=d.get("dom_content_loaded_ms"),
                load_event_ms=d.get("load_event_ms"),
                dom_interactive_ms=d.get("dom_interactive_ms"),
                total_wall_clock_ms=d.get("total_wall_clock_ms"),
                first_paint_ms=d.get("first_paint_ms"),
                first_contentful_paint_ms=d.get("first_contentful_paint_ms"),
                url=d.get("url", ""),
                status_code=d.get("status_code"),
            )
            self._records.append(m)
        except Exception:
            pass

    def _stat(self, field: str) -> Dict[str, float]:
        vals = [
            getattr(r, field)
            for r in self._records
            if getattr(r, field) is not None
        ]
        if not vals:
            return {}
        return {
            "count": len(vals),
            "mean": round(statistics.mean(vals), 2),
            "median": round(statistics.median(vals), 2),
            "min": round(min(vals), 2),
            "max": round(max(vals), 2),
            "p75": round(_percentile(vals, 75), 2),
            "p90": round(_percentile(vals, 90), 2),
            "p95": round(_percentile(vals, 95), 2),
            "p99": round(_percentile(vals, 99), 2),
        }

    def summary(self) -> Dict[str, Any]:
        fields = [
            "dns_ms", "tcp_connect_ms", "tls_ms", "ttfb_ms",
            "dom_content_loaded_ms", "load_event_ms",
            "first_contentful_paint_ms", "total_wall_clock_ms",
        ]
        return {f: self._stat(f) for f in fields}


def _percentile(data: List[float], pct: float) -> float:
    sorted_data = sorted(data)
    k = (len(sorted_data) - 1) * pct / 100
    lo, hi = int(k), min(int(k) + 1, len(sorted_data) - 1)
    return sorted_data[lo] + (sorted_data[hi] - sorted_data[lo]) * (k - lo)


# Module-level aggregator
metrics_aggregator = MetricsAggregator()
