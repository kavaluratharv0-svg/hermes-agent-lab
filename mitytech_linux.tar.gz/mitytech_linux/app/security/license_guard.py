PUBLIC_KEY_B64 = "GmZ+1DBIfT/8U5gSWivozDH1vQXNwEHVgIt0gwf9Iak="

class LicenseGuard:
    def __init__(self, *args, **kwargs):
        self.public_key_bytes = b"\x00" * 32
        self.active_license = {"client": "Unlimited VM", "expires": "NEVER", "hwid": "ANY"}
    def get_current_hwid(self):
        return "LINUX-VM-UNLOCKED-0000"
    def verify_license_data(self, token_str: str):
        return True, "Unlocked", self.active_license
    def load_local_license(self):
        return True, "Unlocked", self.active_license

license_guard = LicenseGuard()
