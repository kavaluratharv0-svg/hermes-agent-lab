"""
telemetry.py – Telemetry dispatcher stub for Linux operation.
"""
from typing import Any, Dict


class TelemetryDispatcher:
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        pass

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass

    def record_session(self, session_data: Dict[str, Any]) -> None:
        pass

    def check_remote_revocation(self) -> bool:
        return True


telemetry_dispatcher = TelemetryDispatcher()
