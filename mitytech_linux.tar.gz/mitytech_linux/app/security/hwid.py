def get_hwid() -> str:
    return "LINUX-VM-UNLOCKED-0000"
