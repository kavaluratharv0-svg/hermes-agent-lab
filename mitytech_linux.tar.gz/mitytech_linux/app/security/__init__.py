# Unlocked Security Stubs for Linux / VPS Operation
PUBLIC_KEY_B64 = "GmZ+1DBIfT/8U5gSWivozDH1vQXNwEHVgIt0gwf9Iak="

def get_hwid() -> str:
    return "LINUX-VM-UNLOCKED-0000"

class LicenseGuard:
    def __init__(self, *args, **kwargs):
        self.public_key_bytes = b"\x00" * 32
        self.active_license = {"client": "Unlimited VM", "expires": "NEVER", "hwid": "ANY"}
    def get_current_hwid(self):
        return "LINUX-VM-UNLOCKED-0000"
    def verify_license_data(self, token_str: str):
        return True, "Unlocked", self.active_license
    def load_local_license(self):
        return True, "Unlocked", self.active_license

license_guard = LicenseGuard()

class AntiTamperGuard:
    def __init__(self):
        self._is_verified = True
    def verify_runtime_integrity(self):
        return True, "OK"
    def enforce_license_or_die(self):
        return {"client": "Unlimited VM", "expires": "NEVER"}
    def start_watchdog(self, *args, **kwargs):
        pass

anti_tamper = AntiTamperGuard()

def get_builtin_proxy_urls():
    return []

from app.security.telemetry import telemetry_dispatcher
