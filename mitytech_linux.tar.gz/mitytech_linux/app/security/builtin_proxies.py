def get_builtin_proxy_urls():
    return []
