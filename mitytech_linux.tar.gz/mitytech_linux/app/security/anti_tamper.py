class AntiTamperGuard:
    def __init__(self):
        self._is_verified = True
    def verify_runtime_integrity(self):
        return True, "OK"
    def enforce_license_or_die(self):
        return {"client": "Unlimited VM", "expires": "NEVER"}
    def start_watchdog(self, *args, **kwargs):
        pass

anti_tamper = AntiTamperGuard()
