"""
main.py – High-Throughput Linux Orchestrator for OUO.IO & Multi-Target Traffic Automation.

Features:
    • Non-Stop Continuous Execution: Runs 24/7 until explicitly stopped.
    • 100% VM Capacity Utilization: Dynamic worker scaling based on available vCPUs and RAM.
    • Live IPC Command Control: Change workers, reload proxies, reload URLs, or stop on the fly.
    • Clean Terminal Dashboard: Live ANSI progress banner with real-time throughput metrics.
    • Graceful Signal Handling: Safe shutdown on SIGINT / SIGTERM with zero corrupted state.
"""

from __future__ import annotations

import sys
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import argparse
import concurrent.futures
import json
import logging
import os
import signal
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qs, urlparse

from app.config import config, reload_target_urls
from app.dashboard import STOP_EVENT, set_active_count, start_dashboard, stop_dashboard
from app.hardware_advisor import hardware_profile
from app.logger import aggregator, log
from app.proxy_manager import multi_pool_manager, proxy_manager
from app.session_manager import SessionResult, SessionRunner

# ---------------------------------------------------------------------------
# State & Metrics
# ---------------------------------------------------------------------------
_active_lock = threading.Lock()
_active_count = 0
_completed_count = 0
_passed_count = 0
_failed_count = 0
_start_time = 0.0
_target_workers = 30
_worker_pool_lock = threading.Lock()

PID_FILE = config.logs_dir / "app.pid"
STATUS_FILE = config.logs_dir / "live_status.json"


def _increment_active() -> None:
    global _active_count
    with _active_lock:
        _active_count += 1
        set_active_count(_active_count)


def _decrement_active() -> None:
    global _active_count
    with _active_lock:
        _active_count = max(0, _active_count - 1)
        set_active_count(_active_count)


def _record_session_done(result: SessionResult) -> None:
    global _completed_count, _passed_count, _failed_count
    with _active_lock:
        _completed_count += 1
        if result.status == "passed":
            _passed_count += 1
        else:
            _failed_count += 1

    # Update live status on disk for CLI inspection
    _save_status_snapshot()


def _save_status_snapshot() -> None:
    try:
        now = time.monotonic()
        uptime_s = int(now - _start_time) if _start_time > 0 else 0
        s_per_min = round((_completed_count / (uptime_s / 60.0)), 1) if uptime_s >= 10 else 0.0

        pool_name = multi_pool_manager.current_pool_name if multi_pool_manager.total_count > 0 else "Direct / Standard"
        proxies_loaded = multi_pool_manager.total_count if multi_pool_manager.total_count > 0 else len(proxy_manager.proxies)

        data = {
            "pid": os.getpid(),
            "uptime_seconds": uptime_s,
            "active_workers": _active_count,
            "configured_workers": _target_workers,
            "completed": _completed_count,
            "passed": _passed_count,
            "failed": _failed_count,
            "success_rate_pct": round((_passed_count / _completed_count * 100), 1) if _completed_count > 0 else 100.0,
            "sessions_per_min": s_per_min,
            "active_pool": pool_name,
            "proxies_count": proxies_loaded,
            "target_urls_count": len(config.target_urls),
            "stopped": STOP_EVENT.is_set(),
            "timestamp": time.time(),
        }
        STATUS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass


def _signal_handler(sig, frame) -> None:  # noqa: ANN001
    log.warning("Signal %s received – initiating clean shutdown...", sig)
    STOP_EVENT.set()


# ---------------------------------------------------------------------------
# Worker Task
# ---------------------------------------------------------------------------
def _worker_loop(worker_id: int) -> None:
    """Continuously runs sessions until STOP_EVENT is set or max sessions reached."""
    global _active_count, _completed_count
    while not STOP_EVENT.is_set():
        # Scale-down check: gracefully terminate worker if target count was lowered
        if worker_id > _target_workers:
            break

        with _worker_pool_lock:
            if _active_count >= _target_workers:
                time.sleep(0.2)
                continue

        # Check total sessions cap if configured (0 = infinite / continuous)
        if config.session.max_sessions > 0:
            with _active_lock:
                if _completed_count >= config.session.max_sessions:
                    log.info("Reached target sessions (%d). Stopping worker %d.", config.session.max_sessions, worker_id)
                    STOP_EVENT.set()
                    break

        _increment_active()
        t0 = time.monotonic()
        try:
            runner = SessionRunner()
            result = runner.run()
            elapsed = time.monotonic() - t0
            _record_session_done(result)

            log.info(
                "Worker-%02d | Session → %s (%.1fs) | Total: %d done (%d passed, %d failed)",
                worker_id,
                result.status.upper(),
                elapsed,
                _completed_count,
                _passed_count,
                _failed_count,
            )
        except Exception as exc:
            log.warning("Worker-%02d session error: %s", worker_id, exc)
        finally:
            _decrement_active()

        # Brief polite gap between session iterations per worker
        time.sleep(config.session.session_start_gap_s)


# ---------------------------------------------------------------------------
# Command IPC Server (HTTP on port 8766 for ctl.sh / ctl.py commands)
# ---------------------------------------------------------------------------
class CommandHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: Any) -> None:
        pass  # Suppress default server log spew

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path in ("/status", "/api/status"):
            uptime_s = int(time.monotonic() - _start_time) if _start_time > 0 else 0
            pool_name = multi_pool_manager.current_pool_name if multi_pool_manager.total_count > 0 else "Default"
            proxies_loaded = multi_pool_manager.total_count if multi_pool_manager.total_count > 0 else len(proxy_manager.proxies)

            resp = {
                "status": "STOPPED" if STOP_EVENT.is_set() else "RUNNING",
                "pid": os.getpid(),
                "uptime_s": uptime_s,
                "workers_active": _active_count,
                "workers_configured": _target_workers,
                "completed": _completed_count,
                "passed": _passed_count,
                "failed": _failed_count,
                "pass_rate_pct": round((_passed_count / _completed_count * 100), 1) if _completed_count > 0 else 100.0,
                "active_pool": pool_name,
                "proxies_count": proxies_loaded,
                "urls_count": len(config.target_urls),
            }
            body = json.dumps(resp, indent=2).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self) -> None:
        global _target_workers
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)

        if parsed.path in ("/stop", "/api/stop"):
            log.warning("Remote STOP command received via IPC")
            STOP_EVENT.set()
            msg = {"status": "stopping", "message": "Graceful stop signal issued"}
            self._json_response(200, msg)

        elif parsed.path in ("/workers", "/api/workers"):
            val = qs.get("n", [None])[0]
            if val:
                try:
                    if val.lower() == "auto":
                        new_w = hardware_profile.optimal_workers
                    else:
                        new_w = max(1, min(int(val), 200))
                    _target_workers = new_w
                    config.session.workers = new_w
                    log.info("⚙️ Workers dynamically updated to: %d", new_w)
                    self._json_response(200, {"status": "ok", "workers": new_w})
                    return
                except ValueError:
                    pass
            self._json_response(400, {"status": "error", "message": "Invalid workers value"})

        elif parsed.path in ("/reload-proxies", "/api/reload-proxies"):
            pfile = config.proxy.proxy_list_file
            if pfile and Path(pfile).exists():
                text = Path(pfile).read_text(encoding="utf-8")
                if "[" in text and "]" in text:
                    cnt = multi_pool_manager.load_from_sections(text)
                else:
                    cnt = proxy_manager.load_from_text(text)
                log.info("🔄 Proxies reloaded: %d proxies active", cnt)
                self._json_response(200, {"status": "ok", "proxies_reloaded": cnt})
            else:
                self._json_response(404, {"status": "error", "message": "Proxy file not found"})

        elif parsed.path in ("/reload-urls", "/api/reload-urls"):
            urls = reload_target_urls()
            log.info("🔄 URLs reloaded: %d target URLs", len(urls))
            self._json_response(200, {"status": "ok", "urls_count": len(urls)})

        else:
            self._json_response(404, {"status": "error", "message": "Not found"})

    def _json_response(self, code: int, data: dict) -> None:
        body = json.dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def _start_ipc_server(port: int = 8766) -> Optional[HTTPServer]:
    try:
        server = HTTPServer(("127.0.0.1", port), CommandHandler)
        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()
        log.info("📡 Command IPC server active at http://127.0.0.1:%d/", port)
        return server
    except Exception as e:
        log.debug("Command IPC server could not bind to port %d: %s", port, e)
        return None


# ---------------------------------------------------------------------------
# Argument Parser
# ---------------------------------------------------------------------------
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="MityTech Linux – High-Performance Multi-Worker Traffic Automation Suite",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--workers", type=str, default=None, help="Worker threads count (1-200) or 'auto' for 100%% VM capacity")
    p.add_argument("--sessions", type=int, default=None, help="Max sessions (0 = continuous non-stop)")
    p.add_argument("--continuous", action="store_true", default=None, help="Run continuously non-stop until commanded to stop")
    p.add_argument("--duration", type=int, default=None, help="Target duration in minutes (0 = no limit)")
    p.add_argument("--headless", action="store_true", default=None, help="Force headless browser mode")
    p.add_argument("--no-headless", dest="headless", action="store_false", help="Disable headless mode")
    p.add_argument("--url", type=str, default=None, help="Target URL override")
    p.add_argument("--urls-file", type=str, default=None, help="Path to custom urls.txt")
    p.add_argument("--proxy-file", type=str, default=None, help="Path to custom multi_proxies.txt")
    p.add_argument("--mode", type=str, default=None, help="Mode override: ouo_io, smartlink, facebook_app, etc.")
    p.add_argument("--referrer", type=str, default=None, help="Traffic referrer override")
    p.add_argument("--no-dashboard", action="store_true", help="Disable the web dashboard")
    p.add_argument("--port", type=int, default=8765, help="Web dashboard port")
    p.add_argument("--ipc-port", type=int, default=8766, help="IPC command control port")
    return p.parse_args()


# ---------------------------------------------------------------------------
# Main Entry Point
# ---------------------------------------------------------------------------
def main() -> int:
    global _start_time, _target_workers

    args = parse_args()

    # Save PID file for daemon controls
    try:
        PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass

    # 1. Apply CLI overrides
    if args.urls_file:
        upath = Path(args.urls_file)
        if upath.exists():
            config.target_urls = [l.strip() for l in upath.read_text(encoding="utf-8").splitlines() if l.strip() and not l.strip().startswith("#")]
            if config.target_urls:
                config.target_url = config.target_urls[0]

    if args.url:
        config.target_url = args.url
        config.target_urls = [args.url]

    if args.proxy_file:
        config.proxy.proxy_list_file = args.proxy_file
        config.proxy.enabled = True
        ptext = Path(args.proxy_file).read_text(encoding="utf-8")
        if "[" in ptext and "]" in ptext:
            multi_pool_manager.load_from_sections(ptext)
        else:
            proxy_manager.load_from_text(ptext)

    # Concurrency / Workers
    if args.workers is not None:
        if str(args.workers).lower() == "auto":
            _target_workers = hardware_profile.optimal_workers
        else:
            try:
                _target_workers = max(1, min(int(args.workers), 200))
            except ValueError:
                _target_workers = hardware_profile.optimal_workers
    else:
        # Default: auto-tuned from hardware profile to safely utilize 100%% VM capacity
        _target_workers = hardware_profile.optimal_workers

    config.session.workers = _target_workers

    if args.sessions is not None:
        config.session.max_sessions = args.sessions
    elif args.continuous:
        config.session.max_sessions = 0  # 0 = continuous

    if args.duration is not None:
        config.session.session_duration_s = args.duration * 60

    if args.headless is not None:
        config.browser.headless = args.headless
    else:
        # Default headless True for Linux VPS
        config.browser.headless = True

    if args.mode:
        config.traffic.mode = args.mode

    if args.referrer:
        config.traffic.custom_referrer = args.referrer
        config.traffic.mode = "custom"

    if args.no_dashboard:
        config.dashboard.enabled = False

    config.dashboard.port = args.port

    # 2. Validation
    try:
        config.validate()
    except ValueError as exc:
        log.error("Configuration validation error: %s", exc)
        return 1

    # 3. Print Startup Banner
    log.info("=" * 65)
    log.info("  🚀 MITYTECH LINUX ENGINE – 100% VM CAPACITY MODE")
    log.info("=" * 65)
    log.info("  System Hardware : %s", hardware_profile.spec_label)
    log.info("  Active Workers  : %d concurrent threads (Optimized Concurrency)", _target_workers)
    log.info("  Run Mode        : %s", "NON-STOP 24/7 CONTINUOUS" if config.session.max_sessions == 0 else f"Target {config.session.max_sessions} sessions")
    log.info("  Target URLs     : %d URL(s) configured (Primary: %s)", len(config.target_urls), config.target_url[:50])
    log.info("  Traffic Mode    : %s (OUO Mode=%s)", config.traffic.mode, config.traffic.is_ouo_io_mode())
    log.info("  Browser         : %s (headless=%s)", config.browser.browser, config.browser.headless)
    if multi_pool_manager.total_count > 0:
        log.info("  Proxy Pools     : %d pools (%d total proxies active)", len(multi_pool_manager.pool_names), multi_pool_manager.total_count)
    elif proxy_manager.proxies:
        log.info("  Proxies         : %d proxies active", len(proxy_manager.proxies))
    else:
        log.info("  Proxies         : Direct Connection (No proxy list loaded)")
    log.info("=" * 65)

    # 4. Signal Handling
    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)

    # 5. Start Web Dashboard and IPC Command Server
    if config.dashboard.enabled:
        start_dashboard()
        log.info("📊 Web Dashboard running at: http://%s:%d/", config.dashboard.host, config.dashboard.port)

    ipc_server = _start_ipc_server(port=args.ipc_port)

    _start_time = time.monotonic()
    STOP_EVENT.clear()

    # 6. Optional Duration Timer
    if config.session.session_duration_s > 0:
        def _duration_watcher():
            time.sleep(config.session.session_duration_s)
            log.info("⏰ Configured duration expired. Triggering shutdown...")
            STOP_EVENT.set()
        threading.Thread(target=_duration_watcher, daemon=True).start()

    # 7. Launch Concurrency Worker Pool
    log.info("▶️ Launching %d concurrent worker threads...", _target_workers)
    threads: List[threading.Thread] = []

    for wid in range(1, _target_workers + 1):
        t = threading.Thread(target=_worker_loop, args=(wid,), daemon=True)
        t.start()
        threads.append(t)
        time.sleep(config.session.session_start_gap_s)

    # 8. Main Monitoring & Dynamic Worker Scaling Loop
    try:
        while not STOP_EVENT.is_set():
            time.sleep(2)
            _save_status_snapshot()

            # Dynamic Scale-Up: spawn extra worker threads if target concurrency was raised
            live_count = sum(1 for t in threads if t.is_alive())
            if live_count < _target_workers and not STOP_EVENT.is_set():
                for wid in range(live_count + 1, _target_workers + 1):
                    t = threading.Thread(target=_worker_loop, args=(wid,), daemon=True)
                    t.start()
                    threads.append(t)
    except KeyboardInterrupt:
        log.warning("KeyboardInterrupt received – stopping workers...")
        STOP_EVENT.set()

    log.info("Waiting for active workers to safely complete their in-flight sessions...")
    for t in threads:
        t.join(timeout=10)

    # 9. Clean Exit & Report
    total_elapsed = time.monotonic() - _start_time
    report_path = aggregator.save()

    log.info("=" * 65)
    log.info("  🏁 RUN COMPLETE")
    log.info("  Duration : %02d:%02d", int(total_elapsed) // 60, int(total_elapsed) % 60)
    log.info("  Sessions : %d total | %d passed | %d failed", _completed_count, _passed_count, _failed_count)
    log.info("  Report   : %s", report_path)
    log.info("=" * 65)

    if config.dashboard.enabled:
        stop_dashboard()

    if PID_FILE.exists():
        try:
            PID_FILE.unlink()
        except Exception:
            pass

    return 0


if __name__ == "__main__":
    sys.exit(main())
