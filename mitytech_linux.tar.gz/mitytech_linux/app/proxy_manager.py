"""
proxy_manager.py – Universal Hybrid Rotating Proxy Engine.
Auto-detects ANY proxy format, supports built-in encrypted residential networks
and custom user proxy lists, with pre-flight health checks and dynamic session rotation.
"""

from __future__ import annotations

import concurrent.futures
import itertools
import logging
import random
import re
import socket
import threading as _threading
import time
import uuid
from pathlib import Path
from typing import Callable, Iterator, List, Optional
from urllib.parse import urlparse

import httpx

from app.config import ProxyConfig, config, DEFAULT_TARGET_COUNTRIES
from app.security.builtin_proxies import get_builtin_proxy_urls

log = logging.getLogger("qa_tester.proxy")


# ---------------------------------------------------------------------------
# Dynamic FloppyData Gateway Port Failover & Optimization
# ---------------------------------------------------------------------------
_FLOPPYDATA_RESOLVED_PORT: Optional[int] = None
_FLOPPYDATA_RESOLVED_TIME: float = 0.0
_FLOPPYDATA_LOCK = _threading.Lock()


def get_best_floppydata_port(host: str, port: int) -> int:
    """Auto-detect the fastest, live FloppyData gateway port.

    If port 10080 is blocked by the local ISP/network or down on the server,
    fail over dynamically to alternate high-availability ports (10083 or 10090).
    """
    global _FLOPPYDATA_RESOLVED_PORT, _FLOPPYDATA_RESOLVED_TIME
    if "g-w.info" not in host.lower() or port not in (10080, 10083, 10090):
        return port

    now = time.monotonic()
    with _FLOPPYDATA_LOCK:
        if _FLOPPYDATA_RESOLVED_PORT and (now - _FLOPPYDATA_RESOLVED_TIME < 300):
            return _FLOPPYDATA_RESOLVED_PORT

    # Check candidates: prioritize fast alternate 10083, then 10090, then requested
    candidates = [10083, 10090, port] if port == 10080 else [port, 10083, 10090]
    seen = set()
    ordered_candidates = [p for p in candidates if not (p in seen or seen.add(p))]

    for p in ordered_candidates:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5)
            res = s.connect_ex((host, p))
            s.close()
            if res == 0:
                with _FLOPPYDATA_LOCK:
                    _FLOPPYDATA_RESOLVED_PORT = p
                    _FLOPPYDATA_RESOLVED_TIME = now
                if p != port:
                    log.info("[FLOPPYDATA PORT ROUTER] Port %s routed to live high-speed gateway port %s", port, p)
                return p
        except Exception:
            pass

    return port


def _build_proxy_dict(scheme: str, host: str, port: str, user: Optional[str], pwd: Optional[str]) -> dict:
    """Normalize components, apply FloppyData port failover, and build connection strings."""
    if port and port.isdigit():
        p_int = get_best_floppydata_port(host, int(port))
        port = str(p_int)
    server = f"{scheme}://{host}:{port}"
    if user and pwd:
        url = f"{scheme}://{user}:{pwd}@{host}:{port}"
    elif user:
        url = f"{scheme}://{user}@{host}:{port}"
    else:
        url = server
    return {
        "scheme": scheme,
        "server": server,
        "username": user,
        "password": pwd,
        "url": url,
    }


# ---------------------------------------------------------------------------
# Universal Proxy Parser
# ---------------------------------------------------------------------------
def parse_proxy_universal(raw: str) -> Optional[dict]:
    """Parse any proxy format into normalized components:

    Supported formats:
      • host:port:user:pass
      • user:pass:host:port
      • user:pass@host:port
      • host:port@user:pass
      • protocol://user:pass@host:port
      • protocol://host:port:user:pass
      • host:port (unauthenticated / IP whitelisted)
      • Comma, tab, pipe, or semicolon separated
    """
    raw = raw.strip().strip('"\'')
    if not raw or raw.startswith("#"):
        return None

    # 1. Normalize delimiters (comma, tab, pipe, semicolon) -> colon
    for sep in [",", "\t", "|", ";"]:
        if sep in raw:
            parts = [p.strip() for p in raw.split(sep) if p.strip()]
            if len(parts) == 4:
                raw = f"{parts[0]}:{parts[1]}:{parts[2]}:{parts[3]}"
            elif len(parts) == 2:
                raw = f"{parts[0]}:{parts[1]}"
            break

    # 2. Detect & strip protocol prefix
    scheme = "http"
    for s in ["socks5h://", "socks5://", "socks4://", "https://", "http://", "socks5:", "socks4:"]:
        if raw.lower().startswith(s):
            scheme = s.replace("://", "").replace(":", "")
            raw = raw[len(s):]
            break

    # 3. Check for '@' format
    if "@" in raw:
        left, right = raw.split("@", 1)
        if ":" in left and ":" in right:
            l_parts = [p.strip() for p in left.split(":")]
            r_parts = [p.strip() for p in right.split(":")]
            if r_parts[-1].isdigit():
                # user:pass@host:port
                user, pwd = l_parts[0], l_parts[1]
                host, port = r_parts[0], r_parts[1]
            else:
                # host:port@user:pass
                host, port = l_parts[0], l_parts[1]
                user, pwd = r_parts[0], r_parts[1]
            return _build_proxy_dict(scheme, host, port, user, pwd)
        elif ":" in right:
            user = left.strip()
            r_parts = [p.strip() for p in right.split(":")]
            host, port = r_parts[0], r_parts[1]
            return _build_proxy_dict(scheme, host, port, user, None)

    # 4. Check colon-delimited format
    parts = [p.strip() for p in raw.split(":")]
    if len(parts) == 4:
        # host:port:user:pass OR user:pass:host:port
        if parts[1].isdigit():
            host, port, user, pwd = parts[0], parts[1], parts[2], parts[3]
        elif parts[3].isdigit():
            user, pwd, host, port = parts[0], parts[1], parts[2], parts[3]
        else:
            host, port, user, pwd = parts[0], parts[1], parts[2], parts[3]
        return _build_proxy_dict(scheme, host, port, user, pwd)
    elif len(parts) == 2:
        host, port = parts[0], parts[1]
        return _build_proxy_dict(scheme, host, port, None, None)
    elif len(parts) == 3:
        if parts[1].isdigit():
            host, port, user = parts[0], parts[1], parts[2]
            return _build_proxy_dict(scheme, host, port, user, None)

    return None


def _detect_country(username: str) -> Optional[str]:
    """Auto-detect country code from proxy username (country-au, __cr.au, -country-au, -zone-au)."""
    if not username:
        return None
    # Match: country-XX, __cr.XX, -country-XX, -zone-XX (2-letter country code)
    m = re.search(r"(?:country|__cr|_?zone)[\-\.]([a-z]{2})(?![a-z])", username, re.IGNORECASE)
    if m:
        return m.group(1).lower()
    return None


# ---------------------------------------------------------------------------
# Persistent IP Deduplication Cache — survives app restarts
# ---------------------------------------------------------------------------
# OUO.io deduplicates views per IP per 24 hours. The old in-memory cache
# was wiped every app restart, meaning IPs used in previous runs were
# considered "fresh" — but OUO still had them in its 24h dedup window.
# Result: sessions logged PASSED but 0 views credited on the dashboard.
#
# Fix: persist {ip -> timestamp} to disk with a 23-hour eviction window.
# An IP is blocked until OUO's 24h window fully expires.
# ---------------------------------------------------------------------------
import json as _json
import os as _os
import time as _time
import threading as _threading
from pathlib import Path as _Path

_OUO_IP_CACHE_FILE = _Path(__file__).parent.parent / "data" / "ouo_used_ips.json"
_OUO_WINDOW_HOURS = 23   # 1h safety margin inside OUO's 24h window
_PERSIST = _os.getenv("SAVE_ARTIFACTS", "").strip().lower() in ("1", "true", "yes")

_USED_SESSION_IPS: dict = {}    # ip -> unix timestamp of first use
_USED_IPS_LOCK = _threading.Lock()


def _load_ip_cache() -> None:
    """Load persisted IP history into RAM (23h window), then REMOVE the file —
    default runs leave zero artifacts on disk. History survives this process
    only; restart loses it (accepted: no-cache requirement)."""
    global _USED_SESSION_IPS
    try:
        if _OUO_IP_CACHE_FILE.exists():
            raw = _json.loads(_OUO_IP_CACHE_FILE.read_text(encoding="utf-8"))
            cutoff = _time.time() - (_OUO_WINDOW_HOURS * 3600)
            with _USED_IPS_LOCK:
                _USED_SESSION_IPS = {ip: ts for ip, ts in raw.items() if ts > cutoff}
            if not _PERSIST:
                try:
                    _OUO_IP_CACHE_FILE.unlink()
                except Exception:
                    pass
    except Exception:
        pass


def _save_ip_cache() -> None:
    """Persist current cache to disk — only when SAVE_ARTIFACTS=1."""
    if not _PERSIST:
        return
    try:
        _OUO_IP_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with _USED_IPS_LOCK:
            snapshot = dict(_USED_SESSION_IPS)
        _OUO_IP_CACHE_FILE.write_text(_json.dumps(snapshot, indent=2), encoding="utf-8")
    except Exception:
        pass


# Load persisted cache on module import
_load_ip_cache()


def is_ip_already_used(ip: str) -> bool:
    """Return True if this IP was used within OUO's 24h dedup window."""
    if not ip or ip in ("?", "unknown", "127.0.0.1"):
        return False
    cutoff = _time.time() - (_OUO_WINDOW_HOURS * 3600)
    with _USED_IPS_LOCK:
        ts = _USED_SESSION_IPS.get(ip)
        return ts is not None and ts > cutoff


def record_used_ip(ip: str) -> None:
    """Record an exit IP with timestamp so it won't be reused within 23h."""
    if not ip or ip in ("?", "unknown", "127.0.0.1"):
        return
    with _USED_IPS_LOCK:
        if ip not in _USED_SESSION_IPS:   # preserve first-use timestamp
            _USED_SESSION_IPS[ip] = _time.time()
    _threading.Thread(target=_save_ip_cache, daemon=True).start()


def clear_used_ips() -> None:
    """Clear in-memory AND on-disk IP cache (for fresh test runs only)."""
    global _USED_SESSION_IPS
    with _USED_IPS_LOCK:
        _USED_SESSION_IPS.clear()
    try:
        if _OUO_IP_CACHE_FILE.exists():
            _OUO_IP_CACHE_FILE.unlink()
    except Exception:
        pass


def get_used_ips_count() -> int:
    """Count IPs still within OUO's 24h dedup window."""
    cutoff = _time.time() - (_OUO_WINDOW_HOURS * 3600)
    with _USED_IPS_LOCK:
        return sum(1 for ts in _USED_SESSION_IPS.values() if ts > cutoff)


# ---------------------------------------------------------------------------
# Proxy Data Model
# ---------------------------------------------------------------------------
class Proxy:
    """Universal Proxy Model with auto-detection and dynamic residential session rotation."""

    def __init__(self, raw: str) -> None:
        self.raw: str = raw.strip()
        parsed = parse_proxy_universal(raw)
        if not parsed:
            raise ValueError(f"Unable to parse proxy string: {raw}")

        self.scheme: str = parsed["scheme"]
        self.server: str = parsed["server"]
        self.username: Optional[str] = parsed["username"]
        self.password: Optional[str] = parsed["password"]
        self.url: str = parsed["url"]

        # Health Metadata
        self.is_alive: bool = True
        self.exit_ip: Optional[str] = None
        self.country_code: Optional[str] = _detect_country(self.username) if self.username else None
        self.country: Optional[str] = self.country_code
        self.target_country: Optional[str] = self.country_code
        self.target_device: Optional[str] = None
        self.isp: Optional[str] = None
        self.latency_ms: float = 0.0
        self.last_checked: float = 0.0

    def rotate_session(self, target_country: Optional[str] = None, target_device: Optional[str] = None) -> "Proxy":
        """Assign a fresh session ID + auto-detect country + rotate for residential proxies.

        Guarantees:
          • Fresh residential session ID for every single browser session.
          • Strips static city targeting to access the entire nationwide/global pool of millions of IPs.
          • Rotates across active configured countries so no IP repeats.
        """
        if not self.username:
            return self

        import secrets as _secrets
        fresh_id = _secrets.token_hex(8)  # 16 hex chars, cryptographically random
        detected_country = _detect_country(self.username)

        # Select country: prioritize target_country passed by the device profile,
        # otherwise pick from active countries in config.proxy.active_countries
        if target_country:
            country = target_country.lower()
        else:
            allowed_countries = [c.lower() for c in (config.proxy.active_countries or DEFAULT_TARGET_COUNTRIES)]
            country = random.choice(allowed_countries) if allowed_countries else (detected_country or "us")

        user = self.username
        server_lower = self.server.lower()
        new_user = user

        # ── 1. DataImpulse residential format (gw.dataimpulse.com or __cr. / __sessid.) ──
        if "dataimpulse" in server_lower or "__cr." in user or "__sessid." in user:
            if country and "__cr." in new_user:
                new_user = re.sub(r"__cr\.[a-zA-Z]+", f"__cr.{country}", new_user)
            elif country and "__cr." not in new_user:
                new_user = f"{new_user}__cr.{country}"

            if "__sessid." in new_user:
                new_user = re.sub(r"__sessid\.[a-zA-Z0-9_-]+", f"__sessid.{fresh_id}", new_user)
            else:
                new_user = f"{new_user}__sessid.{fresh_id}"

        # ── 2. Universal Residential Format (geo.g-w.info, FloppyData, Webshare, Smartproxy, BrightData, etc.) ──
        elif any(k in user.lower() for k in ("country", "session", "sessid", "residential", "zone", "type-")):
            # Strip static city targeting so proxy provider draws from the entire national/global
            # residential pool with millions of IPs, preventing single-city IP reuse and exhaustion.
            new_user = re.sub(r"[\-\._]?city[\-\._][a-zA-Z0-9_]+", "", new_user, flags=re.IGNORECASE)
            if country:
                new_user = re.sub(r"((?:country|__cr|_?zone)[\-\.])([a-zA-Z]{2})", rf"\g<1>{country}", new_user, count=1, flags=re.IGNORECASE)

            if re.search(r"(?:session|sessid)[\-\._][a-zA-Z0-9]+", new_user, re.IGNORECASE):
                new_user = re.sub(r"((?:session|sessid)[\-\._])[a-zA-Z0-9]+", rf"\g<1>{fresh_id}", new_user, count=1, flags=re.IGNORECASE)
            else:
                new_user = f"{new_user}-session-{fresh_id}"

        new_raw = f"{self.scheme}://{new_user}:{self.password}@{self.server.split('://')[1]}"
        p = Proxy(new_raw)
        p.exit_ip = self.exit_ip
        p.country_code = country
        p.country = country
        p.target_country = country
        p.target_device = target_device
        p.raw = self.raw
        return p

    def as_playwright_proxy(self) -> dict:
        rotated = self.rotate_session()
        d: dict = {"server": rotated.server}
        if rotated.username:
            d["username"] = rotated.username
        if rotated.password:
            d["password"] = rotated.password
        return d

    @property
    def is_residential_dynamic(self) -> bool:
        if not self.username:
            return False
        return any(k in self.username.lower() for k in ("session", "country", "residential", "zone", "__cr.", "__sessid.", "type-")) or "dataimpulse" in self.server.lower()


    @property
    def masked_display(self) -> str:
        """Safe representation without exposing passwords in the UI."""
        host_port = self.server.split("://")[-1]
        if self.username:
            u_short = self.username[:8] + "..." if len(self.username) > 8 else self.username
            return f"{self.scheme}://{u_short}:***@{host_port}"
        return f"{self.scheme}://{host_port}"

    def __repr__(self) -> str:
        return f"<Proxy {self.masked_display}>"


# ---------------------------------------------------------------------------
# Hybrid Proxy Manager
# ---------------------------------------------------------------------------
class ProxyManager:
    """Manages User Custom Proxies and Dynamic Routing.

    Provides:
      • Universal auto-detection for all formats
      • Concurrent pre-flight proxy health verification
      • Pruning of dead proxies before runs
      • Dynamic per-session residential IP allocation
    """

    def __init__(self, proxy_config: ProxyConfig) -> None:
        self._cfg = proxy_config
        self.pool_mode: str = "custom"  # default to custom user proxies
        self._lock = threading.Lock()

        # Separate pools
        self._builtin_proxies: List[Proxy] = []
        self._custom_proxies: List[Proxy] = []
        self._active_pool: List[Proxy] = []

        self._iter: Iterator[Proxy] = iter([])
        self._failures: dict[str, int] = {}
        self._MAX_FAILURES = 3

        self.set_mode("custom")

    @property
    def proxies(self) -> List[Proxy]:
        """Return the list of proxies in the active pool."""
        return self._active_pool

    def __len__(self) -> int:
        return len(self._active_pool)

    # ------------------------------------------------------------------
    # Pool Initializers
    # ------------------------------------------------------------------
    def set_mode(self, mode: str) -> None:
        """Switch between 'custom' (user proxies) and optional 'builtin'."""
        self.pool_mode = mode.lower()
        if self.pool_mode == "custom":
            self._active_pool = list(self._custom_proxies)
        else:
            self._active_pool = list(self._builtin_proxies)

        self._cfg.enabled = len(self._active_pool) > 0
        self._build_iterator()
        log.info("Proxy Pool mode set to: %s (%d proxies ready)", self.pool_mode.upper(), len(self._active_pool))

    def load_from_text(self, text: str) -> int:
        """Parse and load user-provided custom proxies in any format."""
        lines = [l.strip() for l in text.splitlines() if l.strip() and not l.startswith("#")]
        loaded: List[Proxy] = []
        for raw in lines:
            try:
                p = Proxy(raw)
                loaded.append(p)
            except Exception as exc:
                log.warning("Skipping invalid proxy input %r: %s", raw, exc)

        self._custom_proxies = loaded
        self._active_pool = list(loaded)
        self._cfg.enabled = len(self._active_pool) > 0
        self._build_iterator()
        return len(loaded)

    def prune_dead_proxies(self) -> List[Proxy]:
        """Filter out dead proxies, keeping only verified alive ones in active & custom pools."""
        alive = [p for p in self._active_pool if p.is_alive or getattr(p, "is_residential_dynamic", False)]
        if not alive and self._active_pool:
            # Retain proxies so the pool is not permanently emptied if a network or quota error occurs
            alive = list(self._active_pool)
        self._active_pool = alive
        self._custom_proxies = alive
        self._cfg.enabled = len(self._active_pool) > 0
        self._build_iterator()
        return alive

    def _build_iterator(self) -> None:
        good = [
            p for p in self._active_pool
            if getattr(p, "is_residential_dynamic", False)
            or (self._failures.get(p.server, 0) < self._MAX_FAILURES and p.is_alive)
        ]
        if not good and self._active_pool:
            good = list(self._active_pool)
        if not good:
            self._iter = iter([])
            return
        if self._cfg.rotation_strategy == "random":
            self._iter = iter(random.sample(good, len(good)) * 1000)
        else:
            self._iter = itertools.cycle(good)

    # ------------------------------------------------------------------
    # Pre-Flight Health Checker
    # ------------------------------------------------------------------
    def verify_single_proxy(self, proxy: Proxy, timeout: float = 7.0) -> dict:
        """Tests proxy connectivity by validating an actual HTTPS CONNECT tunnel.

        This directly prevents ERR_TUNNEL_CONNECTION_FAILED at runtime:
          1. Opens socket connection to proxy host:port.
          2. Sends 'CONNECT www.google.com:443 HTTP/1.1' with Proxy-Authorization.
          3. '200 OK' / '200 Connection established' = ALIVE.
          4. '403 Forbidden' (administrative rules) = DEAD (Data exhausted or account restricted).
          5. '407 Proxy Authentication Required' = DEAD (Bad user/pass).
          6. Connection refused / timeout = DEAD.
        """
        import socket
        import base64
        from urllib.parse import urlparse

        t0 = time.monotonic()
        test_p = proxy.rotate_session() if proxy.is_residential_dynamic else proxy

        p_info = urlparse(test_p.url)
        host = p_info.hostname or "127.0.0.1"
        port = p_info.port or (10080 if "g-w.info" in host else 80)
        user = p_info.username
        pwd = p_info.password

        # ── Step 1: Real HTTPS Tunnel Verification (CONNECT handshake) ──────
        tunnel_ok = False
        status_line = ""
        error_msg = None

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            sock.connect((host, port))

            auth_hdr = ""
            if user and pwd:
                b64_creds = base64.b64encode(f"{user}:{pwd}".encode("utf-8")).decode("ascii")
                auth_hdr = f"Proxy-Authorization: Basic {b64_creds}\r\n"

            connect_req = f"CONNECT www.google.com:443 HTTP/1.1\r\nHost: www.google.com:443\r\n{auth_hdr}\r\n"
            sock.sendall(connect_req.encode("ascii"))

            raw_resp = sock.recv(1024).decode("utf-8", errors="replace")
            sock.close()

            status_line = raw_resp.splitlines()[0] if raw_resp else ""

            if any(code in status_line for code in ("200 ", "200 OK", "Connection established")):
                tunnel_ok = True
            elif "403" in status_line:
                if "administrative rules" in raw_resp.lower():
                    error_msg = "403 Forbidden (Data exhausted or account restricted)"
                else:
                    error_msg = "403 Forbidden (Proxy rejected tunnel)"
            elif "407" in status_line:
                error_msg = "407 Proxy Authentication Required (Invalid credentials)"
            else:
                error_msg = f"Tunnel failed: {status_line[:50]}"
        except Exception as exc:
            error_msg = f"Connection error: {str(exc)[:60]}"

        latency = round((time.monotonic() - t0) * 1000, 1)

        if not tunnel_ok:
            proxy.is_alive = False
            return {
                "server": proxy.server,
                "alive": False,
                "error": error_msg or "Tunnel connection failed",
                "latency_ms": latency,
            }

        # ── Step 2: Tunnel is working! Enrich geo info if available ────────
        proxy.is_alive = True
        proxy.latency_ms = latency
        proxy.last_checked = time.time()

        # Derive 2-letter country code from proxy username or existing value
        if proxy.is_residential_dynamic:
            # Dynamic residential proxies rotate to ANY target country on demand
            proxy.country = "Dynamic (Multi-Country)"
            proxy.target_country = None
            proxy.country_code = None
        else:
            cc = getattr(proxy, "country_code", None) or _detect_country(proxy.username or "")
            if cc:
                proxy.country = cc.upper()
                proxy.target_country = cc.lower()

        # Optional background lookup for exit IP / ISP (non-critical)
        try:
            with httpx.Client(
                proxy=test_p.url,
                timeout=4.0,
                headers={"User-Agent": "Mozilla/5.0"},
            ) as client:
                r = client.get("http://ip-api.com/json?fields=query,country,countryCode,isp")
                if r.status_code == 200:
                    d = r.json()
                    proxy.exit_ip = d.get("query")
                    if not proxy.is_residential_dynamic:
                        if d.get("countryCode"):
                            proxy.country = d.get("countryCode").upper()
                            proxy.target_country = d.get("countryCode").lower()
                    if d.get("isp"):
                        proxy.isp = d.get("isp")
        except Exception:
            pass

        return {
            "server": proxy.server,
            "alive": True,
            "exit_ip": proxy.exit_ip or "residential-rotating",
            "country": proxy.country or (cc.upper() if cc else "?"),
            "isp": proxy.isp or "Residential Dynamic",
            "latency_ms": latency,
            "error": None,
        }

    def verify_all_proxies(
        self,
        proxies: Optional[List[Proxy]] = None,
        max_workers: int = 10,
        on_progress: Optional[Callable[[int, int, dict], None]] = None,
    ) -> dict:
        """Concurrently checks all proxies in the pool, prunes dead ones, and returns audit metrics."""
        targets = proxies or self._active_pool
        if not targets:
            return {"total": 0, "alive": 0, "dead": 0, "results": []}

        log.info("Running pre-flight verification on %d proxies ...", len(targets))
        results: List[dict] = []
        alive_count = 0
        dead_count = 0

        with concurrent.futures.ThreadPoolExecutor(max_workers=min(max_workers, len(targets))) as executor:
            future_map = {executor.submit(self.verify_single_proxy, p): p for p in targets}
            done_idx = 0
            for fut in concurrent.futures.as_completed(future_map):
                done_idx += 1
                try:
                    res = fut.result()
                    results.append(res)
                    if res["alive"]:
                        alive_count += 1
                    else:
                        dead_count += 1
                    if on_progress:
                        on_progress(done_idx, len(targets), res)
                except Exception as e:
                    dead_count += 1

        # Prune dead proxies from active pool, but never prune dynamic residential proxies
        alive_targets = [p for p in targets if p.is_alive or getattr(p, "is_residential_dynamic", False)]
        self._active_pool = alive_targets if alive_targets else list(targets)
        self._build_iterator()
        log.info("Pre-flight check complete: %d ALIVE, %d DEAD", alive_count, dead_count)

        return {
            "total": len(targets),
            "alive": alive_count,
            "dead": dead_count,
            "results": results,
        }

    # ------------------------------------------------------------------
    # Dispatch & Status
    # ------------------------------------------------------------------
    def next_proxy(self) -> Optional[Proxy]:
        """Returns the next usable proxy with rotation applied (Thread-Safe)."""
        if not self._cfg.enabled or not self._active_pool:
            return None
        with self._lock:
            try:
                return next(self._iter)
            except StopIteration:
                self._build_iterator()
                try:
                    return next(self._iter)
                except StopIteration:
                    return None

    def get_current_public_ip(self, proxy: Proxy) -> Optional[str]:
        """Utility to look up the public IP of a proxy."""
        res = self.verify_single_proxy(proxy, timeout=5.0)
        return res.get("exit_ip") if res.get("alive") else None

    def report_failure(self, proxy: Proxy) -> None:
        # Rotating residential proxies (like FloppyData/geo.g-w.info) must NEVER be pruned!
        # They connect through a single gateway to millions of residential peer IPs.
        # A single slow peer does not mean the proxy gateway is dead.
        if getattr(proxy, "is_residential_dynamic", False):
            return

        with self._lock:
            self._failures[proxy.server] = self._failures.get(proxy.server, 0) + 1
            log.warning("Proxy %s failure count: %d", proxy.server, self._failures[proxy.server])
            if self._failures[proxy.server] >= self._MAX_FAILURES:
                log.error("Proxy %s exceeded threshold – pruning", proxy.server)
                proxy.is_alive = False
                self._active_pool = [p for p in self._active_pool if p.server != proxy.server]
                self._build_iterator()

    @property
    def count(self) -> int:
        return len(self._active_pool)

    @property
    def pool_info(self) -> dict:
        return {
            "mode": self.pool_mode,
            "total": len(self._active_pool),
            "is_builtin": self.pool_mode == "builtin",
            "is_residential": any(p.is_residential_dynamic for p in self._active_pool),
        }


# ---------------------------------------------------------------------------
# Multi-Pool Failover Manager
# ---------------------------------------------------------------------------
import threading as _threading
from dataclasses import dataclass, field as _field


@dataclass
class ProxyPool:
    """A named group of proxy lines from one provider/account."""
    name: str
    raw_lines: str                        # raw text — one proxy per line
    proxies: List[Proxy] = _field(default_factory=list)
    exhausted: bool = False
    failure_count: int = 0
    FAILURE_THRESHOLD: int = 5            # consecutive failures before marking exhausted

    def load(self) -> int:
        self.proxies = []
        for line in self.raw_lines.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            try:
                self.proxies.append(Proxy(line))
            except Exception:
                pass
        self.exhausted = False
        self.failure_count = 0
        return len(self.proxies)

    def is_active(self) -> bool:
        return not self.exhausted and bool(self.proxies)


class MultiPoolManager:
    """
    Manages multiple proxy pools (e.g., FloppyData account 1, account 2…).
    Auto-fails over to the next pool when the current one is exhausted.

    Usage:
        mpm = MultiPoolManager()
        mpm.add_pool("FloppyData-1", "http://user1:pass@host:port")
        mpm.add_pool("FloppyData-2", "http://user2:pass@host:port")
        proxy = mpm.next_proxy()          # auto-rotates & fails over
        mpm.report_failure(proxy)         # call on ERR_PROXY_* errors
    """

    def __init__(self) -> None:
        self._pools: List[ProxyPool] = []
        self._current_idx: int = 0
        self._lock = _threading.Lock()
        self._pool_iters: dict = {}       # pool_name → itertools.cycle

    # ------------------------------------------------------------------
    def add_pool(self, name: str, raw_lines: str) -> int:
        """Add a named proxy pool. Returns count of parsed proxies."""
        pool = ProxyPool(name=name, raw_lines=raw_lines)
        n = pool.load()
        if n > 0:
            with self._lock:
                self._pools.append(pool)
                self._pool_iters[name] = itertools.cycle(pool.proxies)
            log.info("MultiPool: Added pool '%s' with %d proxies", name, n)
        return n

    def clear_pools(self) -> None:
        with self._lock:
            self._pools.clear()
            self._pool_iters.clear()
            self._current_idx = 0

    def load_from_sections(self, text: str) -> int:
        """
        Parse multi-pool text format:
            [FloppyData Account 1]
            http://user1:pass@host:port

            [FloppyData Account 2]
            http://user2:pass@host:port

        Also supports plain list (no headers) — treated as a single pool.
        Returns total proxy count across all pools.
        """
        self.clear_pools()
        pools_raw: dict = {}
        current_name = "Default Pool"

        for line in text.splitlines():
            line_s = line.strip()
            if not line_s or line_s.startswith("#"):
                continue
            if line_s.startswith("[") and line_s.endswith("]"):
                current_name = line_s[1:-1].strip() or f"Pool {len(pools_raw)+1}"
            else:
                pools_raw.setdefault(current_name, []).append(line_s)

        total = 0
        for name, lines in pools_raw.items():
            total += self.add_pool(name, "\n".join(lines))
        return total

    # ------------------------------------------------------------------
    @property
    def active_pools(self) -> List[ProxyPool]:
        return [p for p in self._pools if p.is_active()]

    @property
    def pool_names(self) -> List[str]:
        return [p.name for p in self._pools]

    @property
    def total_count(self) -> int:
        return sum(len(p.proxies) for p in self._pools if p.is_active())

    @property
    def current_pool_name(self) -> str:
        active = self.active_pools
        if not active:
            return "None"
        idx = min(self._current_idx, len(active) - 1)
        return active[idx].name

    def next_proxy(self) -> Optional[Proxy]:
        """Round-robins within active pool. Skips exhausted pools."""
        with self._lock:
            active = [p for p in self._pools if p.is_active()]
            if not active:
                return None
            self._current_idx = self._current_idx % len(active)
            pool = active[self._current_idx]
            it = self._pool_iters.get(pool.name)
            if not it:
                it = itertools.cycle(pool.proxies)
                self._pool_iters[pool.name] = it
            proxy = next(it)
            return proxy.rotate_session() if proxy.is_residential_dynamic else proxy

    def report_failure(self, proxy: Proxy) -> Optional[str]:
        """
        Call this when a proxy session fails with a connection error
        (ERR_PROXY_CONNECTION_FAILED, data exhausted, 407 auth fail etc.).
        Returns name of new active pool if failover occurred, else None.
        """
        with self._lock:
            for pool in self._pools:
                if any(p.server == proxy.server for p in pool.proxies):
                    pool.failure_count += 1
                    log.warning("MultiPool: Pool '%s' failure #%d", pool.name, pool.failure_count)
                    if pool.failure_count >= pool.FAILURE_THRESHOLD:
                        pool.exhausted = True
                        log.error(
                            "MultiPool: Pool '%s' marked EXHAUSTED (data out or all dead). "
                            "Failing over to next pool...", pool.name
                        )
                        # Advance to next active pool
                        active = [p for p in self._pools if p.is_active()]
                        if active:
                            self._current_idx = 0
                            log.info("MultiPool: ✅ Switched to pool '%s'", active[0].name)
                            return active[0].name
                    break
        return None

    def reset_pool(self, name: str) -> bool:
        """Reset a pool's exhausted state (e.g., after refilling data)."""
        with self._lock:
            for pool in self._pools:
                if pool.name == name:
                    pool.exhausted = False
                    pool.failure_count = 0
                    pool.load()
                    self._pool_iters[name] = itertools.cycle(pool.proxies)
                    log.info("MultiPool: Pool '%s' reset and reloaded.", name)
                    return True
        return False

    def status_summary(self) -> List[dict]:
        return [
            {
                "name": p.name,
                "proxies": len(p.proxies),
                "exhausted": p.exhausted,
                "failures": p.failure_count,
                "active": p.is_active(),
            }
            for p in self._pools
        ]


# Module-level singleton instances
proxy_manager = ProxyManager(config.proxy)
multi_pool_manager = MultiPoolManager()



def _auto_init_proxies() -> None:
    """Auto-load multi_proxies.txt or proxies.txt if available."""
    pfile = config.proxy.proxy_list_file
    if pfile and Path(pfile).exists():
        try:
            text = Path(pfile).read_text(encoding="utf-8")
            if "[" in text and "]" in text:
                cnt = multi_pool_manager.load_from_sections(text)
                log.info("MultiPool: Loaded %d proxies across %d pools from %s",
                         cnt, len(multi_pool_manager.pool_names), pfile)
            else:
                cnt = proxy_manager.load_from_text(text)
                log.info("Loaded %d proxies from %s", cnt, pfile)
            return
        except Exception as e:
            log.warning("Failed loading proxy file %s: %s", pfile, e)

    for fname in ("multi_proxies.txt", "proxies.txt"):
        for root in (getattr(config, "BASE_DIR", Path(".")), Path.cwd()):
            candidate = root / fname
            if candidate.exists():
                try:
                    text = candidate.read_text(encoding="utf-8")
                    if "[" in text and "]" in text:
                        cnt = multi_pool_manager.load_from_sections(text)
                        log.info("MultiPool: Auto-loaded %d proxies across %d pools from %s",
                                 cnt, len(multi_pool_manager.pool_names), candidate)
                    else:
                        cnt = proxy_manager.load_from_text(text)
                        log.info("Auto-loaded %d proxies from %s", cnt, candidate)
                    return
                except Exception as e:
                    log.warning("Failed reading %s: %s", candidate, e)

_auto_init_proxies()
