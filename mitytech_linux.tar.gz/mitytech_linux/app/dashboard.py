"""
dashboard.py – Lightweight local HTTP dashboard and interactive test runner.

Access at: http://127.0.0.1:8765/ or http://localhost:8765/

Provides:
  • Interactive control panel to trigger QA test runs directly from the browser
  • Active / completed / failed session counts
  • Average & percentile load times (W3C Navigation Timing API)
  • Navigation success rate, popup frequency, HTTP error rate
  • Live session history table with detailed diagnostics
  • Emergency STOP button and reset control
"""

from __future__ import annotations

import concurrent.futures
import json
import logging
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs
from pathlib import Path
from typing import Any, Dict, List

from app.config import config
from app.logger import aggregator
from app.metrics import metrics_aggregator
from app.session_manager import SessionRunner

log = logging.getLogger("qa_tester.dashboard")

# Global STOP flag accessible across threads
STOP_EVENT = threading.Event()

# Seed metrics aggregator from any existing loaded reports
for s in aggregator.all():
    if "metrics" in s and isinstance(s["metrics"], dict):
        metrics_aggregator.add_dict(s["metrics"])

_runner_thread: threading.Thread | None = None
_run_status_msg: str = "Ready"


def _background_run(target_url: str, num_sessions: int, workers: int, headless: bool) -> None:
    global _run_status_msg
    STOP_EVENT.clear()
    _run_status_msg = f"Running {num_sessions} sessions across {workers} workers..."
    log.info("Starting background QA run: URL=%s sessions=%d workers=%d headless=%s",
             target_url, num_sessions, workers, headless)

    orig_url = config.target_url
    orig_headless = config.browser.headless
    config.target_url = target_url
    config.browser.headless = headless

    try:
        def _exec_session(idx: int):
            if STOP_EVENT.is_set():
                return None
            _Handler.active_sessions += 1
            try:
                runner = SessionRunner()
                return runner.run()
            finally:
                _Handler.active_sessions = max(0, _Handler.active_sessions - 1)

        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = []
            for i in range(1, num_sessions + 1):
                if STOP_EVENT.is_set():
                    break
                futures.append(executor.submit(_exec_session, i))
                if i < num_sessions:
                    time.sleep(config.session.session_start_gap_s)

            for fut in concurrent.futures.as_completed(futures):
                try:
                    res = fut.result()
                    if res:
                        log.info("Dashboard session completed: %s (%s)", res.session_id[:8], res.status)
                except Exception as exc:
                    log.error("Session failed: %s", exc)

        aggregator.save()
        _run_status_msg = "Completed last run successfully"
    except Exception as exc:
        _run_status_msg = f"Run error: {exc}"
        log.error("Background run error: %s", exc)
    finally:
        config.target_url = orig_url
        config.browser.headless = orig_headless
        _Handler.active_sessions = 0


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>MITY TECH — AUTOMATE · TEST · DOMINATE</title>
<style>
  :root {{
    --bg-dark: #070708;
    --card-bg: #0e0f12;
    --card-border: #202227;
    --accent: #ff1d25;
    --accent-hover: #d4131a;
    --text: #f0f0f2;
    --text-muted: #8c8d91;
    --gold: #d8a23a;
    --success: #00e58a;
    --danger: #ff1d25;
    --warning: #f59e0b;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin: 0;
    background: var(--bg-dark);
    color: var(--text);
    line-height: 1.5;
  }}
  header {{
    background: #090a0d;
    border-bottom: 1px solid var(--card-border);
    padding: 1rem 2.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 1rem;
  }}
  .logo {{
    display: flex;
    align-items: center;
    gap: 1rem;
    font-size: 1.35rem;
    font-weight: 900;
    letter-spacing: 1.5px;
    color: #fff;
    text-transform: uppercase;
  }}
  .logo span.cartel {{ color: var(--accent); }}
  .target-badge {{
    background: #141518;
    border: 1px solid var(--card-border);
    color: var(--gold);
    font-size: 0.8rem;
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-family: monospace;
  }}
  .quote-strip {{
    background: linear-gradient(90deg, rgba(255,29,37,0.12) 0%, transparent 100%);
    border-left: 3px solid var(--accent);
    padding: 0.6rem 1.25rem;
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
    color: var(--text-muted);
    font-style: italic;
  }}
  .quote-strip span {{ color: var(--gold); font-weight: bold; font-style: normal; }}
  main {{
    padding: 1.5rem 2.5rem;
    max-width: 1440px;
    margin: 0 auto;
  }}
  .controls-panel {{
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: 0.75rem;
    padding: 1.25rem 1.5rem;
    margin-bottom: 1.5rem;
  }}
  .controls-panel h3 {{
    margin: 0 0 1rem 0;
    font-size: 1rem;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    letter-spacing: 1px;
    text-transform: uppercase;
  }}
  .runner-form {{
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    align-items: flex-end;
  }}
  .form-group {{
    display: flex;
    flex-direction: column;
    gap: 0.35rem;
  }}
  .form-group label {{
    font-size: 0.75rem;
    font-weight: 700;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }}
  .form-group input[type="text"],
  .form-group input[type="number"] {{
    background: #070708;
    border: 1px solid var(--card-border);
    color: var(--text);
    padding: 0.5rem 0.75rem;
    border-radius: 0.375rem;
    font-size: 0.9rem;
  }}
  .form-group input:focus {{
    border-color: var(--accent);
    outline: none;
  }}
  .checkbox-group {{
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding-bottom: 0.5rem;
    font-size: 0.85rem;
    color: var(--text-muted);
    cursor: pointer;
  }}
  .btn {{
    padding: 0.55rem 1.25rem;
    border-radius: 0.375rem;
    border: none;
    font-weight: 700;
    font-size: 0.85rem;
    cursor: pointer;
    transition: all 0.15s ease;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    letter-spacing: 0.5px;
    text-transform: uppercase;
  }}
  .btn-primary {{
    background: var(--accent);
    color: #fff;
  }}
  .btn-primary:hover {{
    background: var(--accent-hover);
    box-shadow: 0 0 15px rgba(255,29,37,0.4);
  }}
  .btn-danger {{
    background: #1c1d22;
    border: 1px solid #383a42;
    color: #fff;
  }}
  .btn-danger:hover {{
    background: var(--danger);
  }}
  .btn-secondary {{
    background: #141518;
    border: 1px solid var(--card-border);
    color: var(--text-muted);
  }}
  .btn-secondary:hover {{
    background: #1f2127;
    color: #fff;
  }}
  .grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 1.5rem;
  }}
  .card {{
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: 0.75rem;
    padding: 1.25rem;
    position: relative;
  }}
  .card::before {{
    content: "";
    position: absolute;
    top: 0; left: 0; right: 0; height: 2px;
    background: var(--accent);
  }}
  .card h2 {{
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-muted);
    margin: 0 0 0.5rem;
  }}
  .card .val {{
    font-size: 1.85rem;
    margin: 0;
    font-weight: 900;
    font-family: monospace;
    color: #fff;
  }}
  .card.ok .val {{ color: var(--success); }}
  .card.warn .val {{ color: var(--warning); }}
  .card.err .val {{ color: var(--danger); }}
  .pulse {{
    animation: pulse-anim 1.5s infinite;
  }}
  @keyframes pulse-anim {{
    0% {{ opacity: 1; }}
    50% {{ opacity: 0.4; }}
    100% {{ opacity: 1; }}
  }}
  .section-title {{
    color: var(--text-muted);
    font-size: 0.875rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin: 1.5rem 0 0.75rem;
    font-weight: 700;
  }}
  .table-wrap {{
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: 0.75rem;
    overflow-x: auto;
    margin-bottom: 1.5rem;
  }}
  table {{
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
  }}
  th {{
    background: #090a0d;
    color: var(--text-muted);
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    padding: 0.75rem 1rem;
    text-align: left;
    border-bottom: 1px solid var(--card-border);
  }}
  td {{
    padding: 0.65rem 1rem;
    border-bottom: 1px solid #16171b;
  }}
  tr:last-child td {{
    border-bottom: none;
  }}
  .perf-table td:nth-child(n+2) {{
    font-family: monospace;
    color: #e2e8f0;
  }}
  .badge {{
    display: inline-block;
    padding: 0.2rem 0.5rem;
    border-radius: 4px;
    font-size: 0.7rem;
    font-weight: 700;
    text-transform: uppercase;
  }}
  .badge.passed {{ background: rgba(0, 229, 138, 0.15); color: var(--success); border: 1px solid rgba(0, 229, 138, 0.3); }}
  .badge.failed, .badge.error {{ background: rgba(255, 29, 37, 0.15); color: var(--danger); border: 1px solid rgba(255, 29, 37, 0.3); }}
  .status-tag {{
    font-size: 0.8rem;
    padding: 0.25rem 0.6rem;
    border-radius: 0.375rem;
    background: #141518;
    border: 1px solid var(--card-border);
  }}
</style>
<script>
  const isActive = {is_active};
  setTimeout(() => {{
    window.location.reload();
  }}, isActive ? 3000 : 10000);
</script>
</head>
<body>
<header>
  <div class="logo">
    <span>👑 MITY <span class="cartel">TECH</span></span>
    <span class="target-badge">{target}</span>
  </div>
  <div style="display:flex; align-items:center; gap:0.75rem;">
    <form method="POST" action="/stop" style="margin:0">
      <button class="btn btn-danger" onclick="return confirm('Stop all active test sessions?')">⏹ STOP OPERATION</button>
    </form>
    <form method="POST" action="/reset-stop" style="margin:0">
      <button class="btn btn-secondary" title="Reset STOP flag">↺ RESET</button>
    </form>
  </div>
</header>
<main>
  <div class="quote-strip">
    “ Speed. Precision. Viewability. ” — <span>MITY TECH</span>
  </div>
  <!-- Interactive Test Runner Panel -->
  <div class="controls-panel">
    <h3>
      <span>▶ LAUNCH OPERATION</span>
      <span class="status-tag" style="{status_color}">Status: {run_status}</span>
    </h3>
    <form method="POST" action="/run" class="runner-form">
      <div class="form-group" style="flex: 2; min-width: 250px;">
        <label>Target Website URL</label>
        <input type="text" name="url" value="{target}" required />
      </div>
      <div class="form-group" style="width: 110px;">
        <label>Sessions</label>
        <input type="number" name="sessions" value="20" min="1" max="1000" required />
      </div>
      <div class="form-group" style="width: 110px;">
        <label>Workers</label>
        <input type="number" name="workers" value="20" min="1" max="20" required />
      </div>
      <div class="form-group" style="justify-content: flex-end;">
        <label class="checkbox-group">
          <input type="checkbox" name="headless" checked />
          Headless Mode
        </label>
      </div>
      <button type="submit" class="btn btn-primary" style="height: 38px;">▶ START TEST RUN</button>
    </form>
  </div>

  <!-- Key Metrics Grid -->
  <div class="grid">
    <div class="card {active_pulse}"><h2>Active Sessions</h2><p class="val">{active}</p></div>
    <div class="card ok"><h2>Completed Runs</h2><p class="val">{completed}</p></div>
    <div class="card err"><h2>Failed Runs</h2><p class="val">{failed}</p></div>
    <div class="card"><h2>Avg Load Time</h2><p class="val">{avg_load}ms</p></div>
    <div class="card"><h2>p95 Load Time</h2><p class="val">{p95_load}ms</p></div>
    <div class="card"><h2>Avg TTFB</h2><p class="val">{avg_ttfb}ms</p></div>
    <div class="card"><h2>Nav Success Rate</h2><p class="val">{nav_rate}%</p></div>
    <div class="card warn"><h2>Popups Detected</h2><p class="val">{popups}</p></div>
    <div class="card err"><h2>HTTP Errors</h2><p class="val">{http_errors}</p></div>
  </div>

  <!-- Detailed Performance Timing Percentiles -->
  <div class="section-title">W3C Navigation & Paint Timing Percentiles (ms)</div>
  <div class="table-wrap">
    <table class="perf-table">
      <thead>
        <tr><th>Metric Milestone</th><th>Mean</th><th>p50 (Median)</th><th>p75</th><th>p90</th><th>p95</th><th>p99</th></tr>
      </thead>
      <tbody>
        {perf_rows}
      </tbody>
    </table>
  </div>

  <!-- Session Test History -->
  <div class="section-title">Completed Test Sessions</div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Session ID</th>
          <th>Status</th>
          <th>Viewport</th>
          <th>Load Time</th>
          <th>TTFB</th>
          <th>DCL</th>
          <th>Actions</th>
          <th>Popups</th>
          <th>HTTP Errs</th>
          <th>Duration</th>
        </tr>
      </thead>
      <tbody>
        {session_rows}
      </tbody>
    </table>
  </div>
</main>
</body>
</html>"""


def _build_html(active_count: int) -> str:
    summaries = aggregator.all()
    completed = [s for s in summaries if s.get("status") == "passed"]
    failed = [s for s in summaries if s.get("status") in ("failed", "error")]

    perf = metrics_aggregator.summary()
    avg_load = perf.get("load_event_ms", {}).get("mean", "-")
    p95_load = perf.get("load_event_ms", {}).get("p95", "-")
    avg_ttfb = perf.get("ttfb_ms", {}).get("mean", "-")

    total_actions = sum(s.get("interaction_summary", {}).get("total_actions", 0) for s in summaries)
    passed_actions = sum(s.get("interaction_summary", {}).get("passed", 0) for s in summaries)
    nav_rate = round(passed_actions / total_actions * 100, 1) if total_actions else "-"

    total_popups = sum(len(s.get("popup_events", [])) for s in summaries)
    total_http_errors = sum(len(s.get("http_errors", [])) for s in summaries)

    METRIC_LABELS = {
        "dns_ms": "DNS Lookup",
        "tcp_connect_ms": "TCP Connection",
        "tls_ms": "TLS Handshake",
        "ttfb_ms": "Time to First Byte (TTFB)",
        "dom_content_loaded_ms": "DOMContentLoaded (DCL)",
        "load_event_ms": "Page Load Event",
        "first_contentful_paint_ms": "First Contentful Paint (FCP)",
        "total_wall_clock_ms": "Total Wall Clock",
    }
    perf_rows = ""
    for key, label in METRIC_LABELS.items():
        d = perf.get(key, {})
        if not d:
            continue
        perf_rows += (
            f"<tr><td><strong>{label}</strong></td>"
            f"<td>{d.get('mean','-')}</td>"
            f"<td>{d.get('median','-')}</td>"
            f"<td>{d.get('p75','-')}</td>"
            f"<td>{d.get('p90','-')}</td>"
            f"<td>{d.get('p95','-')}</td>"
            f"<td>{d.get('p99','-')}</td></tr>"
        )

    session_rows = ""
    for i, s in enumerate(reversed(summaries[-30:]), 1):
        sid = s.get("session_id", "")[:8]
        status = s.get("status", "unknown")
        m = s.get("metrics", {})
        load_ms = m.get("load_event_ms", "-")
        ttfb_ms = m.get("ttfb_ms", "-")
        dcl_ms = m.get("dom_content_loaded_ms", "-")
        ia = s.get("interaction_summary", {})
        actions = f"{ia.get('passed', 0)}/{ia.get('total_actions', 0)}"
        popups = len(s.get("popup_events", []))
        errs = len(s.get("http_errors", []))
        dur = s.get("duration_s", "-")
        vp = s.get("viewport_label", "-")
        badge = f'<span class="badge {status}">{status}</span>'
        session_rows += (
            f"<tr><td>{i}</td><td style='font-family:monospace'>{sid}</td>"
            f"<td>{badge}</td><td>{vp}</td><td>{load_ms}ms</td><td>{ttfb_ms}ms</td><td>{dcl_ms}ms</td>"
            f"<td>{actions}</td><td>{popups}</td><td>{errs}</td><td>{dur}s</td></tr>"
        )
    if not session_rows:
        session_rows = "<tr><td colspan='11' style='text-align:center;color:#64748b;padding:2rem;'>No sessions recorded yet. Launch a test run above.</td></tr>"

    status_color = "color: #4ade80;" if "Completed" in _run_status_msg else ("color: #38bdf8;" if active_count > 0 else "color: #94a3b8;")

    return _HTML_TEMPLATE.format(
        target=config.target_url,
        active=active_count,
        active_pulse="pulse" if active_count > 0 else "",
        is_active="true" if active_count > 0 else "false",
        run_status=_run_status_msg,
        status_color=status_color,
        completed=len(completed),
        failed=len(failed),
        avg_load=avg_load,
        p95_load=p95_load,
        avg_ttfb=avg_ttfb,
        nav_rate=nav_rate,
        popups=total_popups,
        http_errors=total_http_errors,
        perf_rows=perf_rows or "<tr><td colspan='7' style='color:#64748b;text-align:center;'>No telemetry data collected yet</td></tr>",
        session_rows=session_rows,
    )


class _Handler(BaseHTTPRequestHandler):
    active_sessions = 0

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/assets/"):
            import mimetypes
            rel_path = self.path.lstrip("/").split("?")[0]
            file_path = Path(__file__).resolve().parent.parent / rel_path
            if file_path.is_file():
                ctype, _ = mimetypes.guess_type(str(file_path))
                ctype = ctype or "application/octet-stream"
                try:
                    data = file_path.read_bytes()
                    self._respond(200, ctype, data)
                    return
                except Exception:
                    pass
            self._respond(404, "text/plain", b"Asset Not Found")
            return

        if self.path == "/api/status":
            self._json({
                "active_sessions": self.__class__.active_sessions,
                "status_message": _run_status_msg,
                "stop_event": STOP_EVENT.is_set(),
                "recent_sessions": aggregator.all()[-20:],
                "metrics_summary": metrics_aggregator.summary(),
            })
        else:
            html = _build_html(self.__class__.active_sessions)
            self._respond(200, "text/html; charset=utf-8", html.encode("utf-8"))

    def do_POST(self) -> None:  # noqa: N802
        global _runner_thread, _run_status_msg
        if self.path == "/run":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8")
            params = parse_qs(body)

            target_url = params.get("url", [config.target_url])[0]
            sessions = int(params.get("sessions", [3])[0])
            workers = int(params.get("workers", [2])[0])
            headless = "headless" in params

            if _runner_thread and _runner_thread.is_alive():
                _run_status_msg = "A run is already in progress!"
            else:
                _runner_thread = threading.Thread(
                    target=_background_run,
                    args=(target_url, sessions, workers, headless),
                    daemon=True,
                )
                _runner_thread.start()

            self.send_response(302)
            self.send_header("Location", "/")
            self.end_headers()

        elif self.path == "/stop":
            STOP_EVENT.set()
            _run_status_msg = "EMERGENCY STOP TRIGGERED"
            log.warning("EMERGENCY STOP triggered via dashboard!")
            self.send_response(302)
            self.send_header("Location", "/")
            self.end_headers()

        elif self.path == "/reset-stop":
            STOP_EVENT.clear()
            _run_status_msg = "Ready (STOP flag cleared)"
            self.send_response(302)
            self.send_header("Location", "/")
            self.end_headers()

        else:
            self._respond(404, "text/plain", b"Not found")

    def _json(self, obj: Any) -> None:
        body = json.dumps(obj, indent=2).encode("utf-8")
        self._respond(200, "application/json", body)

    def _respond(self, status: int, ct: str, body: bytes) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: Any) -> None:  # noqa: N802
        pass


_server: HTTPServer | None = None
_thread: threading.Thread | None = None


def start_dashboard() -> None:
    global _server, _thread
    if not config.dashboard.enabled:
        return
    _server = HTTPServer((config.dashboard.host, config.dashboard.port), _Handler)
    _thread = threading.Thread(target=_server.serve_forever, daemon=True)
    _thread.start()
    log.info(
        "Dashboard running at http://%s:%d",
        config.dashboard.host,
        config.dashboard.port,
    )


def stop_dashboard() -> None:
    if _server:
        _server.shutdown()


def set_active_count(n: int) -> None:
    _Handler.active_sessions = n


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    host = config.dashboard.host
    port = config.dashboard.port
    print("=" * 60)
    print(f"  Starting QA Dashboard server on http://{host}:{port}/")
    print(f"  Target: {config.target_url}")
    print("  Press Ctrl+C to terminate.")
    print("=" * 60)
    server = HTTPServer((host, port), _Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
        server.shutdown()
