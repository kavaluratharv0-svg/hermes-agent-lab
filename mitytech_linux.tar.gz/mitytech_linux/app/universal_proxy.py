"""
universal_proxy.py – Universal Proxy Parser, Format Detector, and Fast Concurrent Verifier.

Supported Formats:
  1. ip:port:user:pass
  2. user:pass@ip:port
  3. user:pass:ip:port
  4. ip:port
  5. protocol://user:pass@ip:port (http, https, socks4, socks5)
  6. protocol://ip:port:user:pass
  7. Domain/host gateways (e.g. resi.floppydata.com:8000:usr:pwd)
"""

from __future__ import annotations

import concurrent.futures
import re
import socket
import urllib.request
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple


@dataclass
class ParsedProxy:
    raw: str
    protocol: str       # "http", "socks5", "socks4"
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    latency_ms: float = 0.0
    is_alive: bool = False
    exit_ip: Optional[str] = None
    error: Optional[str] = None

    def to_playwright_dict(self) -> dict:
        """Converts to Playwright proxy configuration dictionary."""
        d = {"server": f"{self.protocol}://{self.host}:{self.port}"}
        if self.username:
            d["username"] = self.username
        if self.password:
            d["password"] = self.password
        return d

    def to_standard_string(self) -> str:
        """Returns standard host:port:user:pass or host:port."""
        if self.username and self.password:
            return f"{self.host}:{self.port}:{self.username}:{self.password}"
        return f"{self.host}:{self.port}"

    def to_url_string(self) -> str:
        """Returns protocol://user:pass@host:port."""
        if self.username and self.password:
            return f"{self.protocol}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{self.protocol}://{self.host}:{self.port}"


def parse_proxy_line(line: str, default_protocol: str = "http") -> Optional[ParsedProxy]:
    """
    Intelligently parses any proxy format into a structured ParsedProxy object.
    """
    raw = line.strip()
    if not raw or raw.startswith("#"):
        return None

    proto = default_protocol
    work = raw

    # 1. Detect protocol scheme prefix if present
    if "://" in work:
        parts = work.split("://", 1)
        scheme = parts[0].lower()
        if scheme in ("http", "https", "socks4", "socks5"):
            proto = "http" if scheme == "https" else scheme
        work = parts[1]

    # 2. Check for user:pass@host:port format
    if "@" in work:
        creds, hostport = work.rsplit("@", 1)
        usr, pwd = (creds.split(":", 1) + [""])[:2]
        hp = hostport.split(":", 1)
        if len(hp) == 2 and hp[1].isdigit():
            return ParsedProxy(
                raw=raw,
                protocol=proto,
                host=hp[0].strip(),
                port=int(hp[1]),
                username=usr.strip() or None,
                password=pwd.strip() or None,
            )

    # 3. Colon-separated tokens (e.g. host:port or host:port:usr:pwd or usr:pwd:host:port)
    tokens = [t.strip() for t in work.split(":") if t.strip()]

    if len(tokens) == 2:
        # host:port
        if tokens[1].isdigit():
            return ParsedProxy(raw=raw, protocol=proto, host=tokens[0], port=int(tokens[1]))

    elif len(tokens) == 4:
        # Check if 2nd token is port: host:port:user:pass
        if tokens[1].isdigit():
            return ParsedProxy(
                raw=raw,
                protocol=proto,
                host=tokens[0],
                port=int(tokens[1]),
                username=tokens[2],
                password=tokens[3],
            )
        # Check if 4th token is port: user:pass:host:port
        elif tokens[3].isdigit():
            return ParsedProxy(
                raw=raw,
                protocol=proto,
                host=tokens[2],
                port=int(tokens[3]),
                username=tokens[0],
                password=tokens[1],
            )

    return None


def parse_proxy_text(text: str) -> List[ParsedProxy]:
    """Parses a multi-line string containing proxies in any mixed formats."""
    proxies: List[ParsedProxy] = []
    for line in text.strip().splitlines():
        p = parse_proxy_line(line)
        if p:
            proxies.append(p)
    return proxies


def test_single_proxy(proxy: ParsedProxy, timeout_s: float = 6.0) -> ParsedProxy:
    """
    Tests proxy connectivity (HTTP, HTTPS, SOCKS5) and measures latency against an IP endpoint.
    """
    import time
    import httpx
    start_t = time.monotonic()
    try:
        proxy_url = proxy.to_url_string()
        with httpx.Client(proxy=proxy_url, timeout=timeout_s, follow_redirects=True) as client:
            resp = client.get("https://api.ipify.org?format=text")
            if resp.status_code == 200 and resp.text.strip():
                proxy.latency_ms = round((time.monotonic() - start_t) * 1000, 1)
                proxy.is_alive = True
                proxy.exit_ip = resp.text.strip()
                proxy.error = None
                return proxy
    except Exception:
        pass

    # Fallback: check TCP socket handshake to verify host and port are reachable
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout_s)
        s.connect((proxy.host, proxy.port))
        s.close()
        proxy.latency_ms = round((time.monotonic() - start_t) * 1000, 1)
        proxy.is_alive = True
        proxy.exit_ip = "TCP Connected"
        proxy.error = None
    except Exception as exc:
        proxy.latency_ms = 0.0
        proxy.is_alive = False
        proxy.error = str(exc)

    return proxy


def verify_proxy_pool(
    proxies: List[ParsedProxy],
    max_workers: int = 15,
    timeout_s: float = 6.0,
    progress_callback: Optional[Callable[[int, int, ParsedProxy], None]] = None,
) -> Tuple[List[ParsedProxy], List[ParsedProxy]]:
    """
    Concurrently tests all proxies in the list.
    Returns: (working_proxies, dead_proxies)
    """
    working: List[ParsedProxy] = []
    dead: List[ParsedProxy] = []
    total = len(proxies)
    completed = 0

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(test_single_proxy, p, timeout_s): p for p in proxies}
        for f in concurrent.futures.as_completed(futures):
            res = f.result()
            completed += 1
            if res.is_alive:
                working.append(res)
            else:
                dead.append(res)
            if progress_callback:
                progress_callback(completed, total, res)

    return working, dead
