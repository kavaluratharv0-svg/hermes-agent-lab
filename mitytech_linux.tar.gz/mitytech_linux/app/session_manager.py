"""
session_manager.py – Orchestrates a single end-to-end QA test session.

Responsibilities:
  • Launch an isolated browser via browser_manager.
  • Navigate to the target URL and collect performance metrics.
  • Handle unexpected popups / new tabs (record and close them).
  • Run the bounded QA interaction sequence.
  • Wait for the configured post-load observation window.
  • Save structured logs and return a session summary.
"""

from __future__ import annotations

import logging
import random
import re
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from playwright.sync_api import Page, TimeoutError as PWTimeout

from app.browser_manager import isolated_browser, IsolatedContext
from app.config import config
from app.interaction_engine import InteractionEngine
from app.logger import EventType, SessionLogger, aggregator
from app.metrics import collect_metrics, PageTimingMetrics, metrics_aggregator
from app.proxy_manager import proxy_manager, multi_pool_manager

import threading

# Master CPM Ad-Network and Smartlink Whitelist
SMARTLINK_ALLOWED_HOSTS = [
    # Primary & direct smartlink chains
    "adsterra.com", "profitableratecpmnetwork.com", "auctionr.org",
    "thewilddetail.com", "astrotechin.com", "go.oclasrv.com",
    "entimanc.com", "cleverads.com", "acint.net", "d3ifqyao6a3xvr.cloudfront.net",
    # Demand-side partners & impression beacons (The Trade Desk, Google, Magnite, etc.)
    "adsrvr.org", "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "rubiconproject.com", "pubmatic.com", "openx.net", "appnexus.com", "ib.adnxs.com",
    "serving-sys.com", "criteo.com", "criteo.net", "casalemedia.com", "smartadserver.com",
    "3lift.com", "sharethrough.com", "yahoo.com", "advertising.com", "yieldmanager.com",
    "demdex.net", "bluekai.com", "exelator.com", "taboola.com", "outbrain.com", "mgid.com",
    "evadav.com", "trafficstars.com", "hilltopads.net", "juicyads.com", "traffichunt.com",
    "propellerads.com", "megapu.sh", "pushground.com", "richpush.co", "zeropark.com",
    "exoclick.com", "trafficjunky.com", "ero-advertising.com", "trafficholder.com",
    "leadbit.com", "cpamatica.io", "admaven.com", "plugrush.com", "adspyglass.com",
    "pops.one", "popads.net", "cloudfront.net"
]

_url_index = 0
_url_lock = threading.Lock()

def get_next_target_url() -> str:
    """Thread-safe round-robin rotator across all configured smartlinks."""
    global _url_index
    with _url_lock:
        urls = [u.strip() for u in config.target_urls if u.strip() and not u.strip().startswith("#")]
        if not urls:
            return config.target_url or "https://auctionr.org/4/96531197dc37f1245940f172b5e5fa40"
        chosen = urls[_url_index % len(urls)]
        _url_index += 1
        return chosen

log = logging.getLogger("qa_tester.session")

# In-memory cache of static Cloudflare Turnstile & Google reCAPTCHA assets (shared across sessions)
_CF_STATIC_CACHE: dict = {}

def _prewarm_static_cache() -> None:
    try:
        import urllib.request
        _urls = [
            "https://www.gstatic.com/recaptcha/releases/guXhH0v-XMxlzmbTwqkaT4i5/recaptcha__en.js",
        ]
        for u in _urls:
            _ck = u.split("?")[0]
            if _ck not in _CF_STATIC_CACHE:
                req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
                with urllib.request.urlopen(req, timeout=5) as resp:
                    b = resp.read()
                    hdrs = {"content-type": resp.headers.get("content-type", "application/javascript")}
                    _CF_STATIC_CACHE[_ck] = (200, hdrs, b)
    except Exception:
        pass

import threading
threading.Thread(target=_prewarm_static_cache, daemon=True).start()


# ---------------------------------------------------------------------------
# Human-like mobile touch behavior engine
# ---------------------------------------------------------------------------
def _mobile_human_behavior(page: Page, duration_s: float, is_mobile: bool = True) -> None:
    """
    Simulate realistic human behavior for the given duration.

    Mobile (98% of sessions):
      - Touch swipe scrolling (how real phone users scroll)
      - Read pauses between scrolls (humans stop to read)
      - Occasional tap on non-ad page area (natural touch habit)
      - Variable scroll speed and distance (no two users identical)

    Desktop (2% fallback):
      - Natural mouse drift + micro-pauses
    """
    deadline = time.monotonic() + duration_s
    try:
        vw = page.evaluate("window.innerWidth")  or 390
        vh = page.evaluate("window.innerHeight") or 844
    except Exception:
        vw, vh = 390, 844

    if is_mobile:
        # ── Mobile touch behavior ──────────────────────────────────────────
        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 0.3:
                break

            action = random.choices(
                ["swipe_down", "swipe_up", "read_pause", "tap"],
                weights=[50, 15, 30, 5],
                k=1
            )[0]

            if action == "swipe_down":
                # Swipe up = scroll content down (reading further)
                swipe_dist = random.randint(150, 500)
                sx = random.randint(vw // 4, 3 * vw // 4)
                try:
                    page.touchscreen.tap(sx, random.randint(int(vh * 0.4), int(vh * 0.6)))
                    page.evaluate(
                        f"window.scrollBy({{top: {swipe_dist}, behavior: 'smooth'}});"
                    )
                except Exception:
                    pass
                pause = min(remaining - 0.1, random.uniform(0.8, 3.5))
                time.sleep(max(0.1, pause))

            elif action == "swipe_up":
                # Scroll back up a little (re-reading)
                scroll_back = random.randint(60, 250)
                try:
                    page.evaluate(
                        f"window.scrollBy({{top: -{scroll_back}, behavior: 'smooth'}});"
                    )
                except Exception:
                    pass
                time.sleep(min(remaining - 0.1, random.uniform(0.5, 1.5)))

            elif action == "read_pause":
                # Just reading — no movement (very human)
                pause = min(remaining - 0.1, random.uniform(1.0, 4.0))
                time.sleep(max(0.1, pause))

            elif action == "tap":
                # Tap a safe content area (not on ads)
                tx = random.randint(int(vw * 0.1), int(vw * 0.9))
                ty = random.randint(int(vh * 0.2), int(vh * 0.7))
                try:
                    page.touchscreen.tap(tx, ty)
                except Exception:
                    pass
                time.sleep(min(remaining - 0.1, random.uniform(0.3, 1.0)))

    else:
        # ── Desktop mouse fallback (2% of sessions) ────────────────────────
        cx = random.randint(vw // 4, 3 * vw // 4)
        cy = random.randint(vh // 4, 3 * vh // 4)
        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 0.1:
                break
            cx = max(20, min(vw - 20, cx + random.randint(-120, 120)))
            cy = max(20, min(vh - 20, cy + random.randint(-80, 80)))
            try:
                page.mouse.move(cx, cy, steps=random.randint(4, 12))
            except Exception:
                pass
            time.sleep(max(0.05, min(remaining, random.uniform(0.8, 2.5))))


def _ad_mouse_activity(page: Page, duration_s: float) -> None:
    """Delegates to mobile touch engine — auto-detects mobile vs desktop."""
    try:
        is_mob = bool(page.evaluate("navigator.maxTouchPoints > 0"))
    except Exception:
        is_mob = True  # default mobile since 98% of sessions are mobile
    _mobile_human_behavior(page, duration_s, is_mobile=is_mob)


# ---------------------------------------------------------------------------
@dataclass
class SessionResult:
    session_id: str
    status: str                  # "passed" | "failed" | "error"
    target_url: str
    start_time: str
    end_time: str
    duration_s: float
    viewport_label: str
    locale: str
    timezone: str
    proxy_used: Optional[str]
    referrer_used: Optional[str] = None
    referrer: Optional[str] = None
    geo_info: Dict[str, Any] = field(default_factory=dict)   # IP + location data
    metrics: Dict[str, Any] = field(default_factory=dict)
    interaction_summary: Dict[str, Any] = field(default_factory=dict)
    popup_events: List[Dict] = field(default_factory=list)
    new_tab_events: List[Dict] = field(default_factory=list)
    http_errors: List[Dict] = field(default_factory=list)
    error_message: Optional[str] = None
    browser_version: str = ""
    log_files: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
class SessionRunner:
    """Runs a single isolated QA test session."""

    # Byte cap per session — abort if exceeded (stops infinite CF-loop runaway on dirty IPs)
    _BYTE_CAP = 1536 * 1024   # 1.5 MB: ensures complete Cloudflare handshake & Turnstile solve

    def __init__(self, session_id: Optional[str] = None) -> None:
        self.session_id = session_id or str(uuid.uuid4())
        self._slog = SessionLogger(self.session_id)
        self._http_errors: List[Dict] = []
        self._popup_events: List[Dict] = []
        self._new_tab_events: List[Dict] = []
        # Proxy bandwidth tracking
        self._bytes_down: int = 0   # response bytes received through proxy
        self._bytes_up: int = 0     # request bytes sent through proxy
        self._req_count: int = 0    # total requests proxied
        # Anti-runaway guards
        self._cf_pat_failures: int = 0   # counts Cloudflare PAT challenge responses
        self._byte_cap_hit: bool = False  # set True when _BYTE_CAP is exceeded
        self._ouo_destination_url: Optional[str] = None  # tracks ouo redirect destination
        # OUO verification ground-truth — what actually went over the wire
        self._ouo_step1_token_len: int = 0   # cf-turnstile-response length in step-1 POST
        self._ouo_post_token_len: int = 0    # x-token length in the /go/ POST
        self._ouo_post_seen: bool = False     # did any ouo POST fire at all
        self._ouo_getlink_post_seen: bool = False  # xreallcygo (GET-LINK) POST fired — the credit event
        self._ouo_step2_clicked: bool = False
        self._ouo_posts: list = []            # wire record: every ouo POST (url/body_len/tokens)
        self._ouo_post_status: list = []       # response status of each ouo POST (302=accepted)
        self._ouo_hosts: list = []            # hosts of challenge/adscore requests actually fetched
        self._cf_interactive: bool = False    # CF interactive challenge = flagged IP, rotate early
        self._ouo_turnstile_dom: dict = {}    # step-1 turnstile widget/input/api state

    # ------------------------------------------------------------------
    # Popup / new-tab guard
    # ------------------------------------------------------------------
    def _install_popup_handler(self, main_page: Page) -> None:
        """
        Handle popup / new-tab windows opened by the page.

        Behaviour:
          - All popups (including ads) are ALLOWED to open and fully load.
          - Each popup is visited briefly (1–5 seconds, random) — just like a human
            who glances at a new tab before going back.
          - Popup is then closed and focus is returned to the main page.
          - Every popup event is logged for QA reporting.
        """

        def _handle_popup(popup: Page) -> None:
            # ══ OUO.IO MODE: popunder ads — kill subresources, close fast, save proxy data ══
            # NOTE: a popunder URL is an AD chain, never the ouo destination — capturing
            # it here made stuck sessions look successful while ouo credited nothing.
            if config.traffic.is_ouo_io_mode():
                try:
                    popup.route("**/*", lambda _r, _q: _r.abort())
                except Exception:
                    pass
                try:
                    time.sleep(0.15)
                    popup.close()
                except Exception:
                    pass
                return

            # ══ MOTTO: ALL ADS IMPRESSION · ALL CLICKS COUNT ══
            # Let popup load fully — ad scripts fire during load
            url = "about:blank"
            try:
                popup.wait_for_load_state("domcontentloaded", timeout=10000)
                url = popup.url or "about:blank"
            except Exception:
                try:
                    url = popup.url or "about:blank"
                except Exception:
                    pass

            event = {
                "url": url,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self._slog.record(EventType.NEW_TAB, {**event, "type": "popup_opened"})
            self._new_tab_events.append(event)

            # Stay longer on popup — viewability timer must tick (3–8s)
            # Ad impression is counted AFTER the ad is visible for 1+ second
            stay_s = random.uniform(3.0, 8.0)
            log.info("[%s] 🪟 Popup: %s — staying %.1fs (ad impression window)",
                     self.session_id[:8], url[:60], stay_s)

            try:
                # Bring popup to front (viewability = active tab required)
                popup.bring_to_front()
                # Above-fold dwell (ads load here)
                time.sleep(min(stay_s * 0.4, 3.0))
                # Scroll down to reveal below-fold ads
                try:
                    popup.evaluate("window.scrollBy({top: 300, behavior: 'smooth'});")
                except Exception:
                    pass
                # Remaining dwell
                time.sleep(max(0.5, stay_s - stay_s * 0.4))
            except Exception:
                time.sleep(stay_s)

            # Close popup
            try:
                popup.close()
                self._slog.record(EventType.NEW_TAB_CLOSED, {"url": url, "stayed_s": round(stay_s, 2)})
            except Exception:
                pass

            # Return focus to main page
            try:
                main_page.bring_to_front()
            except Exception:
                pass

        main_page.on("popup", _handle_popup)


    # ------------------------------------------------------------------
    # HTTP error monitoring + bandwidth tracking
    # ------------------------------------------------------------------
    def _install_response_handler(self, page: Page) -> None:
        def _on_request(request) -> None:
            try:
                url = request.url
                # In OUO mode, don't count aborted ads, PAT, fonts, or RAM-cached requests as proxy upload
                if config.traffic.is_ouo_io_mode():
                    _u = url.split("?")[0]
                    if _u in _CF_STATIC_CACHE:
                        return
                    # ANY platform PAT endpoint (h/b, h/g, h/a …) — huge attestation bodies
                    if ("challenge-platform" in url and "/pat/" in url) or \
                       any(p in url for p in ("recaptcha/api2/pat", "email-decode", "beacon.min.js")):
                        return
                    if not any(d in url for d in ("ouo.io", "ouo.press", "challenges.cloudflare.com", "google.com/recaptcha", "recaptcha.net", "gstatic.com")):
                        return
                    if request.resource_type in ("image", "stylesheet", "font", "media"):
                        return

                # Count request bytes: headers are ~200-600 bytes + body
                body_len = 0
                try:
                    pb = request.post_data_buffer
                    if pb:
                        body_len = len(pb)
                except Exception:
                    pass
                # Rough header overhead estimate (method + URL + headers ~400 bytes avg)
                self._bytes_up += body_len + 400
                self._req_count += 1
            except Exception:
                pass

        def _on_response(response) -> None:
            # ── bandwidth counting ──────────────────────────────────────
            try:
                _resp_url = response.request.url

                # In OUO mode, track destination — MAIN FRAME NAVIGATION ONLY.
                # Child-frame docs, ad-beacon 302s and 204 pings are ad chain noise:
                # treating them as "destination" logged stuck sessions as PASSED
                # while ouo never processed a verified Get-Link POST (0 views).
                if config.traffic.is_ouo_io_mode():
                    try:
                        _req0 = response.request
                        _is_main_nav = False
                        try:
                            _is_main_nav = bool(_req0.is_navigation_request() and _req0.frame == page.main_frame)
                        except Exception:
                            _is_main_nav = False
                        if _is_main_nav:
                            if response.status in (301, 302, 303, 307, 308):
                                loc = response.headers.get("location")
                                if loc and not any(d in loc for d in ("ouo.io", "ouo.press", "fonts.googleapis", "fonts.gstatic")):
                                    self._ouo_destination_url = loc
                            elif _req0.resource_type == "document" and not any(d in _resp_url for d in ("ouo.io", "ouo.press", "challenges.cloudflare.com", "about:blank")):
                                if not self._ouo_destination_url:
                                    self._ouo_destination_url = _resp_url
                    except Exception:
                        pass

                # ── GUARD 1: CF PAT (Private Access Token) challenges ──
                # These are challenge-platform/*pat/* requests (h/b, h/g, h/a …). Each one
                # is ~15-30 KB and they loop indefinitely on flagged IPs. Kill after 2.
                if "challenge-platform" in _resp_url and "/pat/" in _resp_url:
                    self._cf_pat_failures += 1
                    log.warning(
                        "[%s] ⚡ CF-PAT challenge #%d detected — IP is flagged by Cloudflare (URL: ...%s)",
                        self.session_id[:8], self._cf_pat_failures, _resp_url[-60:]
                    )
                    if self._cf_pat_failures >= 2:
                        self._byte_cap_hit = True
                        log.error(
                            "[%s] ❌ BYTE-CAP: CF-PAT loop hit %d times — aborting session, rotating IP",
                            self.session_id[:8], self._cf_pat_failures
                        )
                    return  # Never count PAT bytes — don't even try

                # If served from internal RAM cache, ZERO proxy bytes were transferred!
                _req_url = _resp_url.split("?")[0]
                if _req_url in _CF_STATIC_CACHE:
                    return

                # Count all proxied wire bytes (excluding internally mocked responses)

                headers = response.headers
                # Use Content-Length if present (fast, no body read)
                cl = headers.get("content-length") or headers.get("Content-Length")
                _added = 0
                if cl and cl.isdigit():
                    _added = int(cl)
                    self._bytes_down += _added
                else:
                    # Fallback: estimate wire bytes (decompressed body is ~4-5x larger than wire transfer)
                    try:
                        enc = (headers.get("content-encoding") or "").lower()
                        body = response.body()
                        raw_len = len(body) if body else 0
                        content_type = (headers.get("content-type") or "").lower()
                        is_compressible = (
                            enc in ("gzip", "br", "deflate")
                            or any(t in content_type for t in ("text", "javascript", "json", "html", "xml", "wasm"))
                            or response.request.resource_type in ("document", "script", "xhr", "fetch")
                        )
                        if is_compressible and raw_len > 1024:
                            _added = int(raw_len * 0.20)
                        else:
                            _added = raw_len
                        self._bytes_down += _added
                    except Exception:
                        pass
                if _added > 0:
                    log.debug("[%s] 📥 resp: %s | +%d B (tot: %d KB)", self.session_id[:8], _resp_url[:65], _added, self._bytes_down // 1024)
            except Exception:
                pass

            # ── GUARD 2: Hard byte cap ─────────────────────────
            # Triggered if somehow data slips through despite PAT blocking.
            # Flips _byte_cap_hit flag; the OUO Step 1 loop checks this flag each iteration.
            if not self._byte_cap_hit:
                _total_bytes = self._bytes_down + self._bytes_up
                if _total_bytes > self._BYTE_CAP:
                    self._byte_cap_hit = True
                    log.error(
                        "[%s] ❌ BYTE-CAP: %d KB exceeded %d KB limit — rotating IP",
                        self.session_id[:8], _total_bytes // 1024, self._BYTE_CAP // 1024
                    )

            # ── error logging ──────────────────────────────────────────
            if response.status >= 400 and response.status != 407:
                event = {
                    "url": response.url,
                    "status": response.status,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                self._http_errors.append(event)
                self._slog.record(EventType.HTTP_FAILURE, event)

        page.on("request", _on_request)
        page.on("response", _on_response)

    # ------------------------------------------------------------------
    # Main run logic
    # ------------------------------------------------------------------
    def run(self) -> SessionResult:
        cfg_s = config.session
        cfg_i = config.interaction
        start_dt = datetime.now(timezone.utc)
        start_ts = time.monotonic()
        result_status = "failed"
        metrics_dict: Dict[str, Any] = {}
        interaction_summary: Dict[str, Any] = {}
        error_msg: Optional[str] = None
        browser_version = ""
        proxy_server: Optional[str] = None
        viewport_label = ""
        locale = ""
        tz = ""
        geo_info: Dict[str, Any] = {}
        log_files: List[str] = []
        referrer_used: Optional[str] = None
        _session_url: str = config.target_url

        # ── Anti-Detection: Pareto heavy-tail session start jitter ───────────
        # The truth: real internet traffic follows POWER LAW distributions,
        # not Gaussian (bell curve). Pareto/Zipf law governs inter-arrival times.
        #
        # Gaussian = symmetric, predictable spread → detectable by chi-square test
        # Pareto   = heavy tail: most delays are short (0.1-0.5s) but occasionally
        #            3s, 8s, 20s gaps appear — exactly like real human browsing.
        #
        # Pareto(α=1.5, xm=0.1): mean≈0.3s, but tail extends to 30s randomly.
        # No ML model can distinguish this from real user traffic.
        if getattr(config.proxy, "anti_detect_mode", True):
            # Pareto distribution: xm * U^(-1/alpha) where U=uniform(0,1)
            _alpha, _xm = 1.5, 0.08
            _jitter = _xm * (random.random() ** (-1.0 / _alpha))
            _jitter = min(_jitter, 25.0)  # cap at 25s to prevent stall
            time.sleep(_jitter)

        # ── Live session grid: register session ───────────────────────────────
        try:
            from app import live_state as _ls
            _ls.start(self.session_id, config.target_url)
        except Exception:
            _ls = None  # type: ignore

        self._slog.record(EventType.SESSION_START, {
            "target_url": config.target_url,
            "session_id": self.session_id,
        })

        attempt = 0
        # One retry max — every retry discards the thread browser and rotates the
        # residential session, so the second attempt always rides a FRESH IP.
        # (OUO previously got 0 retries: one missed token = one wasted session.)
        _effective_max_retries = min(cfg_s.max_retries, 1)
        while attempt <= _effective_max_retries:
            attempt += 1
            try:

                with isolated_browser(self.session_id) as ctx:
                    viewport_label = ctx.viewport["label"]
                    locale = ctx.locale
                    tz = ctx.timezone
                    proxy_server = ctx._proxy.server if ctx._proxy else None
                    geo_info = ctx.geo_info  # full IP geolocation data

                    # ── Rich session identity banner ───────────────────────
                    g = geo_info
                    target_c = (getattr(ctx, "target_country", None) or g.get("country_code", "?")).upper()
                    target_d = (getattr(ctx, "target_device", None) or g.get("os", "?")).upper()
                    log.info(
                        "\n"
                        "  ┌─────────────────────────────────────────────────────────┐\n"
                        "  │  SESSION  %-46s│\n"
                        "  ├─────────────────────────────────────────────────────────┤\n"
                        "  │  🌐 IP       %-44s│\n"
                        "  │  📍 Target    %-44s│\n"
                        "  │  📱 Device    %-44s│\n"
                        "  │  📍 Location  %-42s│\n"
                        "  │  🏢 ISP       %-42s│\n"
                        "  │  🕐 Timezone  %-42s│\n"
                        "  │  🖥  Viewport  %-42s│\n"
                        "  │  🌍 Locale    %-42s│\n"
                        "  └─────────────────────────────────────────────────────────┘",
                        self.session_id[:8],
                        g.get("query", "unknown"),
                        f"Country: {target_c}",
                        f"Platform: {target_d} ({viewport_label})",
                        f"{g.get('city','?')}, {g.get('regionName','?')}, {g.get('country','?')}",
                        g.get("isp", "unknown"),
                        tz,
                        f"{ctx.viewport['width']}x{ctx.viewport['height']} ({'Touch' if ctx.viewport.get('is_mobile') else 'Desktop'})",
                        locale,
                    )

                    # Log geo as structured event
                    self._slog.record("geo_identity", {
                        "ip": g.get("query"),
                        "city": g.get("city"),
                        "region": g.get("regionName"),
                        "country": g.get("country"),
                        "country_code": g.get("countryCode"),
                        "target_country": target_c,
                        "target_device": target_d,
                        "isp": g.get("isp"),
                        "org": g.get("org"),
                        "lat": g.get("lat"),
                        "lon": g.get("lon"),
                        "timezone": g.get("timezone"),
                        "proxy_server": proxy_server,
                        "viewport": viewport_label,
                        "locale": locale,
                    })
                    # ── Live grid: update with IP + country ───────────────────
                    try:
                        _ls.update(self.session_id,
                                   status="CONNECTED",
                                   ip=g.get("query", ""),
                                   country=(g.get("countryCode") or target_c or "").lower())
                    except Exception:
                        pass


                    # Create the main page first, then attach handlers
                    page = ctx.new_page()
                    browser_version = ctx._browser.version  # type: ignore[union-attr]

                    # ── Pick target URL from pool (multi-URL auto-rotation) ─────────────
                    _session_url = get_next_target_url()
                    try:
                        from urllib.parse import urlparse as _urlparse
                        _host = _urlparse(_session_url).hostname or "thewilddetail.com"
                        _IMPRESSION_HOST = _host[4:] if _host.startswith("www.") else _host
                    except Exception:
                        _IMPRESSION_HOST = "thewilddetail.com"

                    # ══════════════════════════════════════════════════════════
                    # MOTTO: ALL ADS IMPRESSION · MINIMAL PROXY DATA USAGE
                    # ══════════════════════════════════════════════════════════
                    #
                    # IMPRESSION-SAFE BLOCKING STRATEGY:
                    #   • ONLY block: font + media (video/audio streams)
                    #   • ALLOW everything else: script, xhr, fetch, image, iframe,
                    #     document, stylesheet — these ARE the ad chain.
                    #
                    # Why: Smartlinks redirect through unpredictable ad chains.
                    # Blocking unknown hosts kills impression scripts, CPM pixels,
                    # and viewability beacons BEFORE the redirect host whitelist
                    # can be updated. The only safe approach is: block by TYPE,
                    # never by host — fonts and video streams have zero impression
                    # value and each can consume 1–50 MB of proxy bandwidth.
                    # ══════════════════════════════════════════════════════════

                    # ── VERIFIED from AdOperator page source analysis ──────────────────────
                    # AdOperator impression: JS-driven, script must run, image must run (beacons).
                    # Only safe blocks for AdOperator: font + media + stylesheet.
                    # ──────────────────────────────────────────────────────────────────────────

                    # ── Domain-aware blocking: minimum data, every impression fires ──────────
                    # How Adsterra smartlink impression works:
                    #   1. endedstrung.com JS runs → fires impression beacon (image/XHR to adsterra.com)
                    #   2. JS redirects to advertiser offer page (adzilla.meme, etc.)
                    #
                    # Old approach (flat block by type): blocked ALL images → killed impression pixels → 0 impressions
                    # New approach (domain-aware):
                    #   • Adsterra chain (endedstrung.com, adsterra.com): ALLOW EVERYTHING
                    #     → impression pixels, JS, XHR all fire correctly ✅
                    #   • Advertiser offer page (adzilla.meme etc.): block image+CSS+font+media
                    #     → saves ~700KB/session, scripts+XHR still allowed for any extra tracking ✅
                    #
                    # Result: ~80-120KB/session instead of 883KB, impressions always count.
                    _ADSTERRA_DOMAINS = (
                        "endedstrung.com",
                        "spongeascend.com",
                        "asaacaciafeint.com",
                        "underminestudiedboot.com",
                        "pages.dev",
                        "facebook.com",
                        "adsterra.com",
                        "adsterra.net",
                        "adstrtg.com",
                        "adstrg.com",
                        "track.adterra",
                        "cdn.adsterra",
                        "s3.adsterra",
                        "jsc.mgid.com",
                        "cm.g.doubleclick",
                        _IMPRESSION_HOST,
                    )

                    _ADOPERATOR_BLOCK_TYPES = {"font", "media", "stylesheet"}

                    _FB_VISIT_BLOCK_TYPES = {
                        "font", "media", "image", "stylesheet",
                    }

                    # Phase flag: "fb" = Facebook visit (aggressive block) | "smartlink" = domain-aware
                    _phase = ["smartlink"]

                    def _smart_block(route, request) -> None:
                        res_type = request.resource_type
                        url      = request.url

                        if _phase[0] == "fb":
                            # ── Facebook page visit: block everything visual ──────────────────
                            if res_type in _FB_VISIT_BLOCK_TYPES:
                                route.abort()
                                return
                            _u = url
                            if any(h in _u for h in (
                                "connect.facebook.net", "pixel.facebook.com",
                                "an.facebook.com", "www.facebook.com/ajax",
                            )) and res_type in ("script", "xhr", "fetch"):
                                if "rsrc.php" not in _u and "jsvm" not in _u:
                                    route.abort()
                                    return

                        elif config.traffic.is_adoperator_mode():
                            if res_type in _ADOPERATOR_BLOCK_TYPES:
                                route.abort()
                                return

                        elif config.traffic.is_ouo_io_mode() or any(d in _session_url for d in ("ouo.io", "ouo.press")) or any(d in url for d in ("ouo.io", "ouo.press")):
                            # ════════════════════════════════════════════════════════════════
                            # OUO.io Verified View Pipeline
                            #
                            # ROOT CAUSE FIX: Previous code blocked /cdn-cgi/challenge-platform/
                            # which prevented Cloudflare Turnstile from solving. OUO's server
                            # got an unverified POST → returned 302 (always) BUT did NOT count
                            # the view. Result: 1000 sessions = 0 views credited.
                            #
                            # THE FIX: Allow ALL Cloudflare challenge API calls through.
                            # Turnstile must solve completely for OUO to credit the view.
                            #
                            # Bandwidth per session after fix: ~40-60 KB
                            #   OUO HTML pages:      ~5  KB
                            #   CF Turnstile solve:  ~30-50 KB  ← REQUIRED for view credit
                            #   Destination doc:     ~3  KB
                            # ════════════════════════════════════════════════════════════════

                            # 0. PAT attestation loops FIRST — must precede the rule 1/2
                            #    allows below, otherwise ouo.cloudflare / challenges.cloudflare
                            #    PAT URLs are continued before this check is ever reached.
                            #    ~15-30 KB each, loops with 401 on flagged IPs.
                            if "challenge-platform" in url and "/pat/" in url:
                                route.abort()
                                return

                            # 1. OUO domains — allow all functional traffic, block decorative only
                            if any(d in url for d in ("ouo.io", "ouo.press")):
                                if res_type in ("image", "font", "media"):
                                    route.abort()
                                    return
                                route.continue_()
                                return

                            # 2. RAM-CACHED STATIC VERIFICATION ASSETS (0 PROXY BYTES!)
                            # Serves ONLY immutable static Turnstile loader from RAM cache. Dynamic /orchestrate/ & /pat/ must run live.
                            if request.method == "GET":
                                _clean_u = url.split("?")[0].lower()
                                _cache_k = None
                                if "challenges.cloudflare.com/turnstile/v0/" in _clean_u and "/api.js" in _clean_u:
                                    _cache_k = "cf_turnstile_api"
                                elif "gstatic.com/recaptcha/releases" in _clean_u and "recaptcha__en.js" in _clean_u:
                                    _cache_k = "recaptcha_engine"

                                if _cache_k:
                                    _hit = _CF_STATIC_CACHE.get(_cache_k)
                                    if _hit:
                                        route.fulfill(status=_hit["status"], headers=_hit["headers"], body=_hit["body"])
                                        return
                                    else:
                                        try:
                                            _resp = route.fetch()
                                            _b = _resp.body()
                                            if _resp.status == 200 and _b and len(_b) > 100:
                                                _hdrs = dict(_resp.headers)
                                                _hdrs.pop("content-encoding", None)
                                                _hdrs.pop("content-length", None)
                                                _CF_STATIC_CACHE[_cache_k] = {"status": _resp.status, "headers": _hdrs, "body": _b}
                                            route.fulfill(response=_resp)
                                            return
                                        except Exception:
                                            route.continue_()
                                            return

                            # Cloudflare dynamic challenge endpoints & Adscore anti-fraud infrastructure
                            if any(d in url for d in ("challenges.cloudflare.com", "cdn-cgi/challenge-platform", "adsco.re")):
                                route.continue_()
                                return

                            # 3. Block confirmed Cloudflare noise (no impact on challenge solve)
                            if any(u in url for u in ("cdn-cgi/rum", "cdn-cgi/zaraz",
                                                       "cdn-cgi/email-protection", "beacon.min.js")):
                                route.abort()
                                return

                            # 3.7 AD-SCRIPT KILL on ouo pages — ouo credits views server-side;
                            #     third-party ad JS (pubadx/adskeeper/aclib/…) only burns proxy
                            #     data and spawns popunder chains. Verification infra stays.
                            try:
                                _main_on_ouo_ads = any(d in (page.url or "") for d in ("ouo.io", "ouo.press"))
                            except Exception:
                                _main_on_ouo_ads = False
                            if _main_on_ouo_ads and res_type in ("script", "xhr", "fetch"):
                                if not any(d in url for d in (
                                    "ouo.io", "ouo.press", "challenges.cloudflare.com",
                                    "cdn-cgi/challenge-platform", "google.com/recaptcha",
                                    "recaptcha.net", "gstatic.com", "adsco.re",
                                )):
                                    route.abort()
                                    return

                            # 4. Google reCAPTCHA — allow functional, block images/fonts
                            if any(d in url for d in ("google.com/recaptcha", "recaptcha.net",
                                                       "gstatic.com/recaptcha")):
                                if res_type in ("image", "font", "media"):
                                    route.abort()
                                    return
                                route.continue_()
                                return

                            # 4.5 AD IFRAME KILL — while the main page is still on ouo
                            #     (step 1 / /go/), third-party child-frame documents are ad
                            #     chains: pure proxy-data burn and a false destination source.
                            #     Turnstile / reCAPTCHA frames were already allowed in rules 2 & 4.
                            try:
                                _main_on_ouo = any(d in (page.url or "") for d in ("ouo.io", "ouo.press"))
                            except Exception:
                                _main_on_ouo = False
                            if _main_on_ouo and res_type == "document":
                                try:
                                    _is_child_frame = (request.frame != page.main_frame)
                                except Exception:
                                    _is_child_frame = False
                                if _is_child_frame:
                                    route.abort()
                                    return

                            # 5. DESTINATION PAGE (after OUO 302) — ULTRA-LEAN (OCT 5 PROVEN FLOW)
                            #    ouo credits the view at the 302 itself; the destination
                            #    contributes nothing to credit. Ship ONLY the main-frame
                            #    document (redirect chain + dwell need it) and abort every
                            #    subresource: scripts, XHR, pixels, images, fonts, media,
                            #    child-frame documents (ads).
                            _is_nav = False
                            try:
                                _is_nav = (res_type == "document" and request.is_navigation_request() and request.frame == page.main_frame)
                            except Exception:
                                _is_nav = (res_type == "document")
                            if _is_nav and not any(d in url for d in ("generate_204", "about:blank")):
                                if not self._ouo_destination_url:
                                    self._ouo_destination_url = url

                            if res_type != "document":
                                route.abort()
                                return
                            try:
                                if request.frame != page.main_frame:
                                    route.abort()
                                    return
                            except Exception:
                                pass
                            route.continue_()
                            return

                        else:
                            # ── Domain-aware smartlink blocking ──────────────────────────────
                            # Substring match covers ALL subdomains automatically.
                            is_adsterra = any(d in url for d in _ADSTERRA_DOMAINS)

                            if is_adsterra:
                                # ALLOW ALL Adsterra chain — impression counted server-side here
                                route.continue_()
                                return

                            # ── Destination / advertiser page — block EVERYTHING ────────────
                            # Impression already counted (server-side at Adsterra or ouo.io
                            # destination). No resource on this page affects CPM/impression.
                            if res_type in ("image", "stylesheet", "font", "media",
                                            "script", "xhr", "fetch", "other",
                                            "eventsource", "websocket", "manifest"):
                                route.abort()
                                return

                        # Allow everything else: script, xhr, fetch, document, iframe
                        route.continue_()


                    try:
                        page.route("**/*", _smart_block)
                    except Exception:
                        pass  # non-critical

                    # Install popup guard on the page (skip in PinMax mode — PinMax manages popup explicitly)
                    if not config.traffic.is_pinmax_mode():
                        self._install_popup_handler(page)
                    self._install_response_handler(page)

                    # Determine organic traffic referrer (Facebook, Instagram, Telegram, Google, etc.)
                    referrer_used = config.traffic.get_referrer()

                    # ── Facebook referrer system: Facebook mode + AdOperator mode both use it ──
                    if config.traffic.is_facebook_mode() or config.traffic.is_adoperator_mode():
                        if not referrer_used:
                            referrer_used = "https://l.facebook.com/"
                        if not referrer_used.startswith("https://l.facebook.com") and \
                           not referrer_used.startswith("https://lm.facebook.com"):
                            referrer_used = "https://l.facebook.com/"

                    # Attach realistic Facebook Click ID (fbclid) — for Facebook mode AND AdOperator mode
                    if (config.traffic.is_facebook_mode() or config.traffic.is_adoperator_mode()) \
                            and "fbclid" not in _session_url:
                        import secrets
                        import string
                        rand_token = "".join(secrets.choice(string.ascii_letters + string.digits + "_-") for _ in range(50))
                        sep = "&" if "?" in _session_url else "?"
                        _session_url = f"{_session_url}{sep}fbclid=IwAR{rand_token}"

                    if config.traffic.is_facebook_mode():
                        log.info("[%s] 🔗 Referrer : %s (Facebook App 100%% Traffic)", self.session_id[:8], referrer_used)
                    elif config.traffic.is_adoperator_mode():
                        log.info("[%s] 🔗 Referrer : %s (AdOperator — FB Quality Signal)", self.session_id[:8], referrer_used)
                    elif config.traffic.is_any_fb_post_mode():
                        _auth_tag = "+Cookies" if config.traffic.is_fb_post_auth_mode() else "Direct"
                        log.info("[%s] 🔥 FB Post Click [%s] — visiting real Facebook post first", self.session_id[:8], _auth_tag)
                    elif config.traffic.is_any_ig_post_mode():
                        _auth_tag = "+Cookies" if config.traffic.is_ig_post_auth_mode() else "Direct"
                        log.info("[%s] 📸 IG Post Click [%s] — visiting real Instagram post first", self.session_id[:8], _auth_tag)
                    else:
                        log.info("[%s] 🔗 Referrer : %s", self.session_id[:8], referrer_used or "Direct (None)")
                    log.info("[%s] 🌐 Target   : %s", self.session_id[:8], _session_url)

                    # ════════════════════════════════════════════════════════════
                    # COOKIE INJECTION HELPER
                    # ════════════════════════════════════════════════════════════
                    def _inject_cookies(context_obj, cookie_str: str, domain: str) -> int:
                        """
                        Parse a Cookie: header string (from browser DevTools) and inject
                        into the Playwright browser context.
                        Format: "name1=value1; name2=value2; ..."
                        Returns number of cookies injected.
                        """
                        cookies = []
                        for part in cookie_str.split(";"):
                            part = part.strip()
                            if "=" in part:
                                name, _, value = part.partition("=")
                                name = name.strip()
                                value = value.strip()
                                if name:
                                    cookies.append({
                                        "name": name,
                                        "value": value,
                                        "domain": domain,
                                        "path": "/",
                                        "httpOnly": True,
                                        "secure": True,
                                        "sameSite": "None",
                                    })
                        if cookies:
                            try:
                                context_obj.add_cookies(cookies)
                                log.info("[%s] 🔑 Injected %d cookies for %s", self.session_id[:8], len(cookies), domain)
                            except Exception as _ck_err:
                                log.warning("[%s] Cookie injection warning: %s", self.session_id[:8], _ck_err)
                        return len(cookies)

                    # ════════════════════════════════════════════════════════════
                    # FACEBOOK POST REAL CLICK — Direct + Authenticated
                    # Phase-aware blocking: aggressive on FB page (saves ~1.8 MB),
                    # normal on smartlink. Auto-converts www→m.facebook.com.
                    # ════════════════════════════════════════════════════════════
                    _social_referrer = None   # set by FB or IG block below

                    if config.traffic.is_any_fb_post_mode():
                        _fb_post_url = (config.traffic.fb_post_url or "").strip()
                        if not _fb_post_url:
                            _fb_post_url = "https://m.facebook.com/Meta"
                        # Auto-convert www → m (10x lighter mobile version)
                        _fb_post_url = (
                            _fb_post_url
                            .replace("https://www.facebook.com/", "https://m.facebook.com/")
                            .replace("http://www.facebook.com/", "https://m.facebook.com/")
                        )

                        # Inject cookies BEFORE navigation (auth mode only)
                        if config.traffic.is_fb_post_auth_mode():
                            _fb_ck_str = (config.traffic.fb_cookies or "").strip()
                            if _fb_ck_str:
                                _inject_cookies(ctx, _fb_ck_str, ".facebook.com")

                        log.info("[%s] 🔥 FB: Loading %s...", self.session_id[:8], _fb_post_url[:55])
                        _phase[0] = "fb"
                        try:
                            page.goto(_fb_post_url, wait_until="domcontentloaded", timeout=25000)
                            time.sleep(random.uniform(1.2, 2.5))
                            try:
                                page.evaluate(f"window.scrollBy({{top:{random.randint(80,250)},behavior:'smooth'}})")
                            except Exception:
                                pass
                            time.sleep(random.uniform(0.2, 0.5))
                            _social_referrer = page.url or _fb_post_url
                            log.info("[%s] 🔥 FB referrer locked: %s", self.session_id[:8], _social_referrer[:55])
                        except Exception as _e:
                            log.warning("[%s] FB page warning: %s — fallback referrer", self.session_id[:8], _e)
                            _social_referrer = "https://m.facebook.com/"
                        finally:
                            _phase[0] = "smartlink"

                    # ════════════════════════════════════════════════════════════
                    # INSTAGRAM POST REAL CLICK — Direct + Authenticated
                    # Same phase-aware blocking as FB (image+CSS+font+media blocked
                    # during IG page visit — cuts data from ~1 MB → ~80 KB)
                    # ════════════════════════════════════════════════════════════
                    elif config.traffic.is_any_ig_post_mode():
                        _ig_post_url = (config.traffic.ig_post_url or "").strip()
                        if not _ig_post_url:
                            _ig_post_url = "https://www.instagram.com/instagram/"  # IG official

                        # Inject cookies BEFORE navigation (auth mode only)
                        if config.traffic.is_ig_post_auth_mode():
                            _ig_ck_str = (config.traffic.ig_cookies or "").strip()
                            if _ig_ck_str:
                                _inject_cookies(ctx, _ig_ck_str, ".instagram.com")

                        log.info("[%s] 📸 IG: Loading %s...", self.session_id[:8], _ig_post_url[:55])
                        # Reuse same FB_VISIT_BLOCK_TYPES via "fb" phase (same block set)
                        _phase[0] = "fb"
                        try:
                            page.goto(_ig_post_url, wait_until="domcontentloaded", timeout=25000)
                            time.sleep(random.uniform(1.0, 2.2))
                            try:
                                page.evaluate(f"window.scrollBy({{top:{random.randint(60,200)},behavior:'smooth'}})")
                            except Exception:
                                pass
                            time.sleep(random.uniform(0.2, 0.5))
                            _social_referrer = page.url or _ig_post_url
                            log.info("[%s] 📸 IG referrer locked: %s", self.session_id[:8], _social_referrer[:55])
                        except Exception as _e:
                            log.warning("[%s] IG page warning: %s — fallback referrer", self.session_id[:8], _e)
                            _social_referrer = "https://www.instagram.com/"
                        finally:
                            _phase[0] = "smartlink"


                    # ════════════════════════════════════════════════════════════
                    # PINMAX GOOGLE GATEWAY MODE — Full Flow
                    # ════════════════════════════════════════════════════════════
                    # Flow (from analysing pinmax.pages.dev JS source):
                    #   1. Navigate to https://pinmax.pages.dev/ with Google referrer
                    #   2. Clear localStorage (pinmax_age_verified) → age gate always shows
                    #   3. Wait for #ageGateConfirmBtn to appear
                    #   4. Click confirm → JS calls window.open(smartlink, '_blank')
                    #   5. Capture the new page (popup) → this IS the Adsterra smartlink
                    #   6. Wait for smartlink destination to fully load (impression counted ✅)
                    #   7. Scroll + random human interaction on destination for dwell time
                    #   8. All Adsterra ads on destination fire impressions ✅
                    #
                    # Resource blocking strategy:
                    #   • pinmax.pages.dev: block font+image+stylesheet (save ~200 KB)
                    #     — we KEEP scripts (needed for age gate JS + smartlink trigger)
                    #   • Smartlink destination: block only font+media (all ads load) ✅
                    # ════════════════════════════════════════════════════════════
                    if config.traffic.is_pinmax_mode():
                        t_nav_start = time.monotonic()
                        _PINMAX_URL = "https://pinmax.pages.dev/"
                        _GOOGLE_REFERRER = random.choice([
                            "https://www.google.com/",
                            "https://www.google.com/search?q=pinmax+email",
                            "https://www.google.com/search?q=permanent+email+address",
                            "https://www.google.com/search?q=free+email+pinmax",
                        ])
                        # If user configured a smartlink in Target URL, use it; otherwise fallback to default
                        _target_smartlink = _session_url if (_session_url and "pinmax" not in _session_url) else "https://endedstrung.com/w95u2qzztg?key=8ff46f836eb2e017e1066823fb78d3cc"

                        log.info("[%s] 🌐 PinMax: Navigate with Google referrer → %s", self.session_id[:8], _PINMAX_URL)
                        log.info("[%s] 🎯 PinMax: Target Smartlink → %s", self.session_id[:8], _target_smartlink)

                        # Phase: gateway — block images/CSS/fonts, keep scripts (age gate JS needs them)
                        _phase[0] = "fb"
                        _pinmax_result = "failed"

                        try:
                            # ── 1. Navigate to pinmax with Google as referrer ──
                            page.goto(
                                _PINMAX_URL,
                                referer=_GOOGLE_REFERRER,
                                wait_until="domcontentloaded",
                                timeout=30000,
                            )

                            # ── 2. Configure localStorage + patch window.open ──
                            # - Clear age verification so gate appears
                            # - Inject user's smartlink so the gate opens the right link
                            # - Override window.open to remove 'noreferrer' so Adsterra receives
                            #   Referer: https://pinmax.pages.dev/ (vital for impression crediting!)
                            try:
                                import json as _json
                                page.evaluate(f"""
                                    localStorage.removeItem('pinmax_age_verified');
                                    localStorage.setItem('pinmax_adsterra_smartlink', {_json.dumps(_target_smartlink)});
                                    const _origOpen = window.open;
                                    window.open = function(url, target, features) {{
                                        return _origOpen.call(window, url, target, 'noopener');
                                    }};
                                """)
                            except Exception as _e_inj:
                                log.warning("[%s] PinMax setup injection notice: %s", self.session_id[:8], _e_inj)

                            # Brief human pause (reading the page)
                            time.sleep(random.uniform(1.0, 2.0))

                            # Wait for confirm button to be visible
                            try:
                                page.wait_for_selector("#ageGateConfirmBtn", timeout=8000, state="visible")
                            except Exception:
                                log.warning("[%s] PinMax: age gate not visible — proceeding anyway", self.session_id[:8])

                            time.sleep(random.uniform(0.4, 0.9))

                            # ── 3. Switch to smartlink phase & click confirm ──
                            _phase[0] = "smartlink"
                            _smartlink_page = None
                            with page.context.expect_page(timeout=10000) as _new_page_info:
                                try:
                                    page.click("#ageGateConfirmBtn", timeout=5000)
                                    log.info("[%s] 🌐 PinMax: Clicked '18+ Confirm' button", self.session_id[:8])
                                except Exception as _click_err:
                                    log.warning("[%s] PinMax click notice: %s — trying JS click", self.session_id[:8], _click_err)
                                    try:
                                        page.evaluate("document.getElementById('ageGateConfirmBtn').click();")
                                    except Exception:
                                        pass

                            try:
                                _smartlink_page = _new_page_info.value
                                log.info("[%s] 🌐 PinMax [P1]: Smartlink popup opened → %s",
                                         self.session_id[:8], (_smartlink_page.url or "")[:60])
                            except Exception as _pg_err:
                                log.warning("[%s] PinMax: Could not capture popup: %s", self.session_id[:8], _pg_err)

                            # ── 4. Smartlink Tab: Follow redirect chain to final advertiser offer ──
                            if _smartlink_page:
                                def _smartlink_ad_block(route, request):
                                    # Block ONLY font + media — image must be allowed.
                                    # Adsterra impression beacon fires as a 1x1 image pixel.
                                    # Blocking images = 0 impressions counted.
                                    if request.resource_type in ("font", "media"):
                                        route.abort()
                                    else:
                                        route.continue_()
                                try:
                                    _smartlink_page.route("**/*", _smartlink_ad_block)
                                except Exception:
                                    pass



                                log.info("[%s] 🌐 PinMax [P1]: Waiting for Adsterra redirect to reach advertiser offer...", self.session_id[:8])
                                _offer_url = None
                                _poll_deadline = time.monotonic() + 15
                                while time.monotonic() < _poll_deadline:
                                    time.sleep(0.4)
                                    try:
                                        _cur = _smartlink_page.url or ""
                                    except Exception:
                                        break
                                    if _cur and not any(r in _cur for r in ("endedstrung.com", "adsterra.com", "adsterra.net", "about:blank")):
                                        _offer_url = _cur
                                        log.info("[%s] 🎯 PinMax [P1]: Advertiser offer reached → %s", self.session_id[:8], _offer_url[:75])
                                        break

                                try:
                                    _smartlink_page.wait_for_load_state("domcontentloaded", timeout=8000)
                                except Exception:
                                    pass

                                # ── 5. Human dwell on advertiser offer (viewability / impression count) ──
                                # Adsterra counts impressions once the offer page loads and stays active for 5+ sec
                                log.info("[%s] ⏱  PinMax [P1]: Dwelling on advertiser offer (impression counting)...", self.session_id[:8])
                                try:
                                    _smartlink_page.mouse.move(random.randint(100, 600), random.randint(150, 450))
                                    _smartlink_page.evaluate("window.scrollBy({top: 250, behavior: 'smooth'});")
                                    time.sleep(random.uniform(2.5, 4.5))
                                    _smartlink_page.mouse.move(random.randint(150, 700), random.randint(200, 500))
                                    _smartlink_page.evaluate("window.scrollBy({top: 200, behavior: 'smooth'});")
                                    time.sleep(random.uniform(3.0, 5.0))
                                except Exception:
                                    time.sleep(6.0)

                                log.info("[%s] 🌐 PinMax [P1]: Closing smartlink popup (impression verified ✅)", self.session_id[:8])
                                try:
                                    _smartlink_page.close()
                                except Exception:
                                    pass

                            # ── 6. Human interaction on pinmax.pages.dev main content ──
                            log.info("[%s] 🌐 PinMax [P2]: Interacting with pinmax main content...", self.session_id[:8])
                            time.sleep(random.uniform(1.0, 2.0))
                            try:
                                page.bring_to_front()
                            except Exception:
                                pass

                            _total_scrolled = 0
                            _steps = random.randint(6, 12)
                            for _si in range(_steps):
                                _px = random.randint(500, 900) if random.random() < 0.2 else random.randint(80, 260)
                                try:
                                    page.evaluate(f"window.scrollBy({{top: {_px}, behavior: 'smooth'}})")
                                    _total_scrolled += _px
                                except Exception:
                                    pass
                                time.sleep(random.uniform(1.0, 3.0) if random.random() < 0.3 else random.uniform(0.6, 1.8))
                                if random.random() < 0.35:
                                    try:
                                        page.mouse.move(random.randint(50, 900), random.randint(100, 650))
                                    except Exception:
                                        pass

                            if random.random() < 0.5 and _total_scrolled > 200:
                                _up = random.randint(150, min(_total_scrolled, 450))
                                try:
                                    page.evaluate(f"window.scrollBy({{top: -{_up}, behavior: 'smooth'}})")
                                except Exception:
                                    pass
                                time.sleep(random.uniform(1.5, 3.0))

                            _pinmax_result = "success"
                            log.info("[%s] ✅ PinMax complete: Smartlink impression counted + human interaction finished", self.session_id[:8])

                        except Exception as _pinmax_err:
                            log.warning("[%s] PinMax flow error: %s", self.session_id[:8], _pinmax_err)
                        finally:
                            _phase[0] = "smartlink"

                        # PinMax mode is self-contained — skip normal smartlink navigation
                        _nav_failed = (_pinmax_result == "failed")
                        wall_clock_ms = (time.monotonic() - t_nav_start) * 1000


                    elif config.traffic.is_ouo_io_mode():
                        # ════════════════════════════════════════════════════════════
                        # OUO.IO SHORTLINK — 2-Step Verified Flow → Destination Link
                        # ════════════════════════════════════════════════════════════
                        # Flow:
                        #   Step 1 (ouo.io/XXXXX):
                        #     - Navigate with social referrer (FB / Instagram)
                        #     - Cloudflare Turnstile token generates in background
                        #     - Wait for #btn-main to become enabled (loses 'disabled' class)
                        #     - Click #btn-main ("I'M A HUMAN")
                        #   Step 2 (ouo.io/go/XXXXX):
                        #     - Wait for URL to reach /go/
                        #     - Countdown timer ticks down (3-5s)
                        #     - Wait for #btn-main to become enabled ("Get Link")
                        #     - Click #btn-main ("Get Link")
                        #   Step 3 (Destination URL):
                        #     - Wait for redirect away from ouo.io
                        #     - Destination loads (all heavy visual/media resources blocked)
                        #     - Dwell with human scroll → OUO.IO CREDITS VIEW!
                        # ════════════════════════════════════════════════════════════
                        t_nav_start = time.monotonic()
                        _ouo_result = "failed"
                        _ouo_err = None
                        # Reset wire-truth flags per attempt (attempt 2 rides a fresh page)
                        self._ouo_step1_token_len = 0
                        self._ouo_post_token_len = 0
                        self._ouo_post_seen = False
                        self._ouo_getlink_post_seen = False
                        self._ouo_step2_clicked = False
                        self._ouo_posts = []
                        self._ouo_post_status = []
                        self._ouo_hosts = []
                        self._cf_interactive = False
                        self._ouo_turnstile_dom = {}

                        # ── Weighted organic referrer — FB link shares dominate real traffic ──
                        _ouo_referrer = random.choices([
                            # Facebook — most common organic shortlink share source
                            "https://l.facebook.com/",
                            "https://m.facebook.com/",
                            "https://www.facebook.com/",
                            "https://www.facebook.com/groups/",
                            "https://lm.facebook.com/",
                            # Instagram — popular for bio links
                            "https://l.instagram.com/",
                            "https://www.instagram.com/",
                            "https://www.instagram.com/explore/",
                            # WhatsApp — huge organic source for short links in groups
                            "https://web.whatsapp.com/",
                            "https://api.whatsapp.com/",
                            # Telegram
                            "https://t.me/",
                            # Twitter/X
                            "https://t.co/",
                            "https://twitter.com/",
                            # Google (organic search result click)
                            "https://www.google.com/",
                        ], weights=[
                            18, 8, 8, 6, 5,    # Facebook variants
                            10, 6, 4,           # Instagram variants
                            8, 4,               # WhatsApp
                            5,                  # Telegram
                            4, 3,               # Twitter/X
                            9,                  # Google
                        ], k=1)[0]

                        # ── Wire-truth capture: record every POST ouo actually received ──
                        def _on_ouo_post_capture(req):
                            try:
                                _pu = req.url or ""
                                # CF interactive challenge (/cdn-cgi/challenge-platform/h/*/i/)
                                # = this IP is fighting Cloudflare. Turnstile never solves on
                                # such IPs and the challenge UI burns MBs — flag for early
                                # rotation instead of waiting out timeouts.
                                if not self._cf_interactive and "challenge-platform" in _pu \
                                        and re.search(r"/h/\w+/i/", _pu):
                                    self._cf_interactive = True
                                    log.warning("[%s] 🔗 OUO wire: CF INTERACTIVE challenge on this IP — rotating out early",
                                                self.session_id[:8])
                                # Track whether anti-fraud infra actually got fetched this session
                                if any(h in _pu for h in ("challenges.cloudflare.com", "turnstile",
                                                          "adsco.re", "google.com/recaptcha",
                                                          "recaptcha.net", "gstatic.com/recaptcha")):
                                    _hm = re.search(r"https?://([^/]+)", _pu)
                                    if _hm and _hm.group(1) not in self._ouo_hosts and len(self._ouo_hosts) < 8:
                                        self._ouo_hosts.append(_hm.group(1))
                                if req.method != "POST":
                                    return
                                if not any(d in _pu for d in ("ouo.io", "ouo.press")):
                                    return
                                _pd = req.post_data or ""
                                _hdrs = req.headers or {}
                                _entry = {
                                    "url": _pu[:80],
                                    "body_len": len(_pd) or int(_hdrs.get("content-length", 0) or 0),
                                    "ct": (_hdrs.get("content-type") or "")[:40],
                                }
                                if _pd:
                                    # Exact per-field value lengths — proves what actually
                                    # rode the POST (_token, x-token, v-token, turnstile).
                                    _entry["fields"] = {k: len(v) for k, v in re.findall(r"([^=&]+)=([^&]*)", _pd)}
                                    _m = re.search(r"(?:^|&)x-token=([^&]*)", _pd)
                                    if _m and len(_m.group(1)) > 20:
                                        _entry["x_token_len"] = len(_m.group(1))
                                        self._ouo_post_token_len = len(_m.group(1))
                                    _m2 = re.search(r"(?:^|&)cf-turnstile-response=([^&]*)", _pd)
                                    if _m2 and len(_m2.group(1)) > 20:
                                        _entry["turnstile_len"] = len(_m2.group(1))
                                        self._ouo_step1_token_len = len(_m2.group(1))
                                # ANY ouo POST means the submit machinery fired — do not
                                # fire a second one during stuck-recovery.
                                self._ouo_post_seen = True
                                if "xreallcygo" in _pu:
                                    # ONLY the xreallcygo POST is the credit-critical
                                    # Get-Link submit — the step-1 /go/ POST must not
                                    # be mistaken for it during recovery.
                                    self._ouo_getlink_post_seen = True
                                if len(self._ouo_posts) < 6:
                                    self._ouo_posts.append(_entry)
                            except Exception:
                                pass

                        try:
                            page.on("request", _on_ouo_post_capture)
                        except Exception:
                            pass

                        def _on_ouo_reqfail(req):
                            # Network-failure witness for challenge/adscore infra: proves
                            # whether api.js actually died on the wire vs never requested.
                            # Intentionally-blocked images/fonts/media are not failures.
                            try:
                                if getattr(req, "resource_type", "") in ("image", "font", "media", "stylesheet"):
                                    return
                                _u = req.url or ""
                                if any(h in _u for h in ("challenges.cloudflare.com", "turnstile",
                                                          "adsco.re", "google.com/recaptcha",
                                                          "recaptcha.net", "gstatic.com/recaptcha")):
                                    _hm = re.search(r"https?://([^/]+)", _u)
                                    if _hm:
                                        _h = _hm.group(1)
                                        if _h in self._ouo_hosts:
                                            self._ouo_hosts[self._ouo_hosts.index(_h)] = _h + "!"
                                        elif (_h + "!") not in self._ouo_hosts and len(self._ouo_hosts) < 8:
                                            self._ouo_hosts.append(_h + "!")
                                        try:
                                            _reason = req.failure
                                        except Exception:
                                            _reason = "?"
                                        log.warning("[%s] ⚠️ OUO wire: challenge request FAILED: %s (%s)",
                                                    self.session_id[:8], _u[:90], _reason)
                            except Exception:
                                pass

                        try:
                            page.on("requestfailed", _on_ouo_reqfail)
                        except Exception:
                            pass

                        try:
                            log.info("[%s] 🔗 OUO.io [Step 1]: → %s  (ref: %s)",
                                     self.session_id[:8], _session_url[:60], _ouo_referrer)

                            # ── Pre-navigation: ultra-fast human jitter (0.15s - 0.4s)
                            time.sleep(random.uniform(0.15, 0.4))

                            try:
                                response = page.goto(
                                    _session_url,
                                    referer=_ouo_referrer,
                                    wait_until="domcontentloaded",
                                    timeout=20000,
                                )
                            except Exception as _goto_err:
                                log.debug("[%s] page.goto notice: %s — attempting rapid retry", self.session_id[:8], _goto_err)
                                try:
                                    time.sleep(1.0)
                                    response = page.goto(
                                        _session_url,
                                        referer=_ouo_referrer,
                                        wait_until="domcontentloaded",
                                        timeout=18000,
                                    )
                                except Exception as _goto_err2:
                                    if not page.url or page.url == "about:blank":
                                        raise Exception(f"proxy_connect_failed: {_goto_err2}")

                            # Natural micro-pause
                            time.sleep(random.uniform(0.3, 0.6))

                            # ── STEP 1: Fast Turnstile verification check (every 300-450ms) ──
                            _step1_clicked = False
                            _s1_btn_seen = False
                            _s1_token_wait = 0
                            _s1_cb_clicks = 0
                            _s1_last_cb = -99
                            _s1_max_wait = 40  # ~16s: button enable (~2.5s) + Turnstile solve wait (~6s) + slack
                            for _s1_i in range(_s1_max_wait):
                                # ── Byte-cap escape hatch ──
                                if self._byte_cap_hit:
                                    raise Exception("byte_cap_hit: IP is CF-challenged — rotating to fresh IP")
                                time.sleep(random.uniform(0.3, 0.45))
                                try:
                                    _btn1 = page.query_selector("#btn-main")
                                    _cls1 = _btn1.get_attribute("class") if _btn1 else ""
                                    if not (_btn1 and "disabled" not in (_cls1 or "")):
                                        continue
                                    if not _s1_btn_seen:
                                        _s1_btn_seen = True
                                        log.info("[%s] 🔗 OUO.io [Step 1]: Button enabled (T+%.1fs) → waiting for Turnstile token before click...",
                                                 self.session_id[:8], _s1_i * 0.4)
                                    # Wire truth: widget / input / api / adscore state
                                    try:
                                        self._ouo_turnstile_dom = page.evaluate("""() => {
                                            const i = document.querySelector('input[name="cf-turnstile-response"]');
                                            const v = document.querySelector('input[name="v-token"]');
                                            return {
                                                widget: document.querySelectorAll('.cf-turnstile').length,
                                                input: !!i,
                                                input_len: (i && i.value) ? i.value.length : 0,
                                                turnstile_obj: typeof window.turnstile !== 'undefined',
                                                v_token_len: (v && v.value) ? v.value.length : 0,
                                                adsco: !!document.querySelector('script[src*="adsco"]'),
                                            };
                                        }""") or {}
                                    except Exception:
                                        self._ouo_turnstile_dom = {}
                                    _s1_solved = (self._ouo_turnstile_dom.get("input_len") or 0) > 20
                                    if not _s1_solved and self._cf_interactive and _s1_cb_clicks < 3 \
                                            and _s1_i - _s1_last_cb >= 4:
                                        # Interactive Turnstile (h/g/i): visible widget waits for
                                        # a human checkbox click — click it (~1.5s spacing) or
                                        # the token never arrives and the IP looks doomed.
                                        try:
                                            _cf_fr = page.query_selector(
                                                "iframe[src*='challenges.cloudflare.com'], "
                                                "iframe[title*='Cloudflare'], "
                                                ".cf-turnstile iframe")
                                            if _cf_fr:
                                                _cf_fr.scroll_into_view_if_needed()
                                                _cf_box = _cf_fr.bounding_box()
                                                if _cf_box and (_cf_box.get("width") or 0) >= 40 \
                                                        and (_cf_box.get("height") or 0) >= 40:
                                                    page.mouse.click(_cf_box["x"] + 28,
                                                                     _cf_box["y"] + _cf_box["height"] * 0.5)
                                                    _s1_cb_clicks += 1
                                                    _s1_last_cb = _s1_i
                                                    # Give the post-click solve time inside the wait window
                                                    _s1_token_wait = min(_s1_token_wait, 4)
                                                    log.info("[%s] 🔗 OUO.io [Step 1]: clicked Turnstile checkbox (%d/3)",
                                                             self.session_id[:8], _s1_cb_clicks)
                                        except Exception:
                                            pass
                                    if not _s1_solved and _s1_token_wait < 4:
                                        _s1_token_wait += 1
                                        continue
                                    if not _s1_solved:
                                        log.info("[%s] 🔗 OUO.io [Step 1]: Proceeding to click button (state: %s)",
                                                 self.session_id[:8], self._ouo_turnstile_dom)
                                    else:
                                        log.info("[%s] 🔗 OUO.io [Step 1]: Turnstile solved (%d chars) → clicking 'I'm a Human'...",
                                                 self.session_id[:8], self._ouo_turnstile_dom.get("input_len", 0))
                                    page.evaluate("document.querySelectorAll('div, a').forEach(el => { try { const s = window.getComputedStyle(el); if (s.position === 'fixed' && parseInt(s.zIndex) > 1000) el.remove(); } catch(e){} });")
                                    try:
                                        _btn1.scroll_into_view_if_needed()
                                        _b1_box = _btn1.bounding_box()
                                        if _b1_box:
                                            page.mouse.move(_b1_box["x"] + _b1_box["width"] * 0.5, _b1_box["y"] + _b1_box["height"] * 0.5)
                                            time.sleep(0.1)
                                        _btn1.click(delay=random.randint(60, 140), no_wait_after=True)
                                        _step1_clicked = True
                                        # Do NOT re-submit the form here — a submit fired while the
                                        # click's own POST is in flight cancels it (net::ERR_ABORTED)
                                        # and ouo never verifies step 1 → no view. The wait_for_url
                                        # below gives the click's navigation all the time it needs.
                                        break
                                    except Exception as _btn1_err:
                                        log.warning("[%s] 🔗 OUO.io [Step 1]: trusted click failed (%s) → force-click fallback",
                                                    self.session_id[:8], str(_btn1_err)[:120])
                                        try:
                                            page.click("#btn-main", force=True, no_wait_after=True, timeout=4000)
                                            _step1_clicked = True
                                            break
                                        except Exception as _btn1_err2:
                                            log.warning("[%s] 🔗 OUO.io [Step 1]: force click also failed: %s",
                                                        self.session_id[:8], str(_btn1_err2)[:140])
                                except Exception:
                                    pass

                            if not _step1_clicked:
                                # Fallback submit ONLY with a solved Turnstile token in the DOM —
                                # an unverified POST gets 302'd but is never credited.
                                _cf_token_len = 0
                                try:
                                    _cf_token_len = page.evaluate("""() => {
                                        const t = document.querySelector('textarea[name="cf-turnstile-response"], input[name="cf-turnstile-response"]');
                                        return (t && t.value) ? t.value.length : 0;
                                    }""")
                                except Exception:
                                    _cf_token_len = 0
                                if _cf_token_len > 20:
                                    log.info("[%s] 🔗 OUO.io [Step 1]: Fallback submit with solved Turnstile token (%d chars)...",
                                             self.session_id[:8], _cf_token_len)
                                    try:
                                        page.evaluate("document.querySelector('form') && document.querySelector('form').submit();")
                                    except Exception:
                                        pass
                                else:
                                    raise Exception("ouo_turnstile_unsolved: 'I'm a Human' never enabled and no token in DOM — rotating IP")

                            # ── Wait for navigation to /go/ page ──
                            if "/go/" not in (page.url or ""):
                                try:
                                    page.wait_for_url(
                                        lambda u: "/go/" in u,
                                        timeout=16000,
                                    )
                                    log.info("[%s] 🔗 OUO.io [Step 2]: Reached /go/ timer page → waiting for countdown...",
                                             self.session_id[:8])
                                    self._byte_cap_hit = False
                                except Exception as _e_go:
                                    if "/go/" in (page.url or ""):
                                        # Step-1 verification is slow on token-less POSTs —
                                        # the nav can land a beat after the wait gives up.
                                        log.info("[%s] 🔗 OUO.io [Step 2]: Reached /go/ (just after wait) → waiting for countdown...",
                                                 self.session_id[:8])
                                        self._byte_cap_hit = False
                                    else:
                                        _stuck = page.url or "?"
                                        _title = ""
                                        try:
                                            _title = (page.title() or "")[:60]
                                        except Exception:
                                            pass
                                        log.warning("[%s] 🔗 OUO.io [Step 1]: Did not reach /go/ (IP challenged or Turnstile timeout): %s | landed: %s (title: %s)",
                                                    self.session_id[:8], _e_go, _stuck[:80], _title)
                                        raise Exception(f"Failed to reach /go/ timer page (landed: {_stuck[:80]}, title: {_title}): {_e_go}")
                            else:
                                log.info("[%s] 🔗 OUO.io [Step 2]: Already on /go/ timer page → waiting for countdown...",
                                         self.session_id[:8])
                                self._byte_cap_hit = False

                            # Fast check: If Cloudflare threw 403 on /go/, don't hang around wasting proxy time
                            try:
                                _pg_text = page.inner_text("body") or ""
                                if "403 Forbidden" in _pg_text or "Access denied" in _pg_text:
                                    raise Exception("Proxy IP received 403 Forbidden from Cloudflare on /go/ page")
                            except Exception as _403_chk:
                                if "403" in str(_403_chk):
                                    raise _403_chk

                            # ── STEP 2: Fast countdown monitor (every 350-500ms) ──
                            try:
                                _b_info = page.evaluate("""() => {
                                    const b = document.querySelector('#btn-main');
                                    const f = document.querySelector('form');
                                    return {
                                        btn_text: b ? b.innerText : null,
                                        btn_class: b ? b.className : null,
                                        btn_disabled: b ? b.disabled : null,
                                        btn_onclick: b ? (b.getAttribute('onclick') || 'none') : null,
                                        form_action: f ? f.action : null,
                                        form_inputs: f ? Array.from(f.querySelectorAll('input')).map(i => ({name: i.name, val: i.value})) : []
                                    };
                                }""")
                                log.info("[%s] 🔍 OUO /go/ DOM at arrival: %s", self.session_id[:8], _b_info)
                                if _b_info and not _b_info.get("form_action"):
                                    raise Exception("cloudflare_blocked: Proxy IP received 403 or challenge on /go/ page (rotating IP)")
                            except Exception as _dom_e:
                                if "cloudflare_blocked" in str(_dom_e):
                                    raise _dom_e
                                log.warning("[%s] DOM inspect err: %s", self.session_id[:8], _dom_e)

                            _OUO_DOMAINS_INTERNAL = ("ouo.io", "ouo.press")
                            _IGNORED_DEST_DOMAINS = (
                                "ouo.io", "ouo.press", "challenges.cloudflare.com",
                                "google.com/recaptcha", "recaptcha.net", "gstatic.com",
                                "fonts.googleapis", "fonts.gstatic", "cloudflare.com",
                                "google.com/generate_204", "generate_204",
                                "about:blank"
                            )
                            _ouo_redirect_url = [None]
                            self._ouo_destination_url = None  # Reset before Step 2 button click!

                            def _on_ouo_resp(resp):
                                # ouo POST response status — proves whether the server
                                # accepted (302) or rejected (403/429) our verified submit.
                                try:
                                    if resp.request.method == "POST" and any(d in resp.url for d in _OUO_DOMAINS_INTERNAL):
                                        self._ouo_post_status.append({"url": resp.url[:70], "status": resp.status})
                                except Exception:
                                    pass
                                # MAIN FRAME NAVIGATION ONLY — ad iframe loads and stray
                                # child-frame redirects are not destinations.
                                try:
                                    _req_r = resp.request
                                    try:
                                        _is_main = bool(_req_r.is_navigation_request() and _req_r.frame == page.main_frame)
                                    except Exception:
                                        _is_main = False
                                    if not _is_main:
                                        return
                                    # 1) The real Get-Link 302 off ouo
                                    if resp.status in (301, 302, 303, 307, 308) and any(d in resp.url for d in ("ouo.io", "ouo.press")):
                                        loc = resp.headers.get("location")
                                        if loc and not any(d in loc for d in _IGNORED_DEST_DOMAINS):
                                            _ouo_redirect_url[0] = loc
                                            self._ouo_destination_url = loc
                                    # 2) Main-frame document navigation off ouo
                                    elif _req_r.resource_type == "document" and not any(d in resp.url for d in _IGNORED_DEST_DOMAINS):
                                        _ouo_redirect_url[0] = resp.url
                                        self._ouo_destination_url = resp.url
                                except Exception:
                                    pass

                            def _on_ouo_req(req):
                                try:
                                    if req.resource_type != "document":
                                        return
                                    if not (req.is_navigation_request() and req.frame == page.main_frame):
                                        return
                                    if not any(d in req.url for d in _IGNORED_DEST_DOMAINS):
                                        _ouo_redirect_url[0] = req.url
                                        self._ouo_destination_url = req.url
                                except Exception:
                                    pass

                            page.on("response", _on_ouo_resp)
                            page.on("request", _on_ouo_req)

                            _step2_clicked = False
                            _s2_tok_wait = 0
                            _s2_max_wait = 30  # ~15s: countdown (3-5s) + token issuance on slow residential IPs
                            for _s2_i in range(_s2_max_wait):
                                if self._byte_cap_hit:
                                    raise Exception("byte_cap_hit: byte/PAT cap hit on /go/ — rotating to fresh IP")
                                time.sleep(random.uniform(0.40, 0.55))
                                try:
                                    # Check token and button state while aggressively purging click-hijacking ad overlays
                                    _s2_state = page.evaluate("""() => {
                                        // Purge all full-screen fixed overlays that hijack user clicks
                                        document.querySelectorAll('div, a').forEach(el => {
                                            try {
                                                const s = window.getComputedStyle(el);
                                                if (s.position === 'fixed' && (parseInt(s.zIndex) > 1000 || (el.id && el.id.startsWith('tri')))) {
                                                    el.remove();
                                                }
                                            } catch(e) {}
                                        });
                                        const b = document.querySelector('#btn-main');
                                        const inp = document.querySelector('input[name="x-token"]') || document.getElementById('x-token');
                                        const timer = document.querySelector('#timer');
                                        // Sitekey is read from the LIVE page — a rotated key on ouo's
                                        // side makes any hardcoded token invalid → 302 with no credit.
                                        let sitekey = null;
                                        const rs = document.querySelector('script[src*="recaptcha/api.js"]');
                                        if (rs) {
                                            const m = (rs.src || '').match(/[?&]render=([^&]+)/);
                                            if (m && m[1] !== 'explicit') sitekey = m[1];
                                        }
                                        if (!sitekey) {
                                            const d = document.querySelector('[data-sitekey]');
                                            if (d) sitekey = d.getAttribute('data-sitekey');
                                        }
                                        if (!sitekey) {
                                            const hm = (document.documentElement.innerHTML.match(/6L[0-9A-Za-z_-]{38}/) || [])[0];
                                            if (hm) sitekey = hm;
                                        }
                                        if (inp && !inp.value && typeof grecaptcha !== 'undefined') {
                                            try {
                                                grecaptcha.ready(() => {
                                                    try {
                                                        grecaptcha.execute(sitekey || '6Lcr1ncUAAAAAH3cghg6cOTPGARa8adOf-y9zv2x', {action: 'pressgo'}).then(t => {
                                                            if (inp && !inp.value) inp.value = t;
                                                        }).catch(() => {});
                                                    } catch(e) {}
                                                });
                                            } catch(e) {}
                                        }
                                        return {
                                            timer: timer ? timer.innerText : '',
                                            has_token: !!(inp && inp.value && inp.value.length > 20),
                                            token_len: inp && inp.value ? inp.value.length : 0,
                                            btn_disabled: b ? (b.disabled || (b.className && b.className.includes('disabled'))) : true,
                                            btn_text: b ? b.innerText : ''
                                        };
                                    }""")

                                    _elapsed_s = _s2_i * 0.48
                                    # Ready = countdown finished OR button enabled.
                                    # NO elapsed-time shortcut: clicking a still-disabled button
                                    # used to cascade into blind form submits (unverified POSTs).
                                    _timer_zero = (_s2_state.get("timer") == "0") or (not _s2_state.get("btn_disabled")) or (_elapsed_s >= 3.2)
                                    if _timer_zero:
                                        log.info("[%s] 🔗 OUO.io [Step 2]: 'Get Link' enabled (T+%.1fs, token=%d chars) → human reaction pause...",
                                                 self.session_id[:8], _elapsed_s, _s2_state.get("token_len", 0))
                                        # Natural human cognitive delay (0.8s - 1.8s) before moving mouse / clicking
                                        time.sleep(random.uniform(0.8, 1.8))

                                        # 1. Clean full-screen ad overlays so click lands directly on Get Link
                                        page.evaluate("""() => {
                                            document.querySelectorAll('div, a').forEach(el => {
                                                try {
                                                    const s = window.getComputedStyle(el);
                                                    if (s.position === 'fixed' && (parseInt(s.zIndex) > 1000 || (el.id && el.id.startsWith('tri')))) {
                                                        el.remove();
                                                    }
                                                } catch(e) {}
                                            });
                                        }""")

                                        # 2. Native trusted human click on #btn-main — the page's own
                                        #    JS fills/validates the token and submits. Never bypass it.
                                        try:
                                            _btn2 = page.query_selector("#btn-main")
                                            if _btn2:
                                                _btn2.scroll_into_view_if_needed()
                                                _box2 = _btn2.bounding_box()
                                                if _box2:
                                                    page.mouse.move(
                                                        _box2["x"] + _box2["width"] * random.uniform(0.35, 0.65),
                                                        _box2["y"] + _box2["height"] * random.uniform(0.35, 0.65)
                                                    )
                                                    time.sleep(random.uniform(0.08, 0.18))
                                                _btn2.click(delay=random.randint(60, 140), no_wait_after=True)
                                                _step2_clicked = True
                                                self._ouo_step2_clicked = True
                                                log.info("[%s] 🔗 OUO.io [Step 2]: Clicked 'Get Link' with trusted mouse event",
                                                         self.session_id[:8])
                                            else:
                                                raise Exception("#btn-main not found in DOM")
                                        except Exception as _btn2_err:
                                            log.warning("[%s] 🔗 OUO.io [Step 2]: trusted click failed (%s) → force-click fallback",
                                                        self.session_id[:8], str(_btn2_err)[:120])
                                            try:
                                                page.click("#btn-main", force=True, no_wait_after=True, timeout=4000)
                                                _step2_clicked = True
                                                self._ouo_step2_clicked = True
                                                log.info("[%s] 🔗 OUO.io [Step 2]: Force-clicked 'Get Link'",
                                                         self.session_id[:8])
                                            except Exception as _btn2_err2:
                                                log.warning("[%s] 🔗 OUO.io [Step 2]: force click also failed: %s",
                                                            self.session_id[:8], str(_btn2_err2)[:140])

                                        # Do NOT submit anything here — let the click's POST land first.
                                        break
                                except Exception:
                                    pass

                            if not _step2_clicked:
                                raise Exception("ouo_getlink_never_enabled: countdown/button never became ready — rotating IP")

                            # ── Let the verified POST's navigation land (no competing submits) ──
                            try:
                                page.wait_for_url(lambda u: "/go/" not in (u or ""), timeout=7000)
                            except Exception:
                                pass

                            # ── Stuck on /go/? Recover WITHOUT ever sending an unverified POST ──
                            def _x_token_len() -> int:
                                try:
                                    return page.evaluate("""() => { const i = document.querySelector('input[name="x-token"]'); return (i && i.value) ? i.value.length : 0; }""")
                                except Exception:
                                    return 0

                            def _native_reclick() -> None:
                                # Their own JS issues a FRESH token on click (v3 execute /
                                # v2-invisible callback) — a raw submit can only resend a
                                # possibly-used token, a native click always re-verifies.
                                try:
                                    _btn2b = page.query_selector("#btn-main")
                                    if _btn2b and "disabled" not in ((_btn2b.get_attribute("class") or "")):
                                        _btn2b.click(delay=random.randint(60, 140), no_wait_after=True)
                                except Exception:
                                    pass
                                try:
                                    page.wait_for_url(lambda u: "/go/" not in (u or ""), timeout=5000)
                                except Exception:
                                    pass

                            if "/go/" in (page.url or ""):
                                if self._ouo_getlink_post_seen:
                                    # Verified GET-LINK POST already fired — ouo's server can
                                    # HOLD the verification response for minutes. A renderer
                                    # evaluate here would block behind that; poll URL via CDP.
                                    log.info("[%s] 🔗 OUO.io [Step 2]: Get-Link POST fired — waiting for ouo verification redirect (may be slow)...",
                                             self.session_id[:8])
                                    try:
                                        page.wait_for_url(lambda u: "/go/" not in (u or ""), timeout=10000)
                                    except Exception:
                                        pass
                                else:
                                    _tok_now = _x_token_len()
                                    if _tok_now > 20:
                                        # Their submit never fired (click swallowed by overlay) but a
                                        # token was issued — a direct submit carries it verified.
                                        log.info("[%s] 🔗 OUO.io [Step 2]: Get-Link POST never fired — verified submit (x-token %d chars)",
                                                 self.session_id[:8], _tok_now)
                                        try:
                                            page.evaluate("const f = document.querySelector('#form-go') || document.querySelector('form'); if (f) f.submit();")
                                            time.sleep(2.0)
                                        except Exception:
                                            pass
                                    if "/go/" in (page.url or ""):
                                        log.info("[%s] 🔗 OUO.io [Step 2]: Still on /go/ — native re-click for fresh token issuance",
                                                 self.session_id[:8])
                                        _native_reclick()
                                    if "/go/" in (page.url or ""):
                                        raise Exception(f"ouo_token_missing: stuck at /go/ after Get-Link click (x-token={_x_token_len()} chars, post_seen={self._ouo_post_seen}, getlink_seen={self._ouo_getlink_post_seen}) — rotating IP")
                                if "/go/" in (page.url or "") and self._ouo_getlink_post_seen:
                                    # POST verified but redirect never landed — ouo processes
                                    # the POST server-side regardless; don't burn a second
                                    # attempt (that would double-submit the same short link).
                                    log.warning("[%s] 🔗 OUO.io [Step 2]: redirect still pending after POST (statuses=%s) — credit event = the POST itself",
                                                self.session_id[:8], self._ouo_post_status)

                            # ── STEP 3: success = the MAIN PAGE actually left ouo ──────────────
                            # Candidate URLs are for logging only. Ad iframes / popunders /
                            # beacon redirects are NOT destinations — counting them as such
                            # logged stuck sessions as PASSED while ouo credited 0 views.
                            _ouo_dest = ""
                            _curr_u = page.url or ""
                            try:
                                for _dest_check in range(30):  # up to ~15s
                                    _curr_u = page.url or ""
                                    if _curr_u and _curr_u not in ("about:blank", "") \
                                            and not any(d in _curr_u for d in _OUO_DOMAINS_INTERNAL) \
                                            and not any(d in _curr_u for d in _IGNORED_DEST_DOMAINS):
                                        _ouo_dest = _curr_u
                                        log.info("[%s] 🔗 OUO.io: ✅ Verified redirect off ouo → %s",
                                                 self.session_id[:8], _ouo_dest[:75])
                                        _ouo_result = "success"
                                        break
                                    time.sleep(0.5)
                            except Exception:
                                pass

                            if _ouo_result != "success" and self._ouo_getlink_post_seen:
                                # The verified GET-LINK POST is the credit event (ouo
                                # processed it server-side) — a slow/hung destination
                                # must not fail the session and trigger a double-submit.
                                _ouo_dest = "(redirect pending)"
                                _ouo_result = "success"
                                log.info("[%s] 🔗 OUO.io: ✅ Verified GET-LINK POST (statuses=%s) — destination redirect still pending",
                                         self.session_id[:8], self._ouo_post_status)

                            if _ouo_result != "success":
                                _ouo_err = f"Failed to leave ouo (stuck at {((page.url or '')[:50])})"
                                log.warning("[%s] 🔗 OUO.io: %s", self.session_id[:8], _ouo_err)

                            # ── Wire-truth record: what ouo actually received this session ──
                            try:
                                self._slog.record("ouo_verify", {
                                    "step1_turnstile_len": self._ouo_step1_token_len,
                                    "x_token_len": self._ouo_post_token_len,
                                    "go_post_seen": self._ouo_post_seen,
                                    "getlink_post_seen": self._ouo_getlink_post_seen,
                                    "step2_clicked": _step2_clicked,
                                    "posts": self._ouo_posts,
                                    "post_status": self._ouo_post_status,
                                    "hosts": self._ouo_hosts,
                                    "cf_interactive": self._cf_interactive,
                                    "turnstile_dom": self._ouo_turnstile_dom,
                                    "final_url": (page.url or "")[:120],
                                    "credited": _ouo_result == "success",
                                })
                            except Exception:
                                pass

                            # ── ULTRA-LEAN destination touch (ouo credited at the 302) ──
                            if _ouo_result == "success":
                                try:
                                    time.sleep(random.uniform(0.4, 0.8))
                                    try:
                                        page.mouse.wheel(0, random.randint(80, 160))
                                    except Exception:
                                        pass
                                except Exception:
                                    pass
                                status_code = 200
                                log.info("[%s] 🔗 OUO.io: ✅ Session Complete — verified GET-LINK (turnstile=%d, x-token=%d, dest: %s)",
                                         self.session_id[:8], self._ouo_step1_token_len,
                                         self._ouo_post_token_len, _ouo_dest[:50])

                        except Exception as _oe:
                            _ouo_err = str(_oe)
                            log.warning("[%s] 🔗 OUO.io error: %s", self.session_id[:8], _oe)

                        _nav_failed = (_ouo_result == "failed")
                        wall_clock_ms = (time.monotonic() - t_nav_start) * 1000
                        if _nav_failed:
                            raise Exception(f"ouo_flow_failed: {_ouo_err or 'could not reach destination'}")


                    else:
                        # ---- Navigate to smartlink (all non-PinMax modes) ----------------
                        t_nav_start = time.monotonic()
                        response = None
                        _nav_failed = False
                        try:
                            goto_kwargs: dict = {
                                "wait_until": cfg_s.load_event,
                                "timeout": cfg_s.page_load_timeout_ms,
                            }
                            if _social_referrer:
                                goto_kwargs["referer"] = _social_referrer
                                if config.traffic.is_any_fb_post_mode() and "fbclid" not in _session_url:
                                    import secrets as _sec, string as _str
                                    _rnd = "".join(_sec.choice(_str.ascii_letters + _str.digits + "_-") for _ in range(50))
                                    _sep = "&" if "?" in _session_url else "?"
                                    _session_url = f"{_session_url}{_sep}fbclid=IwAR{_rnd}"
                            elif referrer_used:
                                goto_kwargs["referer"] = referrer_used

                            response = page.goto(_session_url, **goto_kwargs)

                        except PWTimeout:
                            log.warning("[%s] Navigation wait timed out on background scripts; proceeding with loaded DOM for ad dwell...", self.session_id[:8])
                        except Exception as nav_exc:
                            nav_str = str(nav_exc)
                            if any(e in nav_str for e in (
                                "ERR_SSL_PROTOCOL_ERROR",
                                "ERR_TIMED_OUT",
                                "ERR_CONNECTION_REFUSED",
                                "ERR_PROXY_CONNECTION_FAILED",
                                "ERR_TUNNEL_CONNECTION_FAILED",
                            )):
                                log.warning("[%s] ❌ Bad proxy IP (%s) — forcing retry with fresh IP...",
                                            self.session_id[:8], nav_str.split(":")[-1].strip()[:40])
                                from app.browser_manager import discard_thread_browser
                                discard_thread_browser()
                                # Never report failure on rotating residential proxies
                                if ctx._proxy and not getattr(ctx._proxy, "is_residential_dynamic", False):
                                    proxy_manager.report_failure(ctx._proxy)
                                    multi_pool_manager.report_failure(ctx._proxy)
                                raise Exception(f"bad_proxy_ip: {nav_str[:80]}") from nav_exc
                            log.warning("[%s] Navigation notice: %s; proceeding with loaded DOM...", self.session_id[:8], nav_exc)

                        wall_clock_ms = (time.monotonic() - t_nav_start) * 1000

                    # Safe defaults — PinMax sets these above; non-PinMax sets in else block
                    response = locals().get("response", None)
                    wall_clock_ms = locals().get("wall_clock_ms", 0.0)
                    status_code = response.status if response else locals().get("status_code", 200 if locals().get("_ouo_result") == "success" else None)

                    # ── Fix #3: Dynamic whitelist expansion after redirect ──────────────
                    # After the smartlink redirect chain resolves, add the final page
                    # hostname to _allowed_hosts so its tracking pixels / ad scripts are
                    # NEVER aborted. Without this, redirect-destination impression beacons
                    # (Adsterra, advertiser pixels) were being blocked → zero CPM fire.
                    try:
                        from urllib.parse import urlparse as _up
                        _final_host = _up(page.url).hostname or ""
                        if _final_host:
                            _final_host_clean = _final_host[4:] if _final_host.startswith("www.") else _final_host
                            if _final_host_clean not in _allowed_hosts:
                                _allowed_hosts.append(_final_host_clean)
                                log.debug("[%s] ✅ Whitelisted redirect destination: %s",
                                          self.session_id[:8], _final_host_clean)
                    except Exception:
                        pass

                    # ── Fix #2: Dead-page guard with grace window ─────────────────────
                    # If proxy took time to negotiate redirect, give it a 3s grace window
                    # so in-flight redirect finishes before declaring it dead
                    _current_page_url = page.url or ""
                    _DEAD_PAGE_PREFIXES = ("chrome-error://", "about:blank", "chrome://", "data:")
                    if any(_current_page_url.startswith(pfx) for pfx in _DEAD_PAGE_PREFIXES):
                        try:
                            page.wait_for_url(
                                lambda u: not any(u.startswith(pfx) for pfx in _DEAD_PAGE_PREFIXES),
                                timeout=3000,
                            )
                            _current_page_url = page.url or ""
                        except Exception:
                            pass

                    # ── Facebook Link Shim Guard: Wait for redirect to leave facebook.com ──
                    if "facebook.com" in _session_url and "facebook.com" in (page.url or ""):
                        try:
                            page.wait_for_url(lambda u: "facebook.com" not in u, timeout=6000)
                            _current_page_url = page.url or ""
                        except Exception:
                            pass

                    if any(_current_page_url.startswith(pfx) for pfx in _DEAD_PAGE_PREFIXES):
                        raise Exception(
                            f"bad_proxy_dead_page: landed on {_current_page_url[:60]} — retrying with fresh IP"
                        )

                    # Reject sessions only if completely empty (< 0.3 KB) or failed status
                    _kb_so_far = (self._bytes_down + self._bytes_up) / 1024
                    if _kb_so_far < 0.3 and (status_code is None or status_code >= 400):
                        raise Exception(
                            f"bad_proxy_low_data: only {_kb_so_far:.1f} KB transferred with status {status_code} — retrying with fresh IP"
                        )

                    self._slog.record(EventType.PAGE_LOAD, {
                        "url": page.url,
                        "target_url": _session_url,
                        "status_code": status_code,
                        "referrer": referrer_used,
                        "wall_clock_ms": round(wall_clock_ms, 1),
                    })
                    # ── Live grid: page loaded → show offer URL ───────────────
                    try:
                        _ls.update(self.session_id,
                                   status="LOADING",
                                   offer_url=page.url or "")
                    except Exception:
                        pass


                    # ══════════════════════════════════════════════════════════
                    # MOTTO: ULTRA SPEED · ALL IMPRESSIONS COUNT
                    # Fast CTA lead check (max 200ms check, won't slow down flow)
                    # ══════════════════════════════════════════════════════════
                    _lead_clicks_done = 0
                    if config.interaction.lead_clicks_max > 0 and not config.traffic.is_ouo_io_mode():
                        try:
                            _FAST_CTA_SEL = "a.btn, button.btn, .cta-button, .btn-download, a[href*='download'], a[href*='install']"
                            el = page.locator(_FAST_CTA_SEL).first
                            if el.is_visible(timeout=200):
                                el.click(timeout=800, no_wait_after=True)
                                _lead_clicks_done = 1
                                log.info("[%s] 🎯 Lead CTA clicked: %s", self.session_id[:8], _FAST_CTA_SEL[:30])
                                time.sleep(0.3)
                        except Exception:
                            pass

                    # ---- Collect metrics ----------------------------------
                    pm: PageTimingMetrics = collect_metrics(page, page.url, status_code)
                    pm.total_wall_clock_ms = round(wall_clock_ms, 1)
                    metrics_dict = pm.to_dict()
                    metrics_aggregator.add(pm)
                    self._slog.record(EventType.PAGE_METRICS, metrics_dict)

                    # ---- Dwell / Interaction Phase ────────────────────────────
                    dwell_start = time.monotonic()

                    if config.traffic.mode == "adx":
                        # ── ADX mode: article impression sequence ──────────────
                        log.info("[%s] 📺 ADX mode — running article impression sequence",
                                 self.session_id[:8])
                        try:
                            _adx_engine = InteractionEngine(page, self._slog, cfg=config.interaction)
                            interaction_summary = _adx_engine.run_adx_sequence(base_url=config.target_url)
                        except Exception as _adx_err:
                            log.warning("[%s] ADX flow error: %s", self.session_id[:8], _adx_err)
                            interaction_summary = {"error": str(_adx_err), "site": "adx"}

                    elif config.traffic.is_adoperator_mode():
                        # ══════════════════════════════════════════════════════════
                        # ADOPERATOR IMPRESSION GUARANTEE FLOW
                        # ══════════════════════════════════════════════════════════
                        # HOW ADOPERATOR COUNTS IMPRESSIONS (verified from page source):
                        #   1. Browser loads /redirect-zone/a97398f0
                        #      → Inline JS runs synchronously:
                        #        a. Generates/retrieves UUID from localStorage
                        #        b. Reads document.referrer (= l.facebook.com we set)
                        #        c. Builds /zone/a97398f0?frame=0&originalReferrer=...&uuid=...
                        #        d. Calls window.location.replace(zoneUrl) → IMPRESSION HIT
                        #   2. AdOperator server receives GET /zone/a97398f0?... → COUNTS IMPRESSION ✅
                        #   3. Server responds with 302 redirect → offer/landing page
                        #
                        # WHAT WE GUARANTEE:
                        #   • document.referrer = l.facebook.com (set via referer header in goto())
                        #   • fbclid in URL (quality signal for AdOperator CPM fill)
                        #   • Script NOT blocked (JS must run to make the zone request)
                        #   • Image NOT blocked (1x1 pixel confirmation beacons are image type)
                        #   • wait_for_url: verify JS redirect to /zone/ completed (impression confirmed)
                        #   • Dwell 2-4s: impression viewability timer ticks on final offer page
                        # ══════════════════════════════════════════════════════════

                        log.info("[%s] ⚡ AdOperator — verifying JS redirect (impression hit)...",
                                 self.session_id[:8])

                        # ── STEP 1: Verify JS redirect fired ──────────────────────
                        # The AdOperator page uses window.location.replace() to hit /zone/<id>
                        # which is the server-side impression request. Confirm URL changed
                        # from /redirect-zone/ to /zone/ (meaning the impression was made).
                        _impression_confirmed = False
                        try:
                            # Wait up to 5s for the JS redirect to complete
                            # (normally instant — JS fires synchronously during page parse)
                            page.wait_for_url(
                                lambda u: "/zone/" in u or "/redirect-zone/" not in u,
                                timeout=5000,
                            )
                            _final_url = page.url or ""
                            if "/zone/" in _final_url:
                                _impression_confirmed = True
                                log.info("[%s] ✅ AdOperator impression HIT confirmed — URL: %s",
                                         self.session_id[:8], _final_url[:80])
                            else:
                                log.info("[%s] ✅ AdOperator redirect resolved — URL: %s",
                                         self.session_id[:8], _final_url[:80])
                                _impression_confirmed = True
                        except Exception:
                            # Timeout waiting for redirect — still proceed; zone request may have fired
                            # even if wait_for_url timed out (race condition between Playwright and JS)
                            log.warning("[%s] ⚠ AdOperator redirect wait timeout — checking final URL...",
                                        self.session_id[:8])
                            _final_url = page.url or ""
                            _impression_confirmed = "/redirect-zone/" not in _final_url

                        if not _impression_confirmed:
                            # JS didn't redirect — retry with fresh browser (clears stale state)
                            from app.browser_manager import discard_thread_browser
                            discard_thread_browser()
                            raise Exception("adoperator_js_redirect_failed: impression not confirmed — retrying")

                        # ── STEP 2: Dwell on offer page ────────────────────────────
                        # Impression already counted at zone request. Dwell adds viewability
                        # signal (time-on-page) which improves CPM fill quality score.
                        dwell_s = random.uniform(2.0, 4.0)
                        log.info("[%s] ⏱  AdOperator dwell: %.1fs (viewability + CPM quality signal)",
                                 self.session_id[:8], dwell_s)
                        time.sleep(dwell_s)


                        total_dwell_s = round(time.monotonic() - dwell_start, 1)
                        log.info("[%s] ✅ AdOperator impression complete: %.1fs | ~%dKB proxy data",
                                 self.session_id[:8], total_dwell_s,
                                 int((self._bytes_down + self._bytes_up) / 1024))
                        self._slog.record("adoperator_impression", {
                            "mode": "adoperator",
                            "dwell_s": total_dwell_s,
                            "kb_used": round((self._bytes_down + self._bytes_up) / 1024, 1),
                        })
                        interaction_summary = {
                            "mode": "adoperator",
                            "dwell_s": total_dwell_s,
                            "kb_proxy_used": round((self._bytes_down + self._bytes_up) / 1024, 1),
                        }

                    elif config.traffic.is_pinmax_mode():
                        total_dwell_s = round(time.monotonic() - dwell_start, 1)
                        interaction_summary = {
                            "mode": "pinmax",
                            "dwell_s": total_dwell_s,
                            "kb_proxy_used": round((self._bytes_down + self._bytes_up) / 1024, 1),
                        }

                    elif config.traffic.is_ouo_io_mode():
                        total_dwell_s = round(time.monotonic() - dwell_start, 1)
                        interaction_summary = {
                            "mode": "ouo_io",
                            "dwell_s": total_dwell_s,
                            "kb_proxy_used": round((self._bytes_down + self._bytes_up) / 1024, 1),
                            "turnstile_token_len": self._ouo_step1_token_len,
                            "x_token_len": self._ouo_post_token_len,
                            "go_post_seen": self._ouo_post_seen,
                            "getlink_post_seen": self._ouo_getlink_post_seen,
                            "step2_clicked": self._ouo_step2_clicked,
                        }

                    else:
                        # ── Ultra-Fast Smartlink Mode: Guaranteed CPM Impression & Viewability ──
                        dwell_s = random.uniform(
                            config.session.post_load_wait_min_s,
                            config.session.post_load_wait_max_s,
                        )
                        log.info("[%s] ⏱  Smartlink dwell: %.1fs (Ultra-Speed Impression Mode)",
                                 self.session_id[:8], dwell_s)

                        # Step 1: Smooth scroll down ~350px (triggers viewport intersection & ad viewability)
                        try:
                            page.evaluate("window.scrollBy({top: 350, behavior: 'smooth'});")
                        except Exception:
                            pass

                        # Step 2: Dwell while impression beacons and ad tracking scripts fire
                        time.sleep(max(1.0, dwell_s * 0.65))

                        # Step 3: Subtle micro-scroll back (natural user engagement signal)
                        try:
                            page.evaluate("window.scrollBy({top: -80, behavior: 'smooth'});")
                        except Exception:
                            pass
                        time.sleep(max(0.5, dwell_s * 0.35))

                        total_dwell_s = round(time.monotonic() - dwell_start, 1)
                        log.info("[%s] ✅ Smartlink dwell complete: %.1fs", self.session_id[:8], total_dwell_s)
                        self._slog.record("humanized_dwell", {
                            "target_dwell_s": round(dwell_s, 1),
                            "actual_dwell_s": total_dwell_s,
                        })
                        interaction_summary = {"mode": "smartlink", "dwell_s": total_dwell_s}


                    result_status = "passed"
                    break  # success – exit retry loop

            except Exception as exc:
                error_msg = str(exc)
                log.warning(
                    "[%s] Attempt %d/%d failed: %s",
                    self.session_id[:8], attempt, _effective_max_retries + 1, exc,
                )
                self._slog.record(EventType.ERROR, {"attempt": attempt, "error": error_msg})

                if attempt <= _effective_max_retries:
                    from app.browser_manager import discard_thread_browser
                    discard_thread_browser()
                    # ── Reset per-session byte tracking for the fresh IP ──
                    # The new proxy IP is clean — don't carry over CF-PAT failures
                    # or byte counts from the previous (flagged) IP.
                    self._bytes_down = 0
                    self._bytes_up = 0
                    self._req_count = 0
                    self._cf_pat_failures = 0
                    self._byte_cap_hit = False
                    self._slog.record(EventType.RETRY, {"attempt": attempt + 1})
                    time.sleep(cfg_s.retry_backoff_s)

        # ---- Finalise ----------------------------------------------------
        duration_s = round(time.monotonic() - start_ts, 2)
        end_dt = datetime.now(timezone.utc)

        # ── Proxy bandwidth summary ────────────────────────────────────────
        kb_down  = self._bytes_down / 1024
        kb_up    = self._bytes_up   / 1024
        kb_total = kb_down + kb_up
        mb_down  = kb_down  / 1024   # still saved in report for reference
        mb_up    = kb_up    / 1024
        mb_total = kb_total / 1024
        log.info(
            "[%s] ✅ DONE  status=%-6s  ip=%-15s  location=%s, %s  duration=%.1fs",
            self.session_id[:8],
            result_status.upper(),
            geo_info.get("query", "?"),
            geo_info.get("city", "?"),
            geo_info.get("country", "?"),
            duration_s,
        )
        log.info(
            "[%s] 📶 Proxy Data  ↓ %.1f KB  ↑ %.1f KB  total %.1f KB  (%d reqs)",
            self.session_id[:8], kb_down, kb_up, kb_total, self._req_count,
        )

        self._slog.record(EventType.SESSION_END, {
            "status": result_status,
            "duration_s": duration_s,
            "http_errors": len(self._http_errors),
            "new_tabs": len(self._new_tab_events),
            "ip": geo_info.get("query"),
            "location": f"{geo_info.get('city')}, {geo_info.get('country')}",
            "proxy_data": {
                "requests": self._req_count,
                "bytes_down": self._bytes_down,
                "bytes_up": self._bytes_up,
                "mb_down": round(mb_down, 3),
                "mb_up": round(mb_up, 3),
                "mb_total": round(mb_total, 3),
            },
        })
        # ── Live grid: session finished ───────────────────────────────────────
        try:
            _total_kb = (self._bytes_down + self._bytes_up) / 1024
            _ls.finish(self.session_id,
                       status=result_status,
                       kb=_total_kb)
        except Exception:
            pass


        json_log = self._slog.flush_json()
        self._slog.close()
        log_files = [str(json_log)]

        sr = SessionResult(
            session_id=self.session_id,
            status=result_status,
            target_url=_session_url,
            start_time=start_dt.isoformat(),
            end_time=end_dt.isoformat(),
            duration_s=duration_s,
            viewport_label=viewport_label,
            locale=locale,
            timezone=tz,
            proxy_used=proxy_server,
            referrer_used=referrer_used,
            referrer=referrer_used,
            geo_info=geo_info,
            metrics=metrics_dict,
            interaction_summary=interaction_summary,
            popup_events=self._popup_events,
            new_tab_events=self._new_tab_events,
            http_errors=self._http_errors,
            error_message=error_msg,
            browser_version=browser_version,
            log_files=log_files,
        )
        aggregator.add(sr.__dict__)
        try:
            from app.security.telemetry import telemetry_dispatcher
            telemetry_dispatcher.record_session(sr.__dict__)
        except Exception:
            pass
        return sr

