"""
config.py – Centralised configuration for the Linux QA & Traffic Automation Engine.

Linux & Cross-Platform Compatible:
  • Uses local project directories (no Windows %APPDATA% dependencies)
  • Auto-detects urls.txt and multi_proxies.txt in workspace root
  • Workers scalable up to 200 to utilize 100% of the VPS/VM capacity
  • Headless mode enabled by default for Linux terminals and servers
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv

# Base Directory: root of the project
BASE_DIR = Path(__file__).resolve().parent.parent
PROFILES_DIR = BASE_DIR / "tmp_profiles"
LOGS_DIR = BASE_DIR / "logs"
REPORTS_DIR = BASE_DIR / "reports"

for _d in (PROFILES_DIR, LOGS_DIR, REPORTS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# Load .env if present
_env_path = BASE_DIR / ".env"
if _env_path.exists():
    load_dotenv(_env_path)
else:
    load_dotenv()


# ---------------------------------------------------------------------------
# Target URLs — multi-URL support
# ---------------------------------------------------------------------------
def get_urls_file() -> Path:
    """Return the persistent path for urls.txt."""
    candidates = [
        BASE_DIR / "urls.txt",
        Path.cwd() / "urls.txt",
    ]
    for c in candidates:
        if c.exists():
            return c
    return BASE_DIR / "urls.txt"

_URLS_FILE = get_urls_file()
TARGET_URLS: List[str] = []

def reload_target_urls() -> List[str]:
    """Reload URLs from urls.txt or environment."""
    global TARGET_URLS, TARGET_URL, _URLS_FILE
    _URLS_FILE = get_urls_file()
    if _URLS_FILE.exists():
        try:
            urls = [
                line.strip()
                for line in _URLS_FILE.read_text(encoding="utf-8").splitlines()
                if line.strip() and not line.strip().startswith("#")
            ]
            if urls:
                TARGET_URLS = urls
                TARGET_URL = TARGET_URLS[0]
                return TARGET_URLS
        except Exception:
            pass

    _env_url = os.getenv("TARGET_URL", "").strip()
    if _env_url:
        TARGET_URLS = [_env_url]
        TARGET_URL = _env_url
    return TARGET_URLS

reload_target_urls()

# Convenience alias — first URL
TARGET_URL: str = TARGET_URLS[0] if TARGET_URLS else ""
DEFAULT_API_GATEWAY: str = os.getenv("API_GATEWAY", "https://ronnie-cartel-api.spkchaudhary9211.workers.dev/api")
ADX_BASE_URL: str = os.getenv("ADX_BASE_URL", "https://monutech.in/article/")


# ---------------------------------------------------------------------------
# Browser
# ---------------------------------------------------------------------------
@dataclass
class BrowserConfig:
    browser: str = os.getenv("BROWSER", "chromium")          # chromium (recommended for Linux) | firefox | webkit
    headless: bool = os.getenv("HEADLESS", "true").lower() != "false"
    slow_mo_ms: int = int(os.getenv("SLOW_MO_MS", "0"))

    # Mobile profiles used by real Android & iOS users
    viewport_profiles: List[dict] = field(default_factory=lambda: [
        {"width": 360,  "height": 800,  "label": "mobile-android-std",    "is_mobile": True},
        {"width": 390,  "height": 844,  "label": "mobile-samsung-s22",    "is_mobile": True},
        {"width": 412,  "height": 915,  "label": "mobile-pixel-7",        "is_mobile": True},
        {"width": 360,  "height": 780,  "label": "mobile-redmi-note",     "is_mobile": True},
        {"width": 393,  "height": 851,  "label": "mobile-oneplus-11",     "is_mobile": True},
        {"width": 384,  "height": 854,  "label": "mobile-moto-g",         "is_mobile": True},
        {"width": 412,  "height": 892,  "label": "mobile-pixel-6",        "is_mobile": True},
        {"width": 360,  "height": 760,  "label": "mobile-xiaomi-12",      "is_mobile": True},
        {"width": 375,  "height": 667,  "label": "mobile-android-small",  "is_mobile": True},
        {"width": 414,  "height": 896,  "label": "mobile-android-max",    "is_mobile": True},
        {"width": 375,  "height": 812,  "label": "mobile-iphone-x",       "is_mobile": True},
        {"width": 390,  "height": 844,  "label": "mobile-iphone-14",      "is_mobile": True},
        {"width": 393,  "height": 852,  "label": "mobile-iphone-15",      "is_mobile": True},
        {"width": 430,  "height": 932,  "label": "mobile-iphone-15-plus", "is_mobile": True},
        {"width": 375,  "height": 667,  "label": "mobile-iphone-se",      "is_mobile": True},
        {"width": 414,  "height": 896,  "label": "mobile-iphone-11-pro",  "is_mobile": True},
        {"width": 428,  "height": 926,  "label": "mobile-iphone-13-max",  "is_mobile": True},
        {"width": 320,  "height": 568,  "label": "mobile-iphone-5s",      "is_mobile": True},
        {"width": 1366, "height": 768,  "label": "desktop-hd",            "is_mobile": False},
    ])

    locale_profiles: List[str] = field(default_factory=lambda: [
        "en-US", "en-GB", "en-IN", "de-DE", "fr-FR",
    ])

    timezone_profiles: List[str] = field(default_factory=lambda: [
        "America/New_York", "Europe/London", "Asia/Kolkata",
        "Asia/Tokyo", "Australia/Sydney",
    ])

    user_agent_override: Optional[str] = os.getenv("USER_AGENT_OVERRIDE", None)
    stealth_enabled: bool = os.getenv("STEALTH_ENABLED", "true").lower() != "false"
    user_agent_list_file: Optional[str] = os.getenv("USER_AGENT_LIST_FILE", None)


# ---------------------------------------------------------------------------
# Session / Concurrency Configuration
# ---------------------------------------------------------------------------
@dataclass
class SessionConfig:
    # Default workers: 30 or auto-tuned to VM capacity
    workers: int = int(os.getenv("WORKERS", "30"))          # 1–200
    max_sessions: int = int(os.getenv("MAX_SESSIONS", "0")) # 0 = Continuous mode (never stop until command given)
    session_timeout_s: int = int(os.getenv("SESSION_TIMEOUT_S", "90"))
    session_duration_s: int = int(os.getenv("SESSION_DURATION", "0"))  # 0 = No time limit (continuous)
    auto_adjust_workers: bool = os.getenv("AUTO_ADJUST_WORKERS", "false").lower() == "true"
    continuous: bool = os.getenv("CONTINUOUS", "true").lower() == "true"

    post_load_wait_min_s: int = int(os.getenv("POST_LOAD_WAIT_MIN", "3"))
    post_load_wait_max_s: int = int(os.getenv("POST_LOAD_WAIT_MAX", "5"))
    screenshots_enabled: bool = os.getenv("SCREENSHOTS_ENABLED", "false").lower() == "true"
    load_event: str = os.getenv("LOAD_EVENT", "domcontentloaded")
    page_load_timeout_ms: int = int(os.getenv("PAGE_LOAD_TIMEOUT_MS", "45000"))
    max_retries: int = int(os.getenv("MAX_RETRIES", "4"))
    retry_backoff_s: float = float(os.getenv("RETRY_BACKOFF_S", "1.0"))
    session_start_gap_s: float = float(os.getenv("SESSION_START_GAP_S", "0.20"))


# ---------------------------------------------------------------------------
# Interaction Engine
# ---------------------------------------------------------------------------
@dataclass
class InteractionConfig:
    scroll_steps_min: int = int(os.getenv("SCROLL_STEPS_MIN", "3"))
    scroll_steps_max: int = int(os.getenv("SCROLL_STEPS_MAX", "8"))
    scroll_pause_min_ms: int = int(os.getenv("SCROLL_PAUSE_MIN_MS", "600"))
    scroll_pause_max_ms: int = int(os.getenv("SCROLL_PAUSE_MAX_MS", "2000"))
    scroll_px_min: int = int(os.getenv("SCROLL_PX_MIN", "200"))
    scroll_px_max: int = int(os.getenv("SCROLL_PX_MAX", "600"))
    open_article_probability: float = float(os.getenv("OPEN_ARTICLE_PROB", "0.7"))
    return_to_home_probability: float = float(os.getenv("RETURN_HOME_PROB", "0.9"))
    click_ads: bool = False
    lead_clicks_enabled: bool = os.getenv("LEAD_CLICKS_ENABLED", "true").lower() != "false"
    lead_clicks_max: int = int(os.getenv("LEAD_CLICKS_MAX", "2"))
    max_articles_adx: int = int(os.getenv("MAX_ARTICLES_ADX", "3"))


# ---------------------------------------------------------------------------
# Country-to-Device Rules & Geo Profiles
# ---------------------------------------------------------------------------
TIER_1_COUNTRIES: list[str] = [
    "us", "gb", "ca", "au", "de", "fr", "nl", "ch", "se", "no",
    "dk", "fi", "at", "be", "nz", "sg", "jp", "kr", "ae", "sa",
    "kw", "qa", "bh", "om"
]

TIER_2_COUNTRIES: list[str] = [
    "es", "it", "pt", "pl", "cz", "ro", "hu", "bg", "hr", "sk",
    "gr", "ua", "rs", "il", "tr", "mx", "br", "ar", "cl", "co",
    "pe", "za", "eg", "ma", "ng", "gh", "ke"
]

TIER_3_COUNTRIES: list[str] = [
    "in", "pk", "bd", "lk", "np", "id", "ph", "my", "th", "vn",
    "mm", "tw", "hk", "cn", "cm", "tz", "ug", "et", "ci", "sn",
    "ru", "kz", "uz", "az", "ge", "iq", "jo", "lb"
]

COUNTRY_DEVICE_RULES: dict[str, list[str]] = {
    c: ["android", "ios", "windows"] for c in TIER_1_COUNTRIES + TIER_2_COUNTRIES
}
for c in TIER_3_COUNTRIES:
    COUNTRY_DEVICE_RULES[c] = ["android", "ios"] if c in ["pk", "bd", "lk", "np", "mm", "tz", "ug", "et", "ci", "sn", "uz", "az", "ge", "iq", "jo", "lb"] else ["android", "ios", "windows"]

COUNTRY_GEO_MAP: dict[str, dict[str, str]] = {
    "us": {"name": "USA", "locale": "en-US", "tz": "America/New_York"},
    "gb": {"name": "Great Britain", "locale": "en-GB", "tz": "Europe/London"},
    "ca": {"name": "Canada", "locale": "en-CA", "tz": "America/Toronto"},
    "au": {"name": "Australia", "locale": "en-AU", "tz": "Australia/Sydney"},
    "de": {"name": "Germany", "locale": "de-DE", "tz": "Europe/Berlin"},
    "fr": {"name": "France", "locale": "fr-FR", "tz": "Europe/Paris"},
    "nl": {"name": "Netherlands", "locale": "nl-NL", "tz": "Europe/Amsterdam"},
    "in": {"name": "India", "locale": "en-IN", "tz": "Asia/Kolkata"},
    "br": {"name": "Brazil", "locale": "pt-BR", "tz": "America/Sao_Paulo"},
    "id": {"name": "Indonesia", "locale": "id-ID", "tz": "Asia/Jakarta"},
    "ph": {"name": "Philippines", "locale": "en-PH", "tz": "Asia/Manila"},
    "pk": {"name": "Pakistan", "locale": "ur-PK", "tz": "Asia/Karachi"},
    "sg": {"name": "Singapore", "locale": "en-SG", "tz": "Asia/Singapore"},
    "jp": {"name": "Japan", "locale": "ja-JP", "tz": "Asia/Tokyo"},
}

DEFAULT_TARGET_COUNTRIES: list[str] = list(COUNTRY_DEVICE_RULES.keys())

CPM_COUNTRY_WEIGHTS: dict[str, int] = {
    "in": 22, "br": 12, "us": 9, "id": 8, "ph": 7, "fr": 6, "mx": 6, "de": 5, "th": 5,
    "pk": 5, "gb": 4, "tr": 4, "bd": 4, "vn": 4, "eg": 4, "ar": 4, "co": 3, "ng": 3,
    "it": 3, "es": 3, "pl": 3, "ca": 3, "sa": 3, "ae": 3, "tw": 3, "au": 2, "sg": 2,
}


# ---------------------------------------------------------------------------
# Proxy Configuration
# ---------------------------------------------------------------------------
def get_default_proxy_file() -> Optional[str]:
    for fn in ("multi_proxies.txt", "proxies.txt"):
        p = BASE_DIR / fn
        if p.exists():
            return str(p)
        p_cwd = Path.cwd() / fn
        if p_cwd.exists():
            return str(p_cwd)
    return None

_default_pfile = get_default_proxy_file()

@dataclass
class ProxyConfig:
    enabled: bool = os.getenv("PROXY_ENABLED", "true" if _default_pfile else "false").lower() == "true"
    proxy_list_file: Optional[str] = os.getenv("PROXY_LIST_FILE", _default_pfile)
    rotation_strategy: str = os.getenv("PROXY_ROTATION", "round_robin")
    timeout_s: int = int(os.getenv("PROXY_TIMEOUT_S", "10"))
    verify_on_start: bool = os.getenv("PROXY_VERIFY", "false").lower() == "true"
    active_countries: List[str] = field(default_factory=lambda: [
        c.strip().lower() for c in os.getenv("TARGET_COUNTRIES", ",".join(DEFAULT_TARGET_COUNTRIES)).split(",") if c.strip()
    ])
    device_mode: str = os.getenv("DEVICE_MODE", "all")
    anti_detect_mode: bool = os.getenv("ANTI_DETECT_MODE", "true").lower() != "false"


# ---------------------------------------------------------------------------
# Android / ADB (optional)
# ---------------------------------------------------------------------------
@dataclass
class ADBConfig:
    enabled: bool = os.getenv("ADB_ENABLED", "false").lower() == "true"
    adb_path: str = os.getenv("ADB_PATH", "adb")
    device_serial: Optional[str] = os.getenv("ADB_DEVICE_SERIAL", None)
    airplane_mode_on_cmd: str = "settings put global airplane_mode_on 1"
    airplane_mode_off_cmd: str = "settings put global airplane_mode_on 0"
    broadcast_cmd: str = "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state {state}"
    connectivity_wait_s: int = int(os.getenv("ADB_CONNECTIVITY_WAIT_S", "15"))
    toggle_duration_s: float = float(os.getenv("ADB_TOGGLE_DURATION_S", "3.0"))


# ---------------------------------------------------------------------------
# Traffic / Referrer Source
# ---------------------------------------------------------------------------
@dataclass
class TrafficSourceConfig:
    SOURCES = {
        "google": ["https://www.google.com/"],
        "facebook": ["https://l.facebook.com/", "https://lm.facebook.com/"],
        "facebook_app": ["https://l.facebook.com/", "https://lm.facebook.com/"],
        "instagram": ["https://l.instagram.com/"],
        "whatsapp": ["https://web.whatsapp.com/", "https://api.whatsapp.com/"],
        "telegram": ["https://t.me/"],
        "twitter": ["https://t.co/"],
        "youtube": ["https://www.youtube.com/"],
        "reddit": ["https://www.reddit.com/"],
        "tiktok": ["https://www.tiktok.com/"],
    }

    mode: str = os.getenv("TRAFFIC_SOURCE_MODE", "facebook_app").lower()
    custom_referrer: Optional[str] = os.getenv("CUSTOM_REFERRER", None)
    fb_post_url: Optional[str] = os.getenv("FB_POST_URL", None)
    ig_post_url: Optional[str] = os.getenv("IG_POST_URL", None)
    fb_cookies: Optional[str] = os.getenv("FB_COOKIES", None)
    ig_cookies: Optional[str] = os.getenv("IG_COOKIES", None)

    def is_facebook_mode(self) -> bool:
        m = (self.mode or "").strip().lower()
        return m in ("facebook", "facebook_app", "facebook.com", "l.facebook.com", "fb", "fb_app", "adx") or "facebook" in m

    def is_adoperator_mode(self) -> bool:
        return (self.mode or "").strip().lower() == "adoperator"

    def is_pinmax_mode(self) -> bool:
        return (self.mode or "").strip().lower() == "pinmax"

    def is_ouo_io_mode(self) -> bool:
        """OUO.io shortlink mode — auto-solve Cloudflare Turnstile, timer countdown, and Get Link."""
        if (self.mode or "").strip().lower() in ("ouo_io", "ouo.io", "ouo"):
            return True
        urls = [TARGET_URL] + (TARGET_URLS or [])
        return any("ouo.io" in (u or "").lower() or "ouo.press" in (u or "").lower() for u in urls if u)

    def is_fb_post_click_mode(self) -> bool:
        return (self.mode or "").strip().lower() == "fb_post_click"

    def is_fb_post_auth_mode(self) -> bool:
        return (self.mode or "").strip().lower() == "fb_post_auth"

    def is_ig_post_click_mode(self) -> bool:
        return (self.mode or "").strip().lower() == "ig_post_click"

    def is_ig_post_auth_mode(self) -> bool:
        return (self.mode or "").strip().lower() == "ig_post_auth"

    def is_any_fb_post_mode(self) -> bool:
        return self.is_fb_post_click_mode() or self.is_fb_post_auth_mode()

    def is_any_ig_post_mode(self) -> bool:
        return self.is_ig_post_click_mode() or self.is_ig_post_auth_mode()

    def is_any_social_post_mode(self) -> bool:
        return self.is_any_fb_post_mode() or self.is_any_ig_post_mode()

    def get_referrer(self) -> Optional[str]:
        import random
        m = (self.mode or "facebook_app").strip().lower()
        if m in ("direct", "none", "off", ""):
            return None
        if m == "custom":
            return self.custom_referrer if self.custom_referrer else None
        if self.is_facebook_mode():
            return random.choices(self.SOURCES["facebook_app"], weights=[85, 15], k=1)[0]
        if m == "rotate" or m == "all":
            all_urls = []
            for k, urls in self.SOURCES.items():
                all_urls.extend(urls)
            return random.choice(all_urls)
        if m in self.SOURCES:
            return random.choice(self.SOURCES[m])
        return m if m.startswith("http") else None


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@dataclass
class DashboardConfig:
    enabled: bool = os.getenv("DASHBOARD_ENABLED", "true").lower() != "false"
    host: str = os.getenv("DASHBOARD_HOST", "0.0.0.0")  # Bind to 0.0.0.0 for VPS access
    port: int = int(os.getenv("DASHBOARD_PORT", "8765"))
    refresh_interval_s: int = int(os.getenv("DASHBOARD_REFRESH_S", "3"))


# ---------------------------------------------------------------------------
# Root config object
# ---------------------------------------------------------------------------
@dataclass
class AppConfig:
    base_dir: Path = BASE_DIR
    target_url: str = TARGET_URL
    target_urls: List[str] = field(default_factory=lambda: TARGET_URLS)
    adx_base_url: str = ADX_BASE_URL
    browser: BrowserConfig = field(default_factory=BrowserConfig)
    session: SessionConfig = field(default_factory=SessionConfig)
    interaction: InteractionConfig = field(default_factory=InteractionConfig)
    proxy: ProxyConfig = field(default_factory=ProxyConfig)
    adb: ADBConfig = field(default_factory=ADBConfig)
    traffic: TrafficSourceConfig = field(default_factory=TrafficSourceConfig)
    dashboard: DashboardConfig = field(default_factory=DashboardConfig)
    logs_dir: Path = LOGS_DIR
    reports_dir: Path = REPORTS_DIR
    profiles_dir: Path = PROFILES_DIR

    def validate(self) -> None:
        if self.session.workers < 1 or self.session.workers > 200:
            raise ValueError("workers must be between 1 and 200")
        if not self.target_urls:
            raise ValueError("No target URLs configured. Add URLs to urls.txt or set TARGET_URL in .env")
        for u in self.target_urls:
            if not u.startswith(("http://", "https://")):
                raise ValueError(f"Invalid target URL: {u}")


# Module-level singleton
config = AppConfig()
