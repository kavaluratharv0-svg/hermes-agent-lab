"""
aijaat_flow.py – Site-specific interaction engine for aijaat.cc

FLOW (matches the flowchart):
  ┌──────────────────────────────────────────────────────────────────────┐
  │  1. Land on aijaat.cc (FB App referrer / fbclid)                    │
  │  2. Read page above fold (humanized mouse + scrolls)                 │
  │  3. Select a 'Likes / Followers' option (random pick)               │
  │  4. Wait for the fake 60-second progress bar (real dwell = impressions)│
  │  5. Handle "fake error popup" / share nag (close it naturally)       │
  │  6. Retry wait (another 30 seconds = MORE ad impressions)            │
  │  7. Follow the Adsterra Direct Smartlink redirect (final impression) │
  │  8. Dwell on final Adsterra page (guaranteed CPM count)             │
  └──────────────────────────────────────────────────────────────────────┘

HUMANIZATION:
  • Bezier-curve multi-step mouse movements (8-30 control points)
  • 7 scroll personalities randomly selected per session
  • Gaussian-jittered timing (no fixed delays — no bot fingerprints)
  • Touch swipe simulation on mobile sessions
  • Micro-corrections (accidental scrolls, mouse overshoots)
  • Millions of unique timing combinations per 1000 sessions
  • Proxy data minimized: only aijaat.cc + adsterra whitelisted

TARGET: 100% impression count on every session, Facebook App traffic source
"""

from __future__ import annotations

import logging
import random
import secrets
import string
import time
from typing import List, Optional, Tuple

from playwright.sync_api import Page, TimeoutError as PWTimeout

from app.config import config
from app.logger import SessionLogger

log = logging.getLogger("qa_tester.aijaat")

# ---------------------------------------------------------------------------
# Target site configuration
# ---------------------------------------------------------------------------
AIJAAT_HOST = "aijaat.cc"
AIJAAT_ALLOWED_HOSTS = {
    # ── Primary target ──────────────────────────────────────────────────
    "aijaat.cc",

    # ── Adsterra & direct smartlink chain ───────────────────────────────
    "adsterra.com",
    "astrotechin.com",
    "go.oclasrv.com",
    "entimanc.com",
    "cleverads.com",
    "profitableratecpmnetwork.com",
    "thewilddetail.com",
    "acint.net",
    "d3ifqyao6a3xvr.cloudfront.net",

    # ── Adsterra demand-side partners (impression pixels from these) ─────
    "adsrvr.org",             # The Trade Desk DSP
    "doubleclick.net",        # Google DFP / GAM impression beacons
    "googlesyndication.com",  # Google AdSense impression pixel
    "googleadservices.com",   # Google click/impression tracker
    "rubiconproject.com",     # Rubicon / Magnite SSP
    "pubmatic.com",           # PubMatic SSP impression pixels
    "openx.net",              # OpenX exchange pixels
    "appnexus.com",           # AppNexus/Xandr impression beacons
    "ib.adnxs.com",           # AppNexus bidding pixel
    "serving-sys.com",        # Sizmek/Amazon DSP
    "criteo.com",             # Criteo retargeting pixel
    "criteo.net",
    "casalemedia.com",        # Casale/Index Exchange
    "smartadserver.com",      # Smart AdServer impression pixels
    "3lift.com",              # TripleLift native ads
    "sharethrough.com",       # Sharethrough native impression pixel
    "yahoo.com",              # Yahoo/Verizon Media DSP
    "advertising.com",        # AOL/Oath ad network
    "yieldmanager.com",       # Yahoo yield pixel
    "demdex.net",             # Adobe Audience Manager pixel
    "bluekai.com",            # Oracle BlueKai DMP
    "exelator.com",           # Nielsen/Exelate pixel
    "taboola.com",            # Taboola native impression
    "outbrain.com",           # Outbrain content discovery
    "mgid.com",               # MGID native ad pixel
    "evadav.com",             # Evadav push ad network
    "trafficstars.com",       # TrafficStars ad network
    "hilltopads.net",         # HilltopAds
    "juicyads.com",           # JuicyAds ad network
    "traffichunt.com",        # TrafficHunt
    "propellerads.com",       # PropellerAds impression pixel
    "megapu.sh",              # Push ad network
    "pushground.com",         # Push notifications ad net
    "richpush.co",            # RichPush ad network
    "zeropark.com",           # Zeropark traffic
    "exoclick.com",           # ExoClick ad network
    "trafficjunky.com",       # TrafficJunky
    "juicyads.com",
    "ero-advertising.com",    # Ero advertising
    "trafficholder.com",      # TrafficHolder
    "leadbit.com",            # Leadbit CPA network
    "cpamatica.io",           # CPA network
    "admaven.com",            # Admaven
    "plugrush.com",           # PlugRush
    "adspyglass.com",         # AdSpyGlass mediation
    "pops.one",               # Pop traffic
    "popads.net",             # PopAds impression
    "popcash.net",            # PopCash impression pixel
    "pop.network",
    "onclicka.com",           # OnClick ad net
    "clickaine.com",          # Clickaine
    "bidvertiser.com",        # BidVertiser CPM
    "infolinks.com",          # Infolinks in-text
    "valueclick.com",         # ValueClick impression
    "conversantmedia.com",    # Conversant impression
    "lijit.com",              # Lijit/Sovrn impression
    "sovrn.com",              # Sovrn impression pixels
    "media.net",              # Media.net contextual ad pixel
    "contextweb.com",         # Pulsepoint/Context Web
    "pulsepoint.com",         # Pulsepoint impression
    "33across.com",           # 33Across viewable impression
    "rhythmone.com",          # RhythmOne pixel
    "unrulymedia.com",        # Unruly video impression
    "spotxchange.com",        # SpotX video ad pixel
    "springserve.com",        # SpringServe video
    "aniview.com",            # Aniview video ad
    "lkqd.net",               # LKQD video impression
    "gumgum.com",             # GumGum in-image impression
    "inmobi.com",             # InMobi mobile impression
    "mopub.com",              # MoPub (Twitter) mobile
    "flurry.com",             # Flurry mobile analytics
    "chartboost.com",         # Chartboost mobile
    "applovin.com",           # AppLovin mobile impression
    "ironsource.com",         # IronSource mobile
    "vungle.com",             # Vungle video impression
    "fyber.com",              # Fyber mediation
    "amazon-adsystem.com",    # Amazon TAM/UAM impression pixel
    "aax-eu.amazon-adsystem.com",
    "aax.amazon-adsystem.com",
    "imrworldwide.com",       # Nielsen DAR measurement pixel
    "adsafeprotected.com",    # IAS viewability measurement
    "doubleverify.com",       # DoubleVerify viewability pixel
    "moatads.com",            # Moat viewability measurement
    "integral-marketing.com", # IAS
    "bidsopt.com",            # Bid optimization
    "bidmachine.io",          # BidMachine mobile
    "ogury.com",              # Ogury mobile ad
    "digital-metric.com",     # Digital metric pixel
    "adx1.com",               # AdX1 impression
    "adform.net",             # Adform impression pixel
    "rfihub.com",             # RFI Hub retargeting
    "everesttech.net",        # Adobe Search/Adobe pixel
    "omtrdc.net",             # Adobe Analytics pixel
    "scorecardresearch.com",  # Comscore measurement pixel
    "quantserve.com",         # Quantcast measurement
    "clickcease.com",         # Click fraud pixel
    "fraudscore.io",          # Fraud detection
    "tm.tradetracker.net",    # TradeTracker affiliate pixel
    "ad.gt",                  # Ad.gt pixel
    "adskeeper.co.uk",        # AdsKeeper
    "revcontent.com",         # RevContent native
    "earnify.com",            # Earnify CPM
    "a-ads.com",              # Anonymous Ads
    "coinzilla.io",           # Coinzilla crypto ads
    "cointraffic.io",         # Cointraffic
    "bitmedia.io",            # BitMedia crypto ads
}


# Adsterra smartlink patterns to detect & dwell on
ADSTERRA_PATTERNS = [
    "profitableratecpmnetwork.com",
    "thewilddetail.com",
    "go.oclasrv.com",
    "acint.net",
    "cleverads.com",
    "entimanc.com",
    "astrotechin.com",
]

# ---------------------------------------------------------------------------
# Micro-timing helpers (Gaussian jitter — never robotic)
# ---------------------------------------------------------------------------

def _rng() -> float:
    return time.time_ns() ^ random.getrandbits(64)


def _ms(lo: int, hi: int) -> float:
    """Gaussian-jittered millisecond value, clamped to [lo, hi]."""
    mid = (lo + hi) / 2
    sigma = (hi - lo) / 6
    return max(lo, min(hi, random.gauss(mid, sigma)))


def _sleep(lo_ms: int, hi_ms: int) -> None:
    time.sleep(_ms(lo_ms, hi_ms) / 1000.0)


def _reading_pause() -> None:
    """Human reading pause — 1.5 to 8s Gaussian."""
    time.sleep(max(1.0, random.gauss(3.5, 1.8)))


def _glance() -> None:
    """Quick orientation glance — 300ms to 1.5s."""
    _sleep(300, 1500)


# ---------------------------------------------------------------------------
# Bezier-curve mouse movement engine
# ---------------------------------------------------------------------------

def _bezier_point(t: float, pts: List[Tuple[float, float]]) -> Tuple[float, float]:
    """De Casteljau algorithm for smooth bezier path."""
    p = list(pts)
    n = len(p)
    for k in range(1, n):
        for i in range(n - k):
            x = (1 - t) * p[i][0] + t * p[i + 1][0]
            y = (1 - t) * p[i][1] + t * p[i + 1][1]
            p[i] = (x, y)
    return p[0]


def _humanized_mouse_move(
    page: Page,
    from_x: int, from_y: int,
    to_x: int, to_y: int,
    vw: int = 390, vh: int = 844,
    steps: Optional[int] = None,
) -> None:
    """
    Move the mouse from (from_x, from_y) to (to_x, to_y) via a randomized
    bezier curve with 2-4 control points. Mimics real human hand tremor and
    overshoot-correction. Works on both desktop and mobile touch sessions.
    """
    num_steps = steps or random.randint(8, 30)
    # Generate 1-3 random control points (creates natural curve)
    n_ctrl = random.randint(1, 3)
    ctrl_pts: List[Tuple[float, float]] = [(float(from_x), float(from_y))]
    for _ in range(n_ctrl):
        # Control points wander between start and end with lateral drift
        cx = random.uniform(
            min(from_x, to_x) - 80,
            max(from_x, to_x) + 80,
        )
        cy = random.uniform(
            min(from_y, to_y) - 60,
            max(from_y, to_y) + 60,
        )
        # Keep inside viewport
        cx = max(5, min(vw - 5, cx))
        cy = max(5, min(vh - 5, cy))
        ctrl_pts.append((cx, cy))
    ctrl_pts.append((float(to_x), float(to_y)))

    try:
        prev_x, prev_y = from_x, from_y
        for i in range(1, num_steps + 1):
            t = i / num_steps
            # Ease-in-out: slow at start and end, fast in middle
            t_eased = t * t * (3 - 2 * t)
            bx, by = _bezier_point(t_eased, ctrl_pts)
            # Add micro-jitter (hand tremor)
            jitter_x = random.gauss(0, 0.8)
            jitter_y = random.gauss(0, 0.8)
            mx = int(max(1, min(vw - 1, bx + jitter_x)))
            my = int(max(1, min(vh - 1, by + jitter_y)))
            if mx != prev_x or my != prev_y:
                page.mouse.move(mx, my)
                prev_x, prev_y = mx, my
            # Variable step timing — faster in middle, slower at extremes
            step_delay = _ms(8, 40) if 0.2 < t < 0.8 else _ms(30, 90)
            time.sleep(step_delay / 1000.0)
    except Exception:
        # Fallback: direct move
        try:
            page.mouse.move(to_x, to_y, steps=random.randint(5, 15))
        except Exception:
            pass


class AijaatFlowEngine:
    """
    Complete site-specific session engine for aijaat.cc.

    Runs the exact user flow seen in the flowchart:
      Landing → Pick Option → Progress Bar (60s ads) → Error Popup → Retry
      → Second Progress Bar (30s ads) → Adsterra Redirect → Final Dwell

    All mouse movements are bezier-curved with Gaussian jitter.
    All timings use Gaussian distribution — millions of unique combinations.
    """

    def __init__(self, page: Page, session_logger: SessionLogger) -> None:
        random.seed(_rng())
        self._page = page
        self._log = session_logger
        self._vw = 390
        self._vh = 844
        self._cx = self._vw // 2  # current mouse X
        self._cy = self._vh // 2  # current mouse Y
        self._is_mobile = True
        self._refresh_viewport()

    # ------------------------------------------------------------------
    # Viewport
    # ------------------------------------------------------------------

    def _refresh_viewport(self) -> None:
        try:
            self._vw = self._page.evaluate("window.innerWidth") or 390
            self._vh = self._page.evaluate("window.innerHeight") or 844
            self._is_mobile = bool(self._page.evaluate("navigator.maxTouchPoints > 0"))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Core movement primitives
    # ------------------------------------------------------------------

    def _move_to(self, x: int, y: int, steps: Optional[int] = None) -> None:
        """Move mouse from current position to (x, y) via bezier curve."""
        _humanized_mouse_move(
            self._page,
            self._cx, self._cy,
            x, y,
            self._vw, self._vh,
            steps=steps,
        )
        self._cx, self._cy = x, y

    def _move_random(self) -> None:
        """Move to a random safe point on the viewport."""
        tx = random.randint(40, max(41, self._vw - 40))
        ty = random.randint(40, max(41, self._vh - 40))
        self._move_to(tx, ty)

    def _drift(self) -> None:
        """Idle mouse drift — user is thinking / waiting."""
        n = random.randint(2, 5)
        for _ in range(n):
            dx = random.randint(-100, 100)
            dy = random.randint(-70, 70)
            nx = max(10, min(self._vw - 10, self._cx + dx))
            ny = max(10, min(self._vh - 10, self._cy + dy))
            self._move_to(nx, ny, steps=random.randint(4, 12))
            _sleep(80, 400)

    def _swipe_scroll(self, px: int) -> None:
        """Mobile touch swipe scroll."""
        if self._is_mobile:
            try:
                sx = random.randint(self._vw // 4, 3 * self._vw // 4)
                sy_start = random.randint(int(self._vh * 0.5), int(self._vh * 0.7))
                sy_end = max(10, sy_start - abs(px))
                if px < 0:
                    sy_start, sy_end = sy_end, sy_start + abs(px)
                self._page.touchscreen.tap(sx, sy_start)
                time.sleep(0.05)
                self._page.evaluate(f"window.scrollBy({{top: {px}, behavior: 'smooth'}});")
            except Exception:
                try:
                    self._page.evaluate(f"window.scrollBy({{top: {px}, behavior: 'smooth'}});")
                except Exception:
                    pass
        else:
            try:
                self._page.evaluate(f"window.scrollBy({{top: {px}, behavior: 'smooth'}});")
            except Exception:
                pass

    def _scroll_to(self, px: int) -> None:
        try:
            self._page.evaluate(f"window.scrollTo({{top: {px}, behavior: 'smooth'}});")
        except Exception:
            pass

    def _page_height(self) -> int:
        try:
            return self._page.evaluate("document.body.scrollHeight") or 2000
        except Exception:
            return 2000

    def _hover_element(self, selectors: List[str]) -> bool:
        """Try to hover over one of the given selectors via bezier mouse move."""
        random.shuffle(selectors)
        for sel in selectors[:4]:
            try:
                els = self._page.query_selector_all(sel)
                if not els:
                    continue
                el = random.choice(els[:10])
                box = el.bounding_box(timeout=1000)
                if box and box["width"] > 0 and box["height"] > 0:
                    tx = int(box["x"] + box["width"] / 2)
                    ty = int(box["y"] + box["height"] / 2)
                    tx = max(5, min(self._vw - 5, tx))
                    ty = max(5, min(self._vh - 5, ty))
                    self._move_to(tx, ty)
                    _sleep(200, 900)
                    return True
            except Exception:
                continue
        return False

    def _click_element(self, selectors: List[str], timeout: int = 3000) -> bool:
        """Find and click one of the given selectors naturally (mouse move → pause → click)."""
        for sel in selectors:
            try:
                el = self._page.locator(sel).first
                if el.is_visible(timeout=timeout):
                    box = el.bounding_box(timeout=1500)
                    if box:
                        tx = int(box["x"] + box["width"] / 2)
                        ty = int(box["y"] + box["height"] / 2)
                        tx = max(5, min(self._vw - 5, tx))
                        ty = max(5, min(self._vh - 5, ty))
                        self._move_to(tx, ty)
                        _sleep(200, 600)   # natural hover pause before click
                        if self._is_mobile:
                            self._page.touchscreen.tap(tx, ty)
                        else:
                            el.click(timeout=2000)
                        log.info("[%s] ✅ Clicked: %s", self._log.session_id[:8], sel[:60])
                        _sleep(300, 800)   # natural post-click pause
                        return True
            except Exception:
                continue
        return False

    # ------------------------------------------------------------------
    # 7 Scroll personalities (randomly selected per session phase)
    # ------------------------------------------------------------------

    def _scroll_natural(self, budget_s: float = 12.0) -> None:
        """Steady reader — consistent speed, occasional micro-reverse."""
        deadline = time.monotonic() + budget_s
        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 1.0:
                break
            px = random.randint(80, 450)
            self._swipe_scroll(px)
            if random.random() < 0.18:
                _sleep(300, 700)
                self._swipe_scroll(-random.randint(30, 120))
            _sleep(int(_ms(600, 2200)), int(_ms(800, 3000)))
            if random.random() < 0.25:
                self._drift()
            if random.random() < 0.20:
                self._hover_element(["p", "h2", "h3", "li", "span"])

    def _scroll_curious(self, budget_s: float = 12.0) -> None:
        """Fast scan then slows at something interesting."""
        deadline = time.monotonic() + budget_s
        # Fast scan first
        for _ in range(random.randint(3, 6)):
            if time.monotonic() >= deadline:
                break
            self._swipe_scroll(random.randint(300, 700))
            _sleep(60, 220)
        # "Found something" — long stop
        _sleep(2000, 6000)
        self._hover_element(["h1", "h2", "h3", "p", "button", "img"])
        self._drift()
        # Slow read from here
        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 0.5:
                break
            self._swipe_scroll(random.randint(60, 250))
            _sleep(700, 2500)

    def _scroll_methodical(self, budget_s: float = 12.0) -> None:
        """Chunk-by-chunk methodical reading."""
        deadline = time.monotonic() + budget_s
        vh = self._vh
        step = int(vh * random.uniform(0.5, 0.85))
        pos = 0
        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 1.5:
                break
            pos += step + random.randint(-50, 50)
            self._scroll_to(pos)
            _reading_pause()
            self._hover_element(["p", "li", "span"])
            self._drift()
            if random.random() < 0.25:
                self._swipe_scroll(-random.randint(40, 120))
                _sleep(600, 1800)

    def _scroll_back_forth(self, budget_s: float = 12.0) -> None:
        """Jumps between sections — comparing / re-reading."""
        deadline = time.monotonic() + budget_s
        total_h = self._page_height()
        n = random.randint(3, 6)
        anchors = sorted([random.randint(0, total_h) for _ in range(n)])
        for pos in anchors:
            if time.monotonic() >= deadline:
                break
            self._scroll_to(pos)
            _sleep(800, 3200)
            self._hover_element(["p", "h2", "button"])
            if random.random() < 0.35:
                self._drift()
        # Return up
        back = random.choice(anchors[:max(1, len(anchors) // 2)])
        self._scroll_to(back)
        _sleep(900, 2500)

    def _scroll_check_length(self, budget_s: float = 12.0) -> None:
        """Quickly goes to bottom to judge content length, then reads from 30%."""
        deadline = time.monotonic() + budget_s
        total_h = self._page_height()
        # Quick bottom check
        for _ in range(random.randint(3, 7)):
            if time.monotonic() >= deadline:
                return
            self._swipe_scroll(total_h // 5 + random.randint(-100, 100))
            _sleep(120, 380)
        _sleep(1200, 3000)
        self._drift()
        read_start = int(total_h * random.uniform(0.05, 0.30))
        self._scroll_to(read_start)
        _sleep(700, 1800)
        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 1.0:
                break
            self._swipe_scroll(random.randint(100, 350))
            _sleep(800, 2800)
            if random.random() < 0.25:
                self._hover_element(["p", "h3"])

    def _scroll_impatient(self, budget_s: float = 12.0) -> None:
        """Impatient user — fast scroll, quick stops."""
        deadline = time.monotonic() + budget_s
        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 0.3:
                break
            px = random.randint(250, 800)
            self._swipe_scroll(px)
            _sleep(200, 800)
            if random.random() < 0.1:
                self._swipe_scroll(-random.randint(50, 200))
                _sleep(200, 600)

    def _scroll_idle_burst(self, budget_s: float = 12.0) -> None:
        """Reads above fold, bursts down, then slows."""
        deadline = time.monotonic() + budget_s
        # Long initial read
        above_time = min(budget_s * 0.4, random.uniform(3.0, 9.0))
        self._hover_element(["h1", "h2", "p"])
        self._drift()
        time.sleep(above_time)
        # Burst
        n = random.randint(4, 9)
        for _ in range(n):
            if time.monotonic() >= deadline:
                return
            self._swipe_scroll(random.randint(200, 600))
            _sleep(50, 200)
        _sleep(1800, 5500)
        self._hover_element(["p", "h3"])
        # Slow read
        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 0.5:
                break
            self._swipe_scroll(random.randint(70, 250))
            _sleep(550, 2100)

    def _random_scroll(self, budget_s: float = 10.0) -> None:
        """Pick one of 7 scroll personalities at random."""
        strategies = [
            (self._scroll_natural,      0.28),
            (self._scroll_methodical,   0.18),
            (self._scroll_curious,      0.16),
            (self._scroll_back_forth,   0.12),
            (self._scroll_check_length, 0.10),
            (self._scroll_idle_burst,   0.09),
            (self._scroll_impatient,    0.07),
        ]
        fn = random.choices(
            [s[0] for s in strategies],
            weights=[s[1] for s in strategies],
            k=1
        )[0]
        fn(budget_s=budget_s)

    # ------------------------------------------------------------------
    # Dwell engine — fill time with humanized activity
    # ------------------------------------------------------------------

    def _humanized_dwell(self, duration_s: float, label: str = "dwell") -> None:
        """
        Fill `duration_s` seconds with realistic human behaviour.
        Used during progress bar waits and error popup retries.
        This is when all ad impressions are being counted.
        """
        log.info("[%s] 👁  %s: %.1fs of humanized ad dwell starting",
                 self._log.session_id[:8], label, duration_s)
        deadline = time.monotonic() + duration_s
        scroll_phase = True  # alternate between scroll and hover/drift

        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining < 0.3:
                break

            action = random.choices(
                ["drift", "hover", "scroll_small", "touch_tap", "idle", "read"],
                weights=[0.18, 0.22, 0.20, 0.10, 0.18, 0.12],
                k=1
            )[0]

            if action == "drift":
                self._drift()

            elif action == "hover":
                self._hover_element([
                    "p", "h2", "h3", "h1", "li", "span",
                    "button", "a", "img", "[class*='option']",
                    "[class*='btn']", "[class*='title']",
                ])
                _sleep(300, 1200)

            elif action == "scroll_small":
                # Small random scroll — looking at content
                direction = random.choice([1, 1, 1, -1])  # mostly down
                px = random.randint(40, 200)
                self._swipe_scroll(direction * px)
                _sleep(600, 2000)
                if random.random() < 0.3:
                    self._swipe_scroll(-direction * random.randint(20, 80))

            elif action == "touch_tap" and self._is_mobile:
                # Random safe content tap (not on ads)
                tx = random.randint(int(self._vw * 0.1), int(self._vw * 0.9))
                ty = random.randint(int(self._vh * 0.2), int(self._vh * 0.75))
                try:
                    self._page.touchscreen.tap(tx, ty)
                    self._cx, self._cy = tx, ty
                except Exception:
                    pass
                _sleep(300, 900)

            elif action == "idle":
                # Pure reading — no movement
                pause = min(remaining - 0.2, random.gauss(2.5, 1.2))
                time.sleep(max(0.2, pause))

            elif action == "read":
                # Read pause with subtle drift
                pause = min(remaining - 0.2, random.gauss(3.0, 1.5))
                time.sleep(max(0.2, pause))
                if random.random() < 0.5:
                    self._drift()

    # ------------------------------------------------------------------
    # Page-state detection helpers
    # ------------------------------------------------------------------

    def _wait_for_page_settle(self, timeout_s: float = 5.0) -> None:
        """Wait for dynamic content to settle."""
        try:
            self._page.wait_for_load_state("domcontentloaded", timeout=int(timeout_s * 1000))
        except Exception:
            pass
        _sleep(500, 1500)

    def _detect_page_type(self) -> str:
        """
        Classify current page state to drive the flow.
        Returns: 'landing' | 'progress' | 'error_popup' | 'adsterra' | 'unknown'
        """
        try:
            url = self._page.url or ""
            # Adsterra redirect destination
            if any(p in url for p in ADSTERRA_PATTERNS):
                return "adsterra"

            # Check page content indicators
            body = self._page.evaluate("document.body ? document.body.innerText : ''")
            if not isinstance(body, str):
                body = ""
            body_lower = body.lower()

            title = self._page.evaluate("document.title || ''") or ""
            title_lower = str(title).lower()

            # Progress bar / loading state
            if any(k in body_lower for k in ["processing", "please wait", "progress", "loading", "%" ]):
                return "progress"

            # Error / retry popup
            if any(k in body_lower for k in [
                "didn't share", "share to 10", "try again", "share failed",
                "not shared", "error", "retry", "10 people"
            ]):
                return "error_popup"

            # Landing page (likes/followers selector)
            if any(k in body_lower for k in [
                "likes", "followers", "booster", "free", "select",
                "choose", "get free", "fb", "facebook"
            ]):
                return "landing"

        except Exception:
            pass
        return "unknown"

    def _detect_progress_bar(self) -> Optional[float]:
        """
        Try to detect a progress bar element and read its current value.
        Returns completion % (0-100) or None if not found.
        """
        selectors = [
            "progress", "[role='progressbar']",
            "[class*='progress']", "[class*='Progress']",
            "[id*='progress']", "[id*='Progress']",
        ]
        for sel in selectors:
            try:
                el = self._page.locator(sel).first
                if el.is_visible(timeout=500):
                    val = self._page.evaluate(f"""
                        (() => {{
                            const el = document.querySelector('{sel}');
                            if (!el) return null;
                            if (el.value !== undefined) return parseFloat(el.value);
                            const max = parseFloat(el.getAttribute('max') || '100');
                            const cur = parseFloat(el.getAttribute('value') || el.getAttribute('aria-valuenow') || '0');
                            return (cur / max) * 100;
                        }})()
                    """)
                    if val is not None:
                        return float(val)
            except Exception:
                continue
        return None

    # ------------------------------------------------------------------
    # Phase 1: Landing page — read and select option
    # ------------------------------------------------------------------

    def _phase_landing(self) -> bool:
        """
        Phase 1: User lands, reads the page, picks a Likes/Followers option.
        Returns True if an option was successfully clicked.
        """
        log.info("[%s] 🏠 Phase 1: Landing page — reading & selecting option",
                 self._log.session_id[:8])
        self._refresh_viewport()

        # Initial page orientation — user just landed
        _sleep(1000, 3000)
        self._move_random()
        _glance()

        # Scroll to see the page content (3-8 seconds)
        self._random_scroll(budget_s=random.uniform(3.0, 8.0))
        _sleep(500, 1500)

        # Hover over option area (curiosity before clicking)
        self._hover_element([
            "[class*='option']", "[class*='select']", "[class*='btn']",
            "[class*='likes']", "[class*='follow']", "[class*='package']",
            "button", "a[class]", ".service", ".plan", ".choice",
        ])
        _sleep(800, 2500)

        # Pick and click an option (random — simulates real user choice)
        option_selectors = [
            # By class patterns typical on boost/like sites
            "[class*='option']:nth-child(1)", "[class*='option']:nth-child(2)",
            "[class*='option']:nth-child(3)", "[class*='option']:nth-child(4)",
            "[class*='plan']:nth-child(1)", "[class*='plan']:nth-child(2)",
            "[class*='package']:nth-child(1)", "[class*='package']:nth-child(2)",
            # Generic interactive elements
            "button[type='button']", "input[type='radio']",
            ".service-item", ".boost-option",
            # Text-based selectors
            "button:has-text('100')", "button:has-text('500')",
            "button:has-text('1000')", "button:has-text('Likes')",
            "button:has-text('Followers')", "a:has-text('Get Free')",
            "a:has-text('Start')", "a:has-text('Get')",
            # Last resort — anything clickable
            "button:first-of-type", "a.btn:first-of-type",
        ]
        # Shuffle options for randomness
        random.shuffle(option_selectors)
        clicked = self._click_element(option_selectors, timeout=2000)

        if not clicked:
            # Try clicking any visible button as fallback
            log.info("[%s] ℹ️  No option found — trying generic fallback click",
                     self._log.session_id[:8])
            try:
                buttons = self._page.query_selector_all("button, a[href], [onclick], [class*='btn']")
                visible = []
                for b in buttons[:20]:
                    try:
                        if b.is_visible():
                            visible.append(b)
                    except Exception:
                        pass
                if visible:
                    el = random.choice(visible[:5])
                    box = el.bounding_box(timeout=1000)
                    if box:
                        tx = int(box["x"] + box["width"] / 2)
                        ty = int(box["y"] + box["height"] / 2)
                        self._move_to(tx, ty)
                        _sleep(300, 800)
                        if self._is_mobile:
                            self._page.touchscreen.tap(tx, ty)
                        else:
                            el.click(no_wait_after=True, timeout=1500)
                        clicked = True
            except Exception:
                pass

        _sleep(800, 2000)
        return clicked

    # ------------------------------------------------------------------
    # Phase 2: Progress bar — 60-second dwell (IMPRESSIONS COUNTED HERE)
    # ------------------------------------------------------------------

    def _phase_progress_bar(self, expected_duration_s: float = 60.0) -> None:
        """
        Phase 2: Fake 60-second progress bar.
        This is the PRIMARY impression window — all CPM ads load here.
        User stays on page and looks engaged the entire time.
        """
        log.info("[%s] ⏳ Phase 2: Progress bar — %.0fs dwell (PRIMARY IMPRESSION WINDOW)",
                 self._log.session_id[:8], expected_duration_s)

        # Randomize actual wait (±20% variation = natural)
        actual_wait = expected_duration_s * random.uniform(0.85, 1.20)

        # Split into 4 sub-phases for variety
        phase_a = actual_wait * random.uniform(0.20, 0.30)  # initial scroll & read
        phase_b = actual_wait * random.uniform(0.30, 0.40)  # mid-bar engagement
        phase_c = actual_wait * random.uniform(0.10, 0.15)  # scroll back, anticipation
        phase_d = actual_wait - phase_a - phase_b - phase_c  # final wait

        # Sub-phase A: User starts reading content while waiting
        self._humanized_dwell(phase_a, "progress_bar_A")
        # Scroll down to see if there's more content (or check progress)
        self._random_scroll(budget_s=random.uniform(3.0, 7.0))

        # Sub-phase B: Main dwell — mouse active on page
        self._humanized_dwell(phase_b, "progress_bar_B")
        # Check progress bar periodically (human behavior)
        pct = self._detect_progress_bar()
        if pct is not None:
            log.info("[%s] 📊 Progress bar: %.0f%%", self._log.session_id[:8], pct)

        # Sub-phase C: User scrolls back up to see result
        self._scroll_to(0)
        self._humanized_dwell(phase_c, "progress_bar_C")

        # Sub-phase D: Anticipation — user waits for completion
        self._humanized_dwell(max(0.5, phase_d), "progress_bar_D")

        log.info("[%s] ✅ Phase 2 complete: %.1fs dwell on progress bar",
                 self._log.session_id[:8], actual_wait)

    # ------------------------------------------------------------------
    # Phase 3: Error popup — "You didn't share to 10 people!"
    # ------------------------------------------------------------------

    def _phase_error_popup(self) -> None:
        """
        Phase 3: Fake error popup appears. User reads it, closes it, and prepares
        to retry. Natural 5-15 second reaction time.
        """
        log.info("[%s] ❌ Phase 3: Error popup appeared — reacting naturally",
                 self._log.session_id[:8])

        # User is surprised — sudden mouse movement to center
        self._move_to(
            random.randint(int(self._vw * 0.3), int(self._vw * 0.7)),
            random.randint(int(self._vh * 0.3), int(self._vh * 0.6)),
        )
        _sleep(1000, 3000)  # reading the error message

        # Hover over close/retry area
        self._hover_element([
            "[class*='close']", "[class*='dismiss']", "[class*='ok']",
            "button:has-text('OK')", "button:has-text('Retry')",
            "button:has-text('Close')", "button:has-text('Try Again')",
            "[class*='error'] button", ".modal button", ".popup button",
            "button", "[role='dialog'] button",
        ])
        _sleep(500, 1500)

        # Try to dismiss the popup
        dismissed = self._click_element([
            "button:has-text('OK')", "button:has-text('Retry')",
            "button:has-text('Close')", "button:has-text('Try Again')",
            "[class*='close']", "[class*='dismiss']",
            ".modal .btn", ".popup .btn",
            "button[type='button']",
        ], timeout=2000)

        if not dismissed:
            # Tap outside the popup to close (common mobile pattern)
            try:
                self._page.keyboard.press("Escape")
                _sleep(300, 700)
            except Exception:
                pass
            # Click in the background
            try:
                self._page.mouse.click(
                    random.randint(5, 30),
                    random.randint(5, 30),
                )
            except Exception:
                pass

        _sleep(1000, 2500)
        log.info("[%s] ✅ Phase 3: Error popup handled", self._log.session_id[:8])

    # ------------------------------------------------------------------
    # Phase 4: Retry wait — 30-second SECOND impression window
    # ------------------------------------------------------------------

    def _phase_retry_wait(self, expected_duration_s: float = 30.0) -> None:
        """
        Phase 4: User retries, another progress bar / wait period.
        Second ad impression window — MUST count every session.
        """
        log.info("[%s] 🔄 Phase 4: Retry wait — %.0fs SECOND impression window",
                 self._log.session_id[:8], expected_duration_s)

        # Randomize actual wait
        actual_wait = expected_duration_s * random.uniform(0.80, 1.25)

        # Try clicking a "retry" or "share again" button
        self._click_element([
            "button:has-text('Try Again')", "button:has-text('Retry')",
            "button:has-text('Share Again')", "button:has-text('Continue')",
            "button:has-text('Next')", "a:has-text('Try Again')",
            "a:has-text('Retry')", "[class*='retry']", "[class*='share']",
        ], timeout=2000)

        _sleep(500, 1500)

        # Second impression window dwell
        self._humanized_dwell(actual_wait, "retry_wait")

        log.info("[%s] ✅ Phase 4 complete: %.1fs second impression window",
                 self._log.session_id[:8], actual_wait)

    # ------------------------------------------------------------------
    # Phase 5: Adsterra redirect — final CPM impression
    # ------------------------------------------------------------------

    def _phase_adsterra_dwell(self, dwell_s: float = 15.0) -> None:
        """
        Phase 5: Final Adsterra Direct Smartlink destination.
        User is redirected here — another CPM impression is counted.
        Dwell on the page so the impression registers as valid.
        """
        log.info("[%s] 💰 Phase 5: Adsterra destination — %.0fs final CPM dwell",
                 self._log.session_id[:8], dwell_s)
        self._refresh_viewport()

        actual_dwell = dwell_s * random.uniform(0.80, 1.30)

        # Above-fold: ads load during this time
        above_fold = min(actual_dwell * 0.40, random.uniform(4.0, 10.0))
        self._move_random()
        self._humanized_dwell(above_fold, "adsterra_above_fold")

        # Scroll to reveal mid-page ads
        self._swipe_scroll(random.randint(150, 400))
        _sleep(500, 1200)

        # Mid-page dwell
        mid_dwell = min(actual_dwell * 0.40, random.uniform(4.0, 10.0))
        self._humanized_dwell(mid_dwell, "adsterra_mid")

        # Scroll back
        self._scroll_to(0)
        remaining = max(1.0, actual_dwell - above_fold - mid_dwell)
        self._humanized_dwell(remaining, "adsterra_final")

        log.info("[%s] ✅ Phase 5 complete: Adsterra CPM registered",
                 self._log.session_id[:8])

    # ------------------------------------------------------------------
    # Main flow — orchestrate all phases
    # ------------------------------------------------------------------

    def run(self) -> dict:
        """
        Execute the complete aijaat.cc user flow.
        Returns a summary dict with phase completion status.
        """
        summary = {
            "site": "aijaat.cc",
            "phases_completed": [],
            "total_dwell_s": 0.0,
            "impressions_windows": 0,
            "success": False,
        }
        flow_start = time.monotonic()

        try:
            log.info("[%s] 🚀 Starting aijaat.cc flow engine",
                     self._log.session_id[:8])

            # ── Phase 1: Landing + Option Selection ──────────────────────────
            try:
                landed = self._phase_landing()
                summary["phases_completed"].append("landing")
                summary["option_selected"] = landed
                _sleep(500, 1500)
            except Exception as e:
                log.warning("[%s] Phase 1 error: %s", self._log.session_id[:8], e)

            # ── Phase 2: Progress Bar (60s impression window) ────────────────
            try:
                # Wait for progress bar / loading screen to appear
                self._wait_for_page_settle(3.0)
                # Detect how long the progress bar runs (varies by site config)
                pb_duration = random.uniform(55.0, 70.0)  # typically 60s
                self._phase_progress_bar(pb_duration)
                summary["phases_completed"].append("progress_bar_60s")
                summary["impressions_windows"] += 1
                _sleep(500, 1500)
            except Exception as e:
                log.warning("[%s] Phase 2 error: %s", self._log.session_id[:8], e)

            # ── Phase 3: Error Popup ─────────────────────────────────────────
            try:
                self._wait_for_page_settle(2.0)
                page_type = self._detect_page_type()
                if page_type in ("error_popup", "unknown", "landing"):
                    self._phase_error_popup()
                    summary["phases_completed"].append("error_popup")
            except Exception as e:
                log.warning("[%s] Phase 3 error: %s", self._log.session_id[:8], e)

            # ── Phase 4: Retry Wait (30s second impression window) ───────────
            try:
                retry_duration = random.uniform(25.0, 38.0)  # typically 30s
                self._phase_retry_wait(retry_duration)
                summary["phases_completed"].append("retry_30s")
                summary["impressions_windows"] += 1
                _sleep(500, 1500)
            except Exception as e:
                log.warning("[%s] Phase 4 error: %s", self._log.session_id[:8], e)

            # ── Phase 5: Adsterra Redirect Dwell ─────────────────────────────
            try:
                self._wait_for_page_settle(3.0)
                current_url = self._page.url or ""
                adsterra_dwell = random.uniform(12.0, 22.0)
                if any(p in current_url for p in ADSTERRA_PATTERNS):
                    self._phase_adsterra_dwell(adsterra_dwell)
                    summary["phases_completed"].append("adsterra_dwell")
                    summary["impressions_windows"] += 1
                else:
                    # Still dwell on the current page (may have soft-redirected)
                    self._humanized_dwell(adsterra_dwell, "final_dwell")
                    summary["phases_completed"].append("final_dwell")
                    summary["impressions_windows"] += 1
            except Exception as e:
                log.warning("[%s] Phase 5 error: %s", self._log.session_id[:8], e)

            summary["success"] = True

        except Exception as e:
            log.error("[%s] aijaat.cc flow critical error: %s",
                      self._log.session_id[:8], e)
            summary["error"] = str(e)

        finally:
            total_s = round(time.monotonic() - flow_start, 1)
            summary["total_dwell_s"] = total_s
            log.info(
                "[%s] 🏁 aijaat.cc flow complete | %.1fs | %d impression windows | phases: %s",
                self._log.session_id[:8],
                total_s,
                summary["impressions_windows"],
                " → ".join(summary["phases_completed"]),
            )

        return summary


# ---------------------------------------------------------------------------
# Smart routing rule: detect aijaat.cc in URL pool
# ---------------------------------------------------------------------------

def is_aijaat_url(url: str) -> bool:
    """Return True if this URL targets aijaat.cc."""
    return "aijaat.cc" in url.lower()


def get_aijaat_allowed_hosts(url: str) -> set:
    """Return the whitelist of hosts to allow for this URL."""
    return AIJAAT_ALLOWED_HOSTS
