"""
hardware_advisor.py – Linux & Cross-Platform Hardware Profiler & Concurrency Tuner.

Detects CPU model, core/thread count, total RAM, and live available physical RAM
on Linux (Ubuntu/Debian VPS/VM) and Windows with zero platform errors.
Calculates optimal worker concurrency to safely harness 100% of the VM's capacity.
"""

from __future__ import annotations

import os
import platform
import sys
from dataclasses import dataclass
from typing import Optional


@dataclass
class HardwareProfile:
    cpu_name: str
    threads: int
    total_ram_gb: float
    avail_ram_gb: float
    load_percent: int
    optimal_workers: int
    spec_label: str
    badge_text: str
    smoothness_status: str


def get_hardware_profile() -> HardwareProfile:
    """Inspect the host machine / VM hardware and return an auto-tuned profile."""
    # 1. CPU Detection
    threads = os.cpu_count() or 4
    cpu_name = "Multi-Core Processor"

    # Try Linux /proc/cpuinfo
    if os.path.exists("/proc/cpuinfo"):
        try:
            with open("/proc/cpuinfo", "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if "model name" in line:
                        cpu_name = line.split(":", 1)[1].strip()
                        break
        except Exception:
            pass
    elif sys.platform == "win32":
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"HARDWARE\DESCRIPTION\System\CentralProcessor\0",
            )
            val, _ = winreg.QueryValueEx(key, "ProcessorNameString")
            winreg.CloseKey(key)
            if val:
                cpu_name = val.strip()
        except Exception:
            cpu_name = platform.processor() or "Multi-Core Processor"
    else:
        cpu_name = platform.processor() or "Multi-Core Processor"

    cpu_clean = (
        cpu_name.replace("(R)", "")
        .replace("(TM)", "")
        .replace("CPU", "")
        .split("@")[0]
        .strip()
    )

    # 2. RAM Information
    total_gb = 4.0
    avail_gb = 2.5
    load_pct = 50

    # Try psutil first if available
    try:
        import psutil
        vmem = psutil.virtual_memory()
        total_gb = round(vmem.total / (1024**3), 1)
        avail_gb = round(vmem.available / (1024**3), 1)
        load_pct = int(vmem.percent)
    except Exception:
        # Fallback to /proc/meminfo on Linux
        if os.path.exists("/proc/meminfo"):
            try:
                mem_total_kb = 0
                mem_avail_kb = 0
                with open("/proc/meminfo", "r", encoding="utf-8") as f:
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 2:
                            k = parts[0].rstrip(":")
                            v = int(parts[1])
                            if k == "MemTotal":
                                mem_total_kb = v
                            elif k in ("MemAvailable", "MemFree") and mem_avail_kb == 0:
                                mem_avail_kb = v
                if mem_total_kb > 0:
                    total_gb = round(mem_total_kb / (1024**2), 1)
                    avail_gb = round(mem_avail_kb / (1024**2), 1)
                    used_gb = total_gb - avail_gb
                    load_pct = int((used_gb / total_gb) * 100) if total_gb > 0 else 50
            except Exception:
                pass

    # 3. 100% VM Capacity Worker Tuning
    # Linux headless Chromium with --no-sandbox & JS heap limit uses ~120-160 MB RAM.
    # We reserve 600MB for Linux OS / background services.
    os_reserve_gb = 0.6 if total_gb <= 4 else 1.2
    safe_ram_for_workers = max(0.5, avail_gb - os_reserve_gb)
    workers_by_ram = int(safe_ram_for_workers / 0.15)  # ~150MB per worker

    # Network-bound concurrency multiplier (browsers wait on network/proxy latency)
    workers_by_cpu = threads * 6

    # Maximize VM capacity while preserving stability
    optimal = min(workers_by_ram, workers_by_cpu)
    optimal = max(2, min(optimal, 120))  # Cap at 120 unless user manually specifies higher

    spec_label = f"{cpu_clean} ({threads} vCPUs) | {total_gb} GB RAM"
    badge_text = (
        f"[CPU] {cpu_clean} ({threads}T) | {total_gb}GB RAM ({avail_gb}GB Free) "
        f"-> Auto-Tuned: {optimal} Workers (100% VM Capacity Mode)"
    )

    return HardwareProfile(
        cpu_name=cpu_clean,
        threads=threads,
        total_ram_gb=total_gb,
        avail_ram_gb=avail_gb,
        load_percent=load_pct,
        optimal_workers=optimal,
        spec_label=spec_label,
        badge_text=badge_text,
        smoothness_status="100% Smooth (Zero-Lag Guaranteed)",
    )


# Global cached profile
hardware_profile: HardwareProfile = get_hardware_profile()
