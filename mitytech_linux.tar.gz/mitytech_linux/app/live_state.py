"""
live_state.py — Thread-safe per-session live status registry.

Sessions report their status here at key checkpoints.
GUI polls this every 500ms to update the live session grid.
No external dependencies. Zero leaks — sessions auto-expire after 30s.
"""
from __future__ import annotations
import threading
import time
from typing import Dict, Any, Optional

_lock    = threading.Lock()
_sessions: Dict[str, Dict[str, Any]] = {}   # sid -> state dict

# Country code → flag emoji (subset — adds visual context in grid)
_FLAGS: Dict[str, str] = {
    "us":"🇺🇸","gb":"🇬🇧","ca":"🇨🇦","au":"🇦🇺","de":"🇩🇪","fr":"🇫🇷",
    "nl":"🇳🇱","in":"🇮🇳","pk":"🇵🇰","bd":"🇧🇩","id":"🇮🇩","ph":"🇵🇭",
    "my":"🇲🇾","th":"🇹🇭","vn":"🇻🇳","br":"🇧🇷","mx":"🇲🇽","ar":"🇦🇷",
    "ae":"🇦🇪","sa":"🇸🇦","kw":"🇰🇼","qa":"🇶🇦","tr":"🇹🇷","ru":"🇷🇺",
    "sg":"🇸🇬","jp":"🇯🇵","kr":"🇰🇷","cn":"🇨🇳","za":"🇿🇦","eg":"🇪🇬",
    "ng":"🇳🇬","ke":"🇰🇪","gh":"🇬🇭","it":"🇮🇹","es":"🇪🇸","pl":"🇵🇱",
    "ua":"🇺🇦","ro":"🇷🇴","bg":"🇧🇬","gr":"🇬🇷","il":"🇮🇱","tw":"🇹🇼",
    "hk":"🇭🇰","cl":"🇨🇱","co":"🇨🇴","pe":"🇵🇪","se":"🇸🇪","no":"🇳🇴",
    "dk":"🇩🇰","fi":"🇫🇮","ch":"🇨🇭","be":"🇧🇪","at":"🇦🇹","pt":"🇵🇹",
}


def flag(country_code: str) -> str:
    return _FLAGS.get((country_code or "").lower(), "🌐")


def start(sid: str, target_url: str = "") -> None:
    """Called when a session begins."""
    with _lock:
        _sessions[sid] = {
            "status":     "STARTING",
            "country":    "",
            "ip":         "",
            "offer_url":  "",
            "kb":         0,
            "start_time": time.monotonic(),
            "done_time":  None,
            "target_url": target_url,
        }


def update(sid: str, **kwargs: Any) -> None:
    """Update one or more fields for a session."""
    with _lock:
        if sid in _sessions:
            _sessions[sid].update(kwargs)


def finish(sid: str, status: str = "DONE", kb: float = 0, offer_url: str = "") -> None:
    """Called when a session ends."""
    with _lock:
        if sid in _sessions:
            _sessions[sid].update({
                "status":    status.upper(),
                "kb":        kb,
                "offer_url": offer_url or _sessions[sid].get("offer_url", ""),
                "done_time": time.monotonic(),
            })


def get_snapshot() -> Dict[str, Dict[str, Any]]:
    """
    Return a snapshot for the GUI to render.
    Auto-removes sessions that finished more than 15s ago.
    """
    now = time.monotonic()
    with _lock:
        expired = [
            sid for sid, s in _sessions.items()
            if s.get("done_time") and (now - s["done_time"]) > 15
        ]
        for sid in expired:
            del _sessions[sid]
        return {sid: dict(s) for sid, s in _sessions.items()}


def clear() -> None:
    """Clear all sessions (called on run start)."""
    with _lock:
        _sessions.clear()
