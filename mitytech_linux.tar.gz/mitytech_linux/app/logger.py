"""
logger.py – Structured session events (RAM-only by default).
Set SAVE_ARTIFACTS=1 to additionally persist JSON/CSV logs + reports to disk.
"""

from __future__ import annotations

import csv
import json
import logging
import os
import sys
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.config import config

# Disk persistence is OPT-IN: default run leaves ZERO files on disk.
_PERSIST = os.getenv("SAVE_ARTIFACTS", "").strip().lower() in ("1", "true", "yes")

# ---------------------------------------------------------------------------
# Module-level stdlib logger (human-readable console output)
# ---------------------------------------------------------------------------
_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_root_logger = logging.getLogger()
_root_logger.setLevel(logging.INFO)

# Prevent duplicate handlers on re-import
_root_logger.handlers.clear()

# Console handler (stdout)
_console = logging.StreamHandler(sys.stdout)
_console.setFormatter(logging.Formatter(_FORMAT))
_root_logger.addHandler(_console)

# File handler for logs/app.log (only attached if stdout is not already redirected to app.log by daemon)
if not os.environ.get("MITYTECH_DAEMON"):
    try:
        config.logs_dir.mkdir(parents=True, exist_ok=True)
        _file_handler = logging.FileHandler(config.logs_dir / "app.log", mode="a", encoding="utf-8")
        _file_handler.setFormatter(logging.Formatter(_FORMAT))
        _root_logger.addHandler(_file_handler)
    except Exception:
        pass

log = logging.getLogger("qa_tester")


# ---------------------------------------------------------------------------
# Session event types
# ---------------------------------------------------------------------------
class EventType:
    SESSION_START = "session_start"
    SESSION_END = "session_end"
    PAGE_LOAD = "page_load"
    PAGE_METRICS = "page_metrics"
    SCROLL = "scroll"
    NAVIGATE = "navigate"
    POPUP_DETECTED = "popup_detected"
    POPUP_CLOSED = "popup_closed"
    NEW_TAB = "new_tab"
    NEW_TAB_CLOSED = "new_tab_closed"
    ERROR = "error"
    RETRY = "retry"
    HTTP_FAILURE = "http_failure"
    PROXY_CHANGE = "proxy_change"
    ADB_ACTION = "adb_action"


# ---------------------------------------------------------------------------
# Session logger – one per test session
# ---------------------------------------------------------------------------
class SessionLogger:
    """Records structured events for a single test session."""

    def __init__(self, session_id: str, run_label: str = "") -> None:
        self.session_id = session_id
        self.run_label = run_label
        self._events: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        self._json_path = config.logs_dir / f"session_{session_id}_{ts}.json"
        self._csv_path = config.logs_dir / f"session_{session_id}_{ts}.csv"
        self._csv_file = None
        self._csv_writer: Optional[csv.DictWriter] = None
        if _PERSIST:
            self._csv_file = open(self._csv_path, "w", newline="", encoding="utf-8")

    # ------------------------------------------------------------------
    def _write_csv_row(self, event: Dict[str, Any]) -> None:
        if self._csv_file is None:
            return
        flat = {
            "session_id": event.get("session_id"),
            "event_type": event.get("event_type"),
            "timestamp": event.get("timestamp"),
            "url": event.get("data", {}).get("url", ""),
            "detail": json.dumps(event.get("data", {}), ensure_ascii=False),
        }
        if self._csv_writer is None:
            self._csv_writer = csv.DictWriter(
                self._csv_file, fieldnames=list(flat.keys())
            )
            self._csv_writer.writeheader()
        self._csv_writer.writerow(flat)
        self._csv_file.flush()

    def record(self, event_type: str, data: Optional[Dict[str, Any]] = None) -> None:
        event: Dict[str, Any] = {
            "session_id": self.session_id,
            "run_label": self.run_label,
            "event_type": event_type,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": data or {},
        }
        with self._lock:
            self._events.append(event)
            self._write_csv_row(event)
        log.info("[%s] %s | %s", self.session_id[:8], event_type, json.dumps(data or {}))

    def flush_json(self) -> Path:
        """Persist events only when SAVE_ARTIFACTS=1; otherwise RAM-only."""
        if not _PERSIST:
            return self._json_path
        with self._lock:
            with open(self._json_path, "w", encoding="utf-8") as fh:
                json.dump(self._events, fh, indent=2, ensure_ascii=False)
        return self._json_path

    def close(self) -> None:
        if not _PERSIST:
            return
        self.flush_json()
        if self._csv_file is not None and not self._csv_file.closed:
            try:
                self._csv_file.close()
            except Exception:
                pass
        log.info("Session %s logs written → %s", self.session_id[:8], self._json_path)

    def __enter__(self) -> "SessionLogger":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            if self._csv_file is not None and not self._csv_file.closed:
                self._csv_file.close()
        except Exception:
            pass

    @property
    def events(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._events)


# ---------------------------------------------------------------------------
# Global report aggregator
# ---------------------------------------------------------------------------
class ReportAggregator:
    """Thread-safe store of all completed session summaries."""

    def __init__(self) -> None:
        self._summaries: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._load_existing()

    def _load_existing(self) -> None:
        if not _PERSIST:
            return
        try:
            if config.reports_dir.exists():
                all_files = sorted(config.reports_dir.glob("report_*.json"))
                # Only load the most recent report to keep RAM lean
                for p in all_files[-2:]:
                    try:
                        with open(p, "r", encoding="utf-8") as fh:
                            items = json.load(fh)
                            if isinstance(items, list):
                                self._summaries.extend(items[-50:])
                    except Exception:
                        pass
        except Exception as exc:
            log.warning("Could not load past reports: %s", exc)

    def add(self, summary: Dict[str, Any]) -> None:
        with self._lock:
            self._summaries.append(summary)
            # Bound in-memory summaries to latest 100 to prevent RAM leaks
            if len(self._summaries) > 100:
                self._summaries = self._summaries[-100:]

    def all(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._summaries)

    def save(self) -> Path:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        path = config.reports_dir / f"report_{ts}.json"
        if not _PERSIST:
            return path
        with self._lock:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(self._summaries, fh, indent=2, ensure_ascii=False)
        log.info("Aggregate report saved → %s", path)
        return path


# Module-level aggregator singleton
aggregator = ReportAggregator()
