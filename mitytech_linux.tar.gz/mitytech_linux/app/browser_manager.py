"""
browser_manager.py – Isolated Firefox/Playwright browser lifecycle management.

Each session gets its own temporary profile directory, which is wiped on close.
"""

from __future__ import annotations

import atexit
import json
import logging
import random
import shutil
import subprocess
import tempfile
import threading
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Generator, Optional

from playwright.sync_api import (
    Browser,
    BrowserContext,
    Page,
    Playwright,
    sync_playwright,
)
import httpx

from app.config import (
    BrowserConfig,
    config,
    COUNTRY_DEVICE_RULES,
    COUNTRY_GEO_MAP,
    DEFAULT_TARGET_COUNTRIES,
    CPM_COUNTRY_WEIGHTS,
)
from app.proxy_manager import Proxy, proxy_manager

log = logging.getLogger("qa_tester.browser")

# Auto-load proxies from proxy_list_file at startup
if config.proxy.proxy_list_file:
    _pf = Path(config.proxy.proxy_list_file)
    if _pf.exists():
        _ptext = _pf.read_text(encoding="utf-8")
        if "[" in _ptext and "]" in _ptext:
            from app.proxy_manager import multi_pool_manager
            _pcount = multi_pool_manager.load_from_sections(_ptext)
            log.info("Loaded %d proxy(s) across %d pool(s) from %s", _pcount, len(multi_pool_manager.pool_names), config.proxy.proxy_list_file)
        else:
            _pcount = proxy_manager.load_from_text(_ptext)
            log.info("Loaded %d proxy(s) from %s", _pcount, config.proxy.proxy_list_file)
    else:
        log.warning("Proxy list file not found: %s", config.proxy.proxy_list_file)


# ---------------------------------------------------------------------------
# Mobile Device Profile Generator — millions of unique devices
# ---------------------------------------------------------------------------
# Real Android device model codes — Samsung, Google, Xiaomi, OnePlus, Motorola,
# Oppo, Vivo, realme, Poco, Nokia. Every session picks one at random.
_ANDROID_MODELS = [
    # Samsung Galaxy S
    "SM-S918B", "SM-S911B", "SM-S908B", "SM-S901B", "SM-S906B",
    "SM-S926B", "SM-S921B", "SM-G998B", "SM-G996B", "SM-G991B",
    # Samsung Galaxy A
    "SM-A546B", "SM-A536B", "SM-A526B", "SM-A326B", "SM-A136B",
    "SM-A736B", "SM-A546E", "SM-A336B", "SM-A236B", "SM-A155F",
    # Google Pixel
    "Pixel 7", "Pixel 7 Pro", "Pixel 7a", "Pixel 8", "Pixel 8 Pro",
    "Pixel 6", "Pixel 6 Pro", "Pixel 6a", "Pixel 5", "Pixel 4a",
    # Xiaomi / Redmi
    "2201116SG", "22071212AG", "2201117TG", "22081212UG", "23049PCD8G",
    "Redmi Note 12", "Redmi Note 11", "Redmi 12", "Redmi 12C", "Redmi 10C",
    "2304FPN6DC", "23013RK75C", "22111317I", "21121119SG", "2107113SG",
    # OnePlus
    "CPH2423", "CPH2449", "CPH2469", "CPH2413", "CPH2399", "CPH2395",
    "PHB110", "PHB120", "LE2123", "LE2121", "LE2115", "LE2117",
    # Motorola
    "moto g(60)", "moto g82 5G", "moto g72", "moto g32", "moto g13",
    "XT2201-3", "XT2255-1", "XT2235-2", "XT2175-2", "XT2139-1",
    # Oppo
    "CPH2387", "CPH2333", "CPH2269", "CPH2219", "CPH2127", "CPH2477",
    # Vivo
    "V2254", "V2217", "V2183A", "V2130", "V2036", "V2309",
    # realme
    "RMX3430", "RMX3511", "RMX3085", "RMX2193", "RMX3301", "RMX3761",
    # Poco
    "POCO X5 Pro", "POCO X5", "POCO M5s", "POCO M4 Pro", "POCO F4",
    # Nokia
    "Nokia G21", "Nokia G11", "Nokia C31", "Nokia X30 5G", "Nokia C21 Plus",
]

_ANDROID_VERSIONS = ["11", "12", "13", "14"]
_ANDROID_WEIGHTS  = [5, 15, 40, 40]  # weighted toward modern versions

_CHROME_VERSIONS = [
    "122.0.6261.119", "123.0.6312.122", "124.0.6367.82",
    "125.0.6422.165", "126.0.6478.122", "127.0.6533.64",
    "128.0.6613.88",  "128.0.6613.127",
]

# iPhone models — (safari-name, viewport-width, viewport-height)
_IPHONE_MODELS = [
    ("iPhone 15 Pro Max", 430, 932), ("iPhone 15 Pro", 393, 852),
    ("iPhone 15 Plus",    430, 932), ("iPhone 15",     393, 852),
    ("iPhone 14 Pro Max", 430, 932), ("iPhone 14 Pro",  393, 852),
    ("iPhone 14 Plus",    428, 926), ("iPhone 14",      390, 844),
    ("iPhone 13 Pro Max", 428, 926), ("iPhone 13 Pro",  390, 844),
    ("iPhone 13 mini",    375, 812), ("iPhone 13",      390, 844),
    ("iPhone 12 Pro Max", 428, 926), ("iPhone 12 Pro",  390, 844),
    ("iPhone 12 mini",    375, 812), ("iPhone 12",      390, 844),
    ("iPhone SE (3rd)",   375, 667), ("iPhone 11 Pro Max", 414, 896),
    ("iPhone 11 Pro",     375, 812), ("iPhone 11",      414, 896),
    ("iPhone XS Max",     414, 896), ("iPhone XR",      414, 896),
]

_IOS_VERSIONS   = ["15_8", "16_6", "16_7", "17_0", "17_1", "17_2", "17_3", "17_4", "17_5", "17_6"]
_IOS_WEIGHTS    = [2, 4, 4, 8, 10, 12, 14, 15, 15, 16]
_SAFARI_VER_MAP = {
    "15_8": "15.6", "16_6": "16.6", "16_7": "16.6",
    "17_0": "17.0", "17_1": "17.1", "17_2": "17.2",
    "17_3": "17.3", "17_4": "17.4", "17_5": "17.5", "17_6": "17.6",
}

# Android screen widths actually used by real phones (pixels)
_ANDROID_WIDTHS = [360, 375, 384, 390, 393, 400, 411, 412, 414, 428, 430]

# Real Windows Desktop screen resolutions
_WINDOWS_RESOLUTIONS = [
    (1920, 1080),  # Full HD (most popular worldwide)
    (1536, 864),   # 1080p 125% scaled laptop
    (1366, 768),   # 14-inch laptop HD
    (1440, 900),   # 16:10 wide monitor
    (1600, 900),   # 1600x900 widescreen
    (2560, 1440),  # 2K QHD monitor
]

_WINDOWS_CHROME_VERSIONS = [
    "124.0.0.0", "125.0.0.0", "126.0.0.0", "127.0.0.0", "128.0.0.0", "129.0.0.0"
]


# Authentic Facebook Mobile App versions (FB_IAB / FBAN)
_FB_APP_VERSIONS = [
    "485.0.0.42.110", "484.0.0.39.110", "482.0.0.38.109",
    "480.0.0.45.109", "478.0.0.41.109", "475.0.0.46.108",
]


def _generate_android_profile() -> dict:
    """Generate authentic Android mobile device fingerprint."""
    model = random.choice(_ANDROID_MODELS)
    android_v = random.choices(_ANDROID_VERSIONS, weights=_ANDROID_WEIGHTS, k=1)[0]
    chrome_v = random.choice(_CHROME_VERSIONS)
    if config.traffic.is_facebook_mode():
        fb_v = random.choice(_FB_APP_VERSIONS)
        ua = (
            f"Mozilla/5.0 (Linux; Android {android_v}; {model} Build/UP1A.231005.007; wv) "
            f"AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 "
            f"Chrome/{chrome_v} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{fb_v};]"
        )
    else:
        ua = (
            f"Mozilla/5.0 (Linux; Android {android_v}; {model}) "
            f"AppleWebKit/537.36 (KHTML, like Gecko) "
            f"Chrome/{chrome_v} Mobile Safari/537.36"
        )
    width = random.choice(_ANDROID_WIDTHS)
    height = random.randint(760, 960)
    label = f"android-{model[:12].lower().replace(' ', '-')}"
    return {
        "width": width,
        "height": height,
        "label": label,
        "is_mobile": True,
        "has_touch": True,
        "user_agent": ua,
        "device_scale_factor": random.choice([2, 2, 3, 3]),
        "platform": "Linux armv8l",
        "device_os": "android",
    }


def _generate_ios_profile() -> dict:
    """Generate authentic iPhone iOS mobile device fingerprint."""
    name, width, height = random.choice(_IPHONE_MODELS)
    ios_v = random.choices(_IOS_VERSIONS, weights=_IOS_WEIGHTS, k=1)[0]
    safari_v = _SAFARI_VER_MAP.get(ios_v, "17.0")
    if config.traffic.is_facebook_mode():
        fb_v = random.choice(_FB_APP_VERSIONS)
        ios_v_dot = ios_v.replace("_", ".")
        ua = (
            f"Mozilla/5.0 (iPhone; CPU iPhone OS {ios_v} like Mac OS X) "
            f"AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 "
            f"[FBAN/FBIOS;FBDV/{name.replace(' ', '')};FBMD/iPhone;FBSN/iOS;FBSV/{ios_v_dot};FBSS/3;FBCR/;FBID/phone;FBLC/en_US;FBOP/5;FBRV/0;FBAV/{fb_v};]"
        )
    else:
        ua = (
            f"Mozilla/5.0 (iPhone; CPU iPhone OS {ios_v} like Mac OS X) "
            f"AppleWebKit/605.1.15 (KHTML, like Gecko) "
            f"Version/{safari_v} Mobile/15E148 Safari/604.1"
        )
    label = f"iphone-{name.lower().replace(' ', '-').replace('(', '').replace(')', '')}"
    return {
        "width": width,
        "height": height,
        "label": label,
        "is_mobile": True,
        "has_touch": True,
        "user_agent": ua,
        "device_scale_factor": 3,
        "platform": "iPhone",
        "device_os": "ios",
    }


def _generate_windows_profile() -> dict:
    """Generate authentic Windows 10/11 desktop PC fingerprint."""
    width, height = random.choice(_WINDOWS_RESOLUTIONS)
    cv = random.choice(_WINDOWS_CHROME_VERSIONS)
    browser_flavor = random.choices(["chrome", "edge"], weights=[80, 20], k=1)[0]
    if browser_flavor == "chrome":
        ua = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Safari/537.36"
    else:
        ua = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Safari/537.36 Edg/{cv}"

    label = f"windows-{browser_flavor}-{width}x{height}"
    return {
        "width": width,
        "height": height,
        "label": label,
        "is_mobile": False,
        "has_touch": False,
        "user_agent": ua,
        "device_scale_factor": 1,
        "platform": "Win32",
        "device_os": "windows",
    }


def generate_device_profile(country: Optional[str] = None, target_device: Optional[str] = None) -> tuple[dict, str, str]:
    """
    Generate device profile matching the exact country-to-device rules.
    Returns (profile_dict, country_code, device_os).
    """
    target_c = (country or "us").lower()
    allowed = COUNTRY_DEVICE_RULES.get(target_c, ["android", "windows"])

    if config.traffic.is_facebook_mode() or config.traffic.is_ouo_io_mode():
        # Social shortlinks & FB: 100% mobile (Android / iOS) matching real user traffic
        chosen_os = target_device if target_device in ("android", "ios") else random.choices(["android", "ios"], weights=[75, 25], k=1)[0]
    elif target_device and target_device in allowed:
        chosen_os = target_device
    else:
        chosen_os = random.choice(allowed)

    if chosen_os == "ios":
        prof = _generate_ios_profile()
    elif chosen_os == "windows":
        prof = _generate_windows_profile()
    else:
        prof = _generate_android_profile()

    return prof, target_c, chosen_os


def _generate_mobile_profile() -> dict:
    """Legacy helper for random profile."""
    prof, _, _ = generate_device_profile(country="us")
    return prof



# ---------------------------------------------------------------------------
# Traffic Wave Simulator — Zero Fixed Pattern Anti-Detection
# ---------------------------------------------------------------------------
# The fundamental truth about bot detection:
#   ANY fixed distribution (CPM-weighted, organic-weighted, round-robin)
#   is a learnable pattern. Adsterra's ML trains on publisher traffic
#   and builds a statistical fingerprint of what's "normal" for each account.
#   A fixed distribution = consistent fingerprint = detectable.
#
# The UNBREAKABLE approach: NO fixed distribution at all.
#
# Real human organic traffic has ONE true property:
#   Users come in WAVES — someone shares a link in a WhatsApp group,
#   5-10 people from the same country click it over 2-3 minutes, then silence,
#   then someone else shares it somewhere else, new burst from new country.
#
# Traffic Wave Simulator:
#   1. Pick a random country from the pool (no weights, pure random)
#   2. Serve 1–7 sessions from that country (the "wave")
#   3. Switch to a DIFFERENT random country for the next wave
#   4. Wave sizes are Poisson-distributed (λ=3) → looks like viral sharing
#   5. No two consecutive waves use the same country
#   6. The OVERALL distribution across 1000 sessions is unpredictable —
#      it depends entirely on which countries are in the user's pool
#      and the random Poisson draws, which no external system can predict.
#
# Result: No ML model can fingerprint the distribution because it's
# different every run, every hour, every account. Undetectable by design.

_country_lock = threading.Lock()
_wave_country: str = ""        # current wave's country
_wave_remaining: int = 0       # sessions left in current wave


def get_next_target_country(pool: list[str]) -> str:
    """
    Traffic Wave Simulator — the only truly undetectable country selector.

    Returns the next country for a session based on wave-burst logic:
    - Within a wave: same country (simulates group of users from same place)
    - Between waves: completely random new country from pool
    - Wave size: Poisson(λ=3), range 1–8 (random, not fixed)

    This produces traffic that statistically looks like genuine viral link-sharing.
    No fixed distribution. No learnable pattern. Every 1000-session batch looks
    statistically different from the last.
    """
    global _wave_country, _wave_remaining

    if not pool:
        return "us"

    with _country_lock:
        anti_detect = getattr(config.proxy, "anti_detect_mode", True)

        if not anti_detect:
            # Legacy fallback: simple round-robin for debugging only
            if not hasattr(get_next_target_country, "_rr_idx"):
                get_next_target_country._rr_idx = 0
            idx = get_next_target_country._rr_idx % len(pool)
            get_next_target_country._rr_idx += 1
            return pool[idx]

        # ── Wave logic ────────────────────────────────────────────────────
        if _wave_remaining <= 0 or _wave_country not in pool:
            # Start a new wave: pick a different country from pool
            candidates = [c for c in pool if c != _wave_country]
            if not candidates:
                candidates = pool  # only 1 country in pool

            # Pure random — no weights, no bias
            # This is the key: unpredictable selection means no learnable pattern
            _wave_country = random.choice(candidates)

            # Wave size: Poisson distribution λ=3 (most waves are 2-4 sessions,
            # occasionally 1 or 7, rarely 8+ — just like real sharing bursts)
            # Clipped to 1-8 to prevent any single country dominating
            import math as _math
            _wave_remaining = min(8, max(1, int(random.expovariate(1/3.0)) + 1))

        _wave_remaining -= 1
        return _wave_country


# ---------------------------------------------------------------------------
# Isolated Browser Context
# ---------------------------------------------------------------------------
class IsolatedContext:
    """
    A single isolated browser context with its own temporary profile.
    Cleans up completely when used as a context manager.
    """

    def __init__(
        self,
        playwright: Playwright,
        session_id: str,
        browser_cfg: BrowserConfig,
        proxy: Optional[Proxy] = None,
    ) -> None:
        self.session_id = session_id
        self._cfg = browser_cfg
        self._proxy = proxy
        self._tmp_dir = Path(tempfile.mkdtemp(prefix=f"qa_{session_id[:8]}_", dir=config.profiles_dir))
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._pw = playwright

        # ── 1. Determine Target Country & Device Rules ───────────────────
        device_mode = getattr(config.proxy, "device_mode", "all").lower()
        active_pool = [c.lower() for c in (config.proxy.active_countries or DEFAULT_TARGET_COUNTRIES)]

        if device_mode == "mobile":
            filtered_pool = [c for c in active_pool if any(d in ["android", "ios"] for d in COUNTRY_DEVICE_RULES.get(c, []))]
            if filtered_pool:
                active_pool = filtered_pool
        elif device_mode == "windows":
            filtered_pool = [c for c in active_pool if "windows" in COUNTRY_DEVICE_RULES.get(c, [])]
            if filtered_pool:
                active_pool = filtered_pool

        if not active_pool:
            active_pool = ["us"]

        # Helper to normalize 2-letter country code or common country name
        def _norm_cc(val: Optional[str]) -> Optional[str]:
            if not val:
                return None
            v = str(val).strip().lower()
            if v in COUNTRY_DEVICE_RULES:
                return v
            _name_map = {
                "united states": "us", "usa": "us", "australia": "au",
                "great britain": "gb", "united kingdom": "gb", "uk": "gb",
                "canada": "ca", "switzerland": "ch", "germany": "de",
                "netherlands": "nl", "singapore": "sg", "china": "cn",
            }
            return _name_map.get(v)

        # Pick target country strictly honoring the user's selected active country pool
        chosen_country = None
        if self._proxy and self._proxy.is_residential_dynamic:
            # Dynamic residential proxies rotate to ANY target country on demand:
            # Strictly rotate through user's active countries
            chosen_country = get_next_target_country(active_pool)
        elif self._proxy:
            proxy_cc = (
                _norm_cc(getattr(self._proxy, "country_code", None))
                or _norm_cc(getattr(self._proxy, "target_country", None))
                or _norm_cc(getattr(self._proxy, "country", None))
            )
            if proxy_cc and proxy_cc in active_pool:
                chosen_country = proxy_cc
            else:
                chosen_country = get_next_target_country(active_pool)
        else:
            chosen_country = get_next_target_country(active_pool)

        if not chosen_country or chosen_country not in COUNTRY_DEVICE_RULES:
            chosen_country = get_next_target_country(active_pool) if active_pool else "us"

        # Determine allowed device platform for this country
        allowed_devices = list(COUNTRY_DEVICE_RULES.get(chosen_country, ["android", "windows"]))
        if config.traffic.is_facebook_mode():
            # In Facebook App mode, 100% of sessions must be authentic mobile in-app browser (FB_IAB / FBAN)
            mob_allowed = [d for d in allowed_devices if d in ["android", "ios"]]
            allowed_devices = mob_allowed if mob_allowed else ["android"]
        elif device_mode == "mobile":
            mob_allowed = [d for d in allowed_devices if d in ["android", "ios"]]
            allowed_devices = mob_allowed if mob_allowed else ["android"]
        elif device_mode == "windows":
            win_allowed = [d for d in allowed_devices if d == "windows"]
            if win_allowed:
                allowed_devices = win_allowed

        chosen_device = random.choice(allowed_devices)

        # Rotate residential proxy targeting this specific country & device
        if self._proxy:
            self._proxy = self._proxy.rotate_session(target_country=chosen_country, target_device=chosen_device)

        # Generate the authentic fingerprint profile for this country & device
        self.target_country = chosen_country
        self.target_device = chosen_device
        self.viewport, _, _ = generate_device_profile(country=chosen_country, target_device=chosen_device)

        # Synchronize default locale and timezone for the selected country
        geo_defaults = COUNTRY_GEO_MAP.get(chosen_country, {})
        self.locale = geo_defaults.get("locale", random.choice(browser_cfg.locale_profiles))
        self.timezone = geo_defaults.get("tz", random.choice(browser_cfg.timezone_profiles))

        # ------------------------------------------------------------------
        # Dynamic Timezone & Locale Synchronization + Full Geo Capture
        # ------------------------------------------------------------------
        self.geo_info: dict = {
            "target_country": chosen_country,
            "target_device": chosen_device,
            "device_label": self.viewport.get("label"),
            "os": self.viewport.get("device_os"),
        }
        try:
            proxy_arg = self._proxy.url if self._proxy else None
            geo_data = {}
            with httpx.Client(proxy=proxy_arg, timeout=6.0) as client:
                try:
                    r = client.get("http://ip-api.com/json?fields=status,countryCode,regionName,city,timezone,isp,query")
                    if r.status_code == 200:
                        geo_data = r.json()
                except Exception:
                    pass

                # High-speed fallback if ip-api.com timed out or rate-limited
                if not geo_data.get("query"):
                    try:
                        r_fb = client.get("https://api.ipify.org?format=json")
                        if r_fb.status_code == 200:
                            fb_ip = r_fb.json().get("ip")
                            if fb_ip:
                                geo_data = {
                                    "status": "success",
                                    "query": fb_ip,
                                    "countryCode": chosen_country.upper(),
                                    "timezone": self.timezone,
                                    "city": "?",
                                    "regionName": "?",
                                    "isp": "Residential Gateway",
                                }
                    except Exception:
                        pass

                if not geo_data.get("query"):
                    try:
                        r_fb2 = client.get("https://ifconfig.me/ip")
                        if r_fb2.status_code == 200 and r_fb2.text.strip():
                            geo_data = {
                                "status": "success",
                                "query": r_fb2.text.strip(),
                                "countryCode": chosen_country.upper(),
                                "timezone": self.timezone,
                                "city": "?",
                                "regionName": "?",
                                "isp": "Residential Gateway",
                            }
                    except Exception:
                        pass

                curr_ip = geo_data.get("query")

                # ── Anti-Repeat IP Guard: Guarantee 100% Unique IP Per Session ──
                if self._proxy and self._proxy.is_residential_dynamic and curr_ip:
                    from app.proxy_manager import is_ip_already_used, record_used_ip
                    _dedup_attempts = 0
                    while is_ip_already_used(curr_ip) and _dedup_attempts < 7:
                        _dedup_attempts += 1
                        log.info("[%s] 🔄 IP %s already used in this run — rotating for fresh unique IP (attempt %d/7)...",
                                 session_id[:8], curr_ip, _dedup_attempts)
                        self._proxy = self._proxy.rotate_session(target_country=chosen_country, target_device=chosen_device)
                        try:
                            with httpx.Client(proxy=self._proxy.url, timeout=3.0) as dedup_client:
                                r_dedup = dedup_client.get("http://ip-api.com/json?fields=status,countryCode,regionName,city,timezone,isp,query")
                                if r_dedup.status_code == 200:
                                    geo_data = r_dedup.json()
                                    curr_ip = geo_data.get("query")
                        except Exception:
                            break
                    if is_ip_already_used(curr_ip):
                        raise Exception(f"Duplicate IP {curr_ip} detected — aborting to protect view counting")
                    if curr_ip:
                        record_used_ip(curr_ip)
                elif curr_ip:
                    from app.proxy_manager import record_used_ip
                    record_used_ip(curr_ip)

                if geo_data:
                    self.geo_info.update(geo_data)
                    ip_tz = geo_data.get("timezone")
                    ip_country = (geo_data.get("countryCode") or "").upper()
                    if ip_tz:
                        self.timezone = ip_tz

                    # Match primary locale to country
                    locale_map = {
                        "SA": "ar-SA", "CH": "de-CH", "US": "en-US", "AU": "en-AU",
                        "GB": "en-GB", "CA": "en-CA", "MM": "my-MM", "BG": "bg-BG",
                        "KR": "ko-KR", "KW": "ar-KW", "AE": "ar-AE", "SG": "en-SG",
                        "DE": "de-DE", "NL": "nl-NL", "TW": "zh-TW", "CN": "zh-CN",
                        "CM": "fr-CM", "IN": "en-IN", "FR": "fr-FR", "JP": "ja-JP",
                    }
                    if ip_country in locale_map:
                        self.locale = locale_map[ip_country]

                    log.info(
                        "[%s] 🌐 IP: %-15s  📍 %s, %s  🏢 %s  🕐 %s  📱 %s [%s]",
                        session_id[:8],
                        geo_data.get("query", "?"),
                        geo_data.get("city", "?"),
                        geo_data.get("regionName", "?"),
                        geo_data.get("isp", "?"),
                        self.timezone,
                        self.target_device.upper(),
                        self.viewport.get("label"),
                    )
        except Exception as e:
            log.debug("[%s] Timezone auto-sync fallback: %s", session_id[:8], e)

        log.info(
            "[%s] Profile: %s | country: %s (%s) | viewport: %s | locale: %s | tz: %s | proxy: %s",
            session_id[:8],
            self._tmp_dir.name,
            self.target_country.upper(),
            self.target_device.upper(),
            self.viewport["label"],
            self.locale,
            self.timezone,
            proxy.server if proxy else "none",
        )


    # ------------------------------------------------------------------
    def _launch_browser(self) -> Browser:
        launch_opts: dict = {
            "headless": self._cfg.headless,
            "slow_mo": self._cfg.slow_mo_ms,
            "firefox_user_prefs": {
                # Disable telemetry / crash reporting
                "toolkit.telemetry.enabled": False,
                "datareporting.healthreport.uploadEnabled": False,
                # Private browsing: no persistent disk state
                "browser.privatebrowsing.autostart": True,
                # Prevent WebRTC IP leaks
                "media.peerconnection.enabled": False,
                # Prevent DNS leaks: resolve domain names remotely over the proxy
                "network.proxy.socks_remote_dns": True,
                # Disable HTML5 geolocation hardware sensor access
                "geo.enabled": False,
            },
        }
        if self._proxy:
            # Re-use the exact rotated proxy from context initialization
            from urllib.parse import urlparse
            p = urlparse(self._proxy.url)
            scheme = p.scheme or "http"
            port = p.port
            # Playwright / Chromium does not support SOCKS5 proxy authentication natively.
            # geo.g-w.info provides dual HTTP endpoint on port 10080 for SOCKS5 port 10800.
            if scheme.startswith("socks") and "g-w.info" in (p.hostname or "") and port == 10800:
                scheme = "http"
                port = 10080

            launch_opts["proxy"] = {
                "server": f"{scheme}://{p.hostname}:{port}",
                "username": p.username,
                "password": p.password,
            }

        browser_type = self._cfg.browser.lower()

        # High-Performance Hardware Acceleration & Resource Offload Flags
        # Offloads DOM rendering, canvas, and video decoding directly to GPU (Direct3D 11 / ANGLE)
        # Prevents CPU bottlenecking and caps RAM consumption to enable silky-smooth 32+ worker concurrency.
        if sys.platform == "win32":
            gpu_args = [
                "--enable-gpu-rasterization",
                "--enable-zero-copy",
                "--ignore-gpu-blocklist",
                "--disable-dev-shm-usage",
                "--disable-background-networking",
                "--renderer-process-limit=64",
                "--js-flags=--max-old-space-size=192",
                "--no-default-browser-check",
                "--no-first-run",
                "--mute-audio",
            ]
        else:
            # Linux Terminal / VPS Server Optimized Flags
            gpu_args = [
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu",
                "--disable-software-rasterizer",
                "--disable-accelerated-2d-canvas",
                "--no-first-run",
                "--no-zygote",
                "--mute-audio",
                "--disable-background-networking",
                "--disable-background-timer-throttling",
                "--disable-backgrounding-occluded-windows",
                "--disable-breakpad",
                "--disable-component-update",
                "--disable-domain-reliability",
                "--disable-renderer-backgrounding",
                "--renderer-process-limit=64",
                "--js-flags=--max-old-space-size=192",
            ]
        if browser_type in ("chromium", "chrome", "msedge"):
            launch_opts["args"] = gpu_args

        browser_type = self._cfg.browser.lower()
        if (config.traffic.is_facebook_mode() or config.traffic.is_ouo_io_mode()) and browser_type == "firefox":
            # OUO.io Cloudflare Turnstile and Facebook IAB require Chromium (stealth.js fidelity)
            browser_type = "chromium"

        launcher = {
            "firefox": self._pw.firefox,
            "chromium": self._pw.chromium,
            "webkit": self._pw.webkit,
        }.get(browser_type, self._pw.chromium)

        try:
            b = launcher.launch(**launch_opts)
            _track_browser(b)
            return b
        except Exception as exc:
            err_msg = str(exc)
            if "Executable doesn't exist" in err_msg or "Please run the following command" in err_msg or "executablePath" in err_msg:
                log.warning("Browser binary missing for %s. Checking system browsers and auto-provisioning...", browser_type)
                
                # 1. Seamlessly attempt pre-installed Windows system browsers (Edge / Chrome)
                sys_channels = ["msedge", "chrome"] if sys.platform == "win32" else ["chromium", "chrome"]
                for sys_ch in sys_channels:
                    try:
                        fallback_opts = dict(launch_opts)
                        fallback_opts.pop("firefox_user_prefs", None)
                        fallback_opts["args"] = gpu_args
                        fallback_opts["channel"] = sys_ch
                        b = self._pw.chromium.launch(**fallback_opts)
                        log.info("Successfully launched session using pre-installed Windows %s!", sys_ch.upper())
                        _track_browser(b)
                        return b
                    except Exception:
                        pass

                # 2. If no system browser exists, auto-download browser via internal driver
                try:
                    from playwright._impl._driver import compute_driver_executable
                    import subprocess
                    node_exe, cli_js = compute_driver_executable()
                    target_b = "firefox" if browser_type == "firefox" else "chromium"
                    log.info("Downloading and preparing %s browser engine (first-time setup)...", target_b)
                    subprocess.run([node_exe, cli_js, "install", target_b], timeout=180, check=True)
                    b = launcher.launch(**launch_opts)
                    _track_browser(b)
                    return b
                except Exception as dl_err:
                    log.error("Automatic browser provisioning failed: %s", dl_err)
                    raise exc
            raise

    def _create_context(self) -> BrowserContext:
        context_opts: dict = {
            "viewport": {
                "width": self.viewport["width"],
                "height": self.viewport["height"],
            },
            "locale": self.locale,
            "timezone_id": self.timezone,
            "accept_downloads": False,
            "java_script_enabled": True,
            "bypass_csp": False,          # Do NOT bypass CSP – legitimate testing
            "ignore_https_errors": True,   # rotating residential proxies cause cert errors on redirect chains
            "storage_state": {},          # Fresh storage every session (no cookie/history leak)
        }

        # Per-context proxy isolation: guarantees each session uses its own freshly rotated residential IP
        if self._proxy:
            from urllib.parse import urlparse
            p = urlparse(self._proxy.url)
            scheme = p.scheme or "http"
            port = p.port or (10080 if "g-w.info" in (p.hostname or "") else 80)
            if scheme.startswith("socks") and "g-w.info" in (p.hostname or "") and port == 10800:
                scheme = "http"
                port = 10080

            context_opts["proxy"] = {
                "server": f"{scheme}://{p.hostname}:{port}",
                "username": p.username,
                "password": p.password,
            }

        # Enable full mobile emulation when the chosen viewport is a mobile profile.
        # is_mobile + has_touch tells the page this is a real touch phone.
        # device_scale_factor from the generated profile (2x Android or 3x iPhone/flagship).
        if self.viewport.get("is_mobile", False):
            context_opts["is_mobile"] = True
            context_opts["has_touch"] = True
            context_opts["device_scale_factor"] = self.viewport.get("device_scale_factor", 3)
        else:
            context_opts["is_mobile"] = False
            context_opts["has_touch"] = False
            context_opts["device_scale_factor"] = 1


        # UA priority: explicit override → generated profile UA → static list / file
        if self._cfg.user_agent_override:
            context_opts["user_agent"] = self._cfg.user_agent_override
        elif self.viewport.get("user_agent"):
            # Generated profile already has a perfectly matched UA for this device
            context_opts["user_agent"] = self.viewport["user_agent"]
        elif self._cfg.stealth_enabled:
            # Load UA list from optional file or use built‑in fallback
            def _load_ua_list() -> list:
                if self._cfg.user_agent_list_file:
                    try:
                        p = Path(self._cfg.user_agent_list_file).expanduser()
                        return [l.strip() for l in p.read_text().splitlines() if l.strip()]
                    except Exception:
                        pass
                return [
                    # ── Android Chrome (most common mobile browser globally) ────
                    "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.127 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.127 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 13; Redmi Note 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.82 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.64 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 13; CPH2423) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.82 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 12; moto g(60)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.119 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.127 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 13; 2201116SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.82 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.82 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.127 Mobile Safari/537.36",
                    # ── Samsung Internet ────────────────────────────────────────
                    "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/121.0.0.0 Mobile Safari/537.36",
                    "Mozilla/5.0 (Linux; Android 13; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/24.0 Chrome/117.0.0.0 Mobile Safari/537.36",
                    # ── iPhone Safari ───────────────────────────────────────────
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1",
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/128.0.6613.92 Mobile/15E148 Safari/604.1",
                    # ── Chrome on iPad (counts as mobile traffic on most ad networks) ─
                    "Mozilla/5.0 (iPad; CPU OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1",
                    "Mozilla/5.0 (Linux; Android 13; Pixel Tablet) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.82 Mobile Safari/537.36",
                ]
            ua_list = _load_ua_list()
            if ua_list:
                context_opts["user_agent"] = random.choice(ua_list)

        # Extra HTTP Headers for Facebook App mode (com.facebook.katana)
        if config.traffic.is_facebook_mode():
            fb_ref = config.traffic.get_referrer() or "https://l.facebook.com/"
            # NOTE: do NOT set Sec-Fetch-Site / Sec-Fetch-Mode here — Chromium rejects
            # subresource requests that carry a forced Sec-Fetch-Mode: navigate header
            # with net::ERR_INVALID_ARGUMENT, which killed EVERY stylesheet/script/image
            # request (incl. the Cloudflare Turnstile api.js → ouo never got a verified
            # turnstile token → 0 views credited). Referer + X-Requested-With are safe.
            fb_headers = {
                "Referer": fb_ref,
            }
            if self.viewport.get("device_os") == "android":
                fb_headers["X-Requested-With"] = "com.facebook.katana"
            elif self.viewport.get("device_os") == "ios":
                fb_headers["X-Requested-With"] = "com.facebook.Facebook"
            context_opts["extra_http_headers"] = fb_headers

        ctx = self._browser.new_context(**context_opts)  # type: ignore[union-attr]

        # Inject stealth script when enabled – runs before any site script.
        if self._cfg.stealth_enabled:
            try:
                ctx.add_init_script(path=Path(__file__).with_name("stealth.js"))
            except Exception as e:
                log.warning("[%s] Failed to inject stealth script: %s", self.session_id[:8], e)

            # ── Dynamic navigator.languages spoofing (country-matched) ───────────
            # Adsterra checks: does navigator.language match the IP country?
            # A Saudi Arabia IP with en-US language = suspicious mismatch.
            # We inject the correct language list AFTER Playwright sets locale.
            _COUNTRY_LANGUAGES: dict = {
                "us": ["en-US", "en"],
                "gb": ["en-GB", "en"],
                "ca": ["en-CA", "en", "fr-CA"],
                "au": ["en-AU", "en"],
                "nz": ["en-NZ", "en"],
                "ie": ["en-IE", "en"],
                "de": ["de-DE", "de", "en"],
                "at": ["de-AT", "de", "en"],
                "ch": ["de-CH", "de", "fr", "it"],
                "fr": ["fr-FR", "fr", "en"],
                "be": ["fr-BE", "fr", "nl", "de"],
                "nl": ["nl-NL", "nl", "en"],
                "se": ["sv-SE", "sv", "en"],
                "no": ["nb-NO", "no", "en"],
                "dk": ["da-DK", "da", "en"],
                "fi": ["fi-FI", "fi", "sv", "en"],
                "sg": ["en-SG", "zh-SG", "ms"],
                "jp": ["ja-JP", "ja"],
                "kr": ["ko-KR", "ko"],
                "ae": ["ar-AE", "ar", "en"],
                "sa": ["ar-SA", "ar"],
                "kw": ["ar-KW", "ar", "en"],
                "qa": ["ar-QA", "ar", "en"],
                "bh": ["ar-BH", "ar", "en"],
                "om": ["ar-OM", "ar", "en"],
                "eg": ["ar-EG", "ar"],
                "ma": ["ar-MA", "fr"],
                "iq": ["ar-IQ", "ar"],
                "jo": ["ar-JO", "ar", "en"],
                "lb": ["ar-LB", "ar", "fr", "en"],
                "es": ["es-ES", "es", "ca", "en"],
                "mx": ["es-MX", "es", "en"],
                "ar": ["es-AR", "es"],
                "cl": ["es-CL", "es"],
                "co": ["es-CO", "es"],
                "pe": ["es-PE", "es"],
                "it": ["it-IT", "it", "en"],
                "pt": ["pt-PT", "pt", "en"],
                "br": ["pt-BR", "pt"],
                "pl": ["pl-PL", "pl", "en"],
                "ru": ["ru-RU", "ru"],
                "ua": ["uk-UA", "uk", "ru"],
                "tr": ["tr-TR", "tr"],
                "in": ["en-IN", "hi", "en"],
                "pk": ["ur-PK", "ur", "en"],
                "bd": ["bn-BD", "bn", "en"],
                "lk": ["en-LK", "si", "ta"],
                "id": ["id-ID", "id"],
                "ph": ["en-PH", "fil"],
                "my": ["ms-MY", "ms", "en", "zh"],
                "th": ["th-TH", "th"],
                "vn": ["vi-VN", "vi"],
                "tw": ["zh-TW", "zh"],
                "hk": ["zh-HK", "zh", "en"],
                "cn": ["zh-CN", "zh"],
                "ng": ["en-NG", "yo", "ha"],
                "za": ["en-ZA", "af", "zu"],
                "gh": ["en-GH"],
                "ke": ["en-KE", "sw"],
                "il": ["he-IL", "he", "ar", "en"],
                "cz": ["cs-CZ", "cs", "sk", "en"],
                "sk": ["sk-SK", "sk", "cs", "en"],
                "hu": ["hu-HU", "hu", "en"],
                "ro": ["ro-RO", "ro", "en"],
                "bg": ["bg-BG", "bg", "en"],
                "hr": ["hr-HR", "hr", "en"],
                "rs": ["sr-RS", "sr", "en"],
                "gr": ["el-GR", "el", "en"],
                "kz": ["kk-KZ", "kk", "ru"],
                "uz": ["uz-UZ", "uz", "ru"],
                "ge": ["ka-GE", "ka", "ru"],
                "az": ["az-AZ", "az", "ru"],
            }
            _langs = _COUNTRY_LANGUAGES.get(self.target_country, ["en-US", "en"])
            _lang_primary = _langs[0]
            _langs_json = json.dumps(_langs)
            try:
                ctx.add_init_script(f"""
                (() => {{
                    try {{
                        Object.defineProperty(navigator, 'language', {{
                            get: () => {json.dumps(_lang_primary)},
                            configurable: true, enumerable: true,
                        }});
                        Object.defineProperty(navigator, 'languages', {{
                            get: () => {_langs_json},
                            configurable: true, enumerable: true,
                        }});
                    }} catch (e) {{}}
                }})();
                """)
            except Exception as e:
                log.debug("[%s] Language injection failed: %s", self.session_id[:8], e)

            # ── Extra Accept-Language HTTP header matching country ─────────────
            # IMPORTANT: set_extra_http_headers() REPLACES existing headers.
            # Must merge with whatever was already set (e.g. Facebook Referer).
            try:
                _q_langs = ", ".join(
                    f"{l};q={round(1.0 - 0.1 * i, 1)}" if i > 0 else l
                    for i, l in enumerate(_langs[:4])
                )
                # Merge: start with any headers already set in context_opts
                _merged_headers = dict(context_opts.get("extra_http_headers", {}))
                # Only add Accept-Language if not already set
                if "Accept-Language" not in _merged_headers:
                    _merged_headers["Accept-Language"] = _q_langs
                    ctx.set_extra_http_headers(_merged_headers)
            except Exception:
                pass

        # Inject DOM document.referrer lock for Facebook App traffic
        if config.traffic.is_facebook_mode():
            try:
                fb_ref = config.traffic.get_referrer() or "https://l.facebook.com/"
                ctx.add_init_script(f"""
                (() => {{
                    try {{
                        const _ref = {json.dumps(fb_ref)};
                        try {{
                            Object.defineProperty(Document.prototype, 'referrer', {{
                                get: function() {{ return _ref; }},
                                configurable: true,
                                enumerable: true
                            }});
                        }} catch (e) {{}}
                        try {{
                            Object.defineProperty(document, 'referrer', {{
                                get: function() {{ return _ref; }},
                                configurable: true,
                                enumerable: true
                            }});
                        }} catch (e) {{}}
                    }} catch (e) {{}}
                }})();
                """)
            except Exception as e:
                log.warning("[%s] Failed to inject Facebook referrer script: %s", self.session_id[:8], e)

        # Ads are NEVER blocked — all requests are allowed through.
        return ctx

    # ------------------------------------------------------------------
    def open(self, existing_browser: Optional[Browser] = None) -> "IsolatedContext":
        if existing_browser and existing_browser.is_connected():
            self._browser = existing_browser
        else:
            self._browser = self._launch_browser()
        self._context = self._create_context()
        return self

    def new_page(self) -> Page:
        assert self._context is not None, "Context not opened"
        return self._context.new_page()

    def pages(self):
        assert self._context is not None
        return self._context.pages

    def close(self) -> None:
        """Gracefully close context; keep browser if cached for thread reuse."""
        try:
            if self._context:
                try:
                    self._context.clear_cookies()
                except Exception:
                    pass
                self._context.close()
        except Exception as exc:
            log.warning("[%s] Error closing context: %s", self.session_id[:8], exc)
        # Only close browser if NOT cached for thread reuse
        thread_browser = _get_thread_browser()
        if self._browser and self._browser is not thread_browser:
            try:
                self._browser.close()
            except Exception as exc:
                log.warning("[%s] Error closing browser: %s", self.session_id[:8], exc)
            _untrack_browser(self._browser)
        self._wipe_profile()

    def _wipe_profile(self) -> None:
        try:
            if self._tmp_dir.exists():
                shutil.rmtree(self._tmp_dir, ignore_errors=True)
                log.debug("[%s] Temp profile wiped: %s", self.session_id[:8], self._tmp_dir)
        except Exception as exc:
            log.warning("Profile wipe failed for %s: %s", self._tmp_dir, exc)

    # Context-manager support
    def __enter__(self) -> "IsolatedContext":
        return self.open()

    def __exit__(self, *_) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Global Browser & Process Registry (Prevents Zombie Processes & Memory Leaks)
# ---------------------------------------------------------------------------
_browser_local = threading.local()
_tracked_browsers: set[Browser] = set()
_tracked_pw: set[Playwright] = set()
_registry_lock = threading.Lock()


def _track_browser(b: Browser) -> None:
    if b:
        with _registry_lock:
            _tracked_browsers.add(b)


def _untrack_browser(b: Browser) -> None:
    if b:
        with _registry_lock:
            _tracked_browsers.discard(b)


def _track_pw(pw: Playwright) -> None:
    if pw:
        with _registry_lock:
            _tracked_pw.add(pw)


def _untrack_pw(pw: Playwright) -> None:
    if pw:
        with _registry_lock:
            _tracked_pw.discard(pw)


def _get_thread_browser() -> Optional[Browser]:
    return getattr(_browser_local, 'browser', None)


def _set_thread_browser(browser: Browser) -> None:
    _browser_local.browser = browser
    _track_browser(browser)


def discard_thread_browser() -> None:
    """Close the cached browser AND stop the playwright transport for this thread, ensuring no zombie OS processes or socket handles leak."""
    b = getattr(_browser_local, 'browser', None)
    if b:
        try:
            # Kill the actual underlying OS process tree if accessible
            try:
                import psutil
                # Playwright browser internal process handle
                proc = getattr(b, "_impl_obj", None)
                if proc and hasattr(proc, "_process"):
                    sub_proc = proc._process
                    if sub_proc and hasattr(sub_proc, "pid"):
                        parent = psutil.Process(sub_proc.pid)
                        for child in parent.children(recursive=True):
                            try:
                                child.kill()
                            except Exception:
                                pass
                        parent.kill()
            except Exception:
                pass
            b.close()
        except Exception:
            pass
        _untrack_browser(b)
        _browser_local.browser = None

    pw = getattr(_browser_local, 'pw', None)
    if pw:
        try:
            pw.stop()
        except Exception:
            pass
        _untrack_pw(pw)
        _browser_local.pw = None
    _browser_local.session_count = 0


def cleanup_all_browsers() -> None:
    """Closes all cached and active browser instances in parallel (instant stop)
    and stops playwright transports."""
    with _registry_lock:
        browsers_to_close = list(_tracked_browsers)
        _tracked_browsers.clear()
        pw_to_stop = list(_tracked_pw)
        _tracked_pw.clear()

    import threading as _th

    def _close_one(b):
        try:
            if b.is_connected():
                b.close()
        except Exception:
            pass

    _threads = []
    for b in browsers_to_close:
        t = _th.Thread(target=_close_one, args=(b,), daemon=True)
        t.start()
        _threads.append(t)
    for t in _threads:
        t.join(timeout=2.0)

    for pw in pw_to_stop:
        try:
            pw.stop()
        except Exception:
            pass

    _browser_local.browser = None
    _browser_local.pw = None
    _browser_local.session_count = 0


def cleanup_zombie_browsers() -> None:
    """Terminates any orphaned headless shell or browser processes leftover from previous interrupted sessions.
    Uses native in-memory Win32 process APIs (via psutil) for microsecond, non-blocking termination."""
    try:
        import psutil
        target_names = {
            'chrome-headless-shell',
            'headless_shell',
            'chromium',
            'chromium-browser',
            'chrome',
            'google-chrome',
            'firefox',
            'chrome-headless-shell.exe',
            'headless_shell.exe',
            'chromium.exe',
            'chrome.exe',
            'firefox.exe',
        }
        for p in psutil.process_iter(['name', 'cmdline']):
            try:
                name = (p.info.get('name') or '').lower()
                cmdline = " ".join(p.info.get('cmdline') or []).lower()
                # Only kill if it's explicitly running as automated / headless / test worker
                if name in target_names and any(k in cmdline for k in ('--headless', 'headless', 'playwright', '--remote-debugging-port')):
                    p.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    except Exception:
        pass

    # Clean old temporary profile folders leftover from crashed runs
    try:
        import shutil
        import time
        profiles_dir = getattr(config, "profiles_dir", None)
        if profiles_dir and profiles_dir.exists():
            now = time.time()
            for d in profiles_dir.glob("qa_*"):
                try:
                    if d.is_dir() and (now - d.stat().st_mtime) > 180:
                        shutil.rmtree(d, ignore_errors=True)
                except Exception:
                    pass
    except Exception:
        pass


atexit.register(cleanup_all_browsers)
atexit.register(cleanup_zombie_browsers)


# ---------------------------------------------------------------------------
# Factory helper
# ---------------------------------------------------------------------------
@contextmanager
def isolated_browser(session_id: Optional[str] = None) -> Generator[IsolatedContext, None, None]:
    """Yield an IsolatedContext; always tears down on exit.
    
    Reuses the same browser across sessions within the same thread,
    saving ~5-7 seconds per session (no browser launch overhead).
    Automatically recycles browser after 25 sessions to ensure memory remains lean.
    """
    sid = session_id or str(uuid.uuid4())
    # Use multi-pool manager when pools are configured, else standard proxy pool
    from app.proxy_manager import multi_pool_manager
    if multi_pool_manager.total_count > 0:
        proxy = multi_pool_manager.next_proxy()
    else:
        proxy = proxy_manager.next_proxy()

    # Reuse browser from this thread if available
    existing_browser = _get_thread_browser()
    
    # Recycle thread browser every 10 sessions to flush accumulated V8/GPU memory
    sc = getattr(_browser_local, 'session_count', 0) + 1
    _browser_local.session_count = sc
    if sc > 10 and existing_browser:
        discard_thread_browser()
        existing_browser = None
        _browser_local.session_count = 1

    if existing_browser and existing_browser.is_connected():
        # Reuse existing browser — only create new context (~1s)
        ctx = IsolatedContext(
            playwright=None, session_id=sid,
            browser_cfg=config.browser, proxy=proxy,
        )
        try:
            ctx.open(existing_browser=existing_browser)
        except Exception:
            ctx.close()
            discard_thread_browser()
            raise
        try:
            yield ctx
        finally:
            ctx.close()
    else:
        # First time (or after discard): launch fresh playwright + browser
        pw = sync_playwright().start()
        _browser_local.pw = pw          # ← cache so discard_thread_browser() can stop it
        _track_pw(pw)
        full = IsolatedContext(
            playwright=pw, session_id=sid,
            browser_cfg=config.browser, proxy=proxy,
        )
        try:
            full.open()
        except Exception:
            full.close()
            discard_thread_browser()
            raise
        _set_thread_browser(full._browser)
        try:
            yield full
        finally:
            full.close()
            # Don't stop Playwright — browser is cached for thread reuse.
            # discard_thread_browser() will stop it only when a proxy error forces a retry.
