# 🚀 MityTech Linux – High-Performance Multi-Worker Automation Suite

A high-performance, Linux-native, multi-worker web QA & shortlink automation engine reverse-engineered and optimized for **Ubuntu, Debian, and Linux VPS / Virtual Machines**.

---

## ⚡ Key Highlights & Enhancements

- **100% Linux Native**: All Windows DLLs, WMIC/Winreg registry calls, and DirectX dependencies removed.
- **Hardware Auto-Tuning**: Automatically inspects your VPS vCPUs and RAM (`/proc/cpuinfo`, `/proc/meminfo`) to safely allocate up to 100% of your VM's capacity.
- **24/7 Continuous Non-Stop Mode**: Automatically loops sessions indefinitely until you send `./ctl.sh stop`.
- **Live Terminal Control Center (`ctl.sh`)**: Change workers, reload proxy pools, update target links, or view live throughput without restarting.
- **Full Multi-Pool Proxy Support**: Multi-account failover for FloppyData, FlashProxy, or custom residential rotating proxies.
- **OUO.IO 2-Step Verified View Solver**: Automated Cloudflare Turnstile token bypass, `/go/` timer synchronization, reCAPTCHA v3 execution, and organic dwell.
- **Bandwidth Saver**: RAM-caches static Turnstile and reCAPTCHA assets to eliminate wasted proxy data.

---

## 📦 Quick Start on Ubuntu / Debian VPS

### 1. Copy or Upload to your VPS
Upload the `mitytech_linux` directory to your VPS (via SFTP, SCP, or Git):
```bash
scp -r mitytech_linux user@your-vps-ip:/home/user/
```

### 2. Run the 1-Click Installer
```bash
cd mitytech_linux
chmod +x setup_ubuntu.sh ctl.sh
./setup_ubuntu.sh
```
*This installs system dependencies, creates a Python virtual environment (`.venv`), installs Playwright Chromium, and verifies everything.*

---

## 🎮 Command Center Reference (`ctl.sh`)

| Command | Description |
| :--- | :--- |
| `./ctl.sh start` | Run in the foreground of your terminal (interactive, press Ctrl+C to stop). |
| `./ctl.sh start -d` | Launch in the background as a 24/7 daemon process. |
| `./ctl.sh stop` | Gracefully stop the running workers and save session reports. |
| `./ctl.sh restart` | Restart background daemon. |
| `./ctl.sh status` | View live metrics: active workers, throughput, passed/failed, uptime. |
| `./ctl.sh workers <N>` | Change worker concurrency dynamically (e.g., `./ctl.sh workers 40` or `./ctl.sh workers auto`). |
| `./ctl.sh proxy <file>` | Switch proxy file (e.g., `./ctl.sh proxy multi_proxies.txt` or `./ctl.sh proxy reload`). |
| `./ctl.sh urls <file>` | Update target URLs on the fly (e.g., `./ctl.sh urls urls.txt` or `./ctl.sh urls reload`). |
| `./ctl.sh logs` | Tail live real-time output logs (`tail -f logs/app.log`). |
| `./ctl.sh test-proxy` | Concurrently test latency and exit IPs of all configured proxies. |

---

## ⚙️ VPS Capacity Tuning Guide

MityTech auto-tunes worker count according to your hardware, but you can also manually specify `--workers N`:

| VPS Spec | RAM | Recommended Workers | Estimated Daily Sessions |
| :---: | :---: | :---: | :---: |
| 1 vCPU | 1 GB - 2 GB | 6 – 10 workers | ~8,000 – 12,000 |
| 2 vCPU | 4 GB | 18 – 25 workers | ~25,000 – 35,000 |
| 4 vCPU | 8 GB | 35 – 50 workers | ~50,000 – 75,000 |
| 8 vCPU | 16 GB | 60 – 100 workers | ~100,000 – 150,000 |
| 16+ vCPU | 32 GB+ | 100 – 180 workers | 200,000+ |

---

## 🔄 Running as a Background System Service (`systemd`)

For production setups that auto-restart on VPS reboot:

1. Create a service file:
```bash
sudo nano /etc/systemd/system/mitytech.service
```

2. Paste the following configuration (replace `/home/ubuntu/mitytech_linux` with your actual path):
```ini
[Unit]
Description=MityTech Automation Suite
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/mitytech_linux
ExecStart=/home/ubuntu/mitytech_linux/.venv/bin/python3 -m app.main --continuous --workers auto
Restart=always
RestartSec=5
StandardOutput=append:/home/ubuntu/mitytech_linux/logs/app.log
StandardError=append:/home/ubuntu/mitytech_linux/logs/app.log

[Install]
WantedBy=multi-user.target
```

3. Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable mitytech
sudo systemctl start mitytech
sudo systemctl status mitytech
```

---

## 📊 Live Web Dashboard

MityTech includes a lightweight local dashboard accessible from any web browser:
```
http://<YOUR-VPS-IP>:8765/
```
Shows real-time session progress, latency distribution, and passed/failed ratios.
