import sys
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
#!/usr/bin/env python3
"""
ctl.py – Universal CLI Control Center for MityTech Linux.

Commands:
    start       – Start the bot (runs in foreground or with --daemon)
    stop        – Safely stop the running bot process
    status      – Show real-time performance, active workers, passed/failed stats
    workers <N> – Dynamically change worker concurrency on the fly (1-200 or 'auto')
    proxy <path>– Switch or reload proxy list / multi-pool configurations
    urls <path> – Reload or update target URLs on the fly
    logs        – View live application output logs
    test-proxy  – Concurrently test all configured proxies
"""

import argparse
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request, urlopen

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))
LOGS_DIR = BASE_DIR / "logs"
PID_FILE = LOGS_DIR / "app.pid"
STATUS_FILE = LOGS_DIR / "live_status.json"
APP_LOG = LOGS_DIR / "app.log"
IPC_PORT = 8766


def _send_ipc(path: str, method: str = "GET", data: dict = None) -> dict:
    url = f"http://127.0.0.1:{IPC_PORT}{path}"
    req = Request(url, headers={"User-Agent": "MityTech-CTL"}, method=method)
    if data:
        body = json.dumps(data).encode("utf-8")
        req.add_header("Content-Type", "application/json")
        req.data = body

    try:
        with urlopen(req, timeout=3.0) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return {"error": str(e)}


def _get_running_pid() -> int | None:
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text(encoding="utf-8").strip())
            # Check if process is alive
            if sys.platform != "win32":
                os.kill(pid, 0)
            return pid
        except (ValueError, OSError):
            return None
    return None


def cmd_start(args):
    pid = _get_running_pid()
    if pid:
        print(f"⚠️ MityTech is already running with PID {pid}.")
        print("Run './ctl.sh status' or './ctl.sh stop'")
        return

    cmd = [sys.executable, "-m", "app.main"]
    if args.workers:
        cmd.extend(["--workers", str(args.workers)])
    if args.sessions is not None:
        cmd.extend(["--sessions", str(args.sessions)])
    if args.continuous:
        cmd.append("--continuous")
    if args.proxy_file:
        cmd.extend(["--proxy-file", args.proxy_file])
    if args.urls_file:
        cmd.extend(["--urls-file", args.urls_file])
    if args.duration:
        cmd.extend(["--duration", str(args.duration)])

    if args.daemon:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        log_fp = open(APP_LOG, "a", encoding="utf-8")
        print("🚀 Starting MityTech Linux in background daemon mode...")
        proc = subprocess.Popen(
            cmd,
            cwd=str(BASE_DIR),
            stdout=log_fp,
            stderr=log_fp,
            start_new_session=True if sys.platform != "win32" else False,
        )
        time.sleep(1.5)
        print(f"✅ Daemon started with PID {proc.pid}")
        print(f"📋 Live logs: tail -f logs/app.log  (or run './ctl.sh logs')")
        print(f"📊 Web Dashboard: http://localhost:8765/")
    else:
        print("🚀 Starting MityTech Linux in foreground (Press Ctrl+C to stop)...")
        try:
            subprocess.run(cmd, cwd=str(BASE_DIR))
        except KeyboardInterrupt:
            pass


def cmd_stop(args):
    print("🛑 Requesting graceful stop...")
    # 1. Try IPC stop first
    res = _send_ipc("/api/stop", method="POST")
    if "error" not in res:
        print("✅ Graceful stop signal delivered via IPC.")
    else:
        # Fallback to SIGINT / SIGTERM on PID
        pid = _get_running_pid()
        if pid:
            try:
                sig = signal.SIGINT if sys.platform != "win32" else signal.SIGTERM
                os.kill(pid, sig)
                print(f"✅ Sent shutdown signal to PID {pid}.")
            except Exception as e:
                print(f"Failed to signal PID {pid}: {e}")
        else:
            print("No active MityTech process found.")


def cmd_status(args):
    res = _send_ipc("/api/status")
    if "error" not in res:
        print("\n" + "=" * 55)
        print("  📊 MITYTECH LINUX ENGINE – LIVE STATUS")
        print("=" * 55)
        print(f"  Status        : 🟢 {res.get('status', 'RUNNING')}")
        print(f"  PID           : {res.get('pid')}")
        print(f"  Uptime        : {res.get('uptime_s', 0)} seconds")
        print(f"  Active Workers: {res.get('workers_active')} / {res.get('workers_configured')} configured")
        print(f"  Sessions Done : {res.get('completed')} total ({res.get('passed')} passed, {res.get('failed')} failed)")
        print(f"  Pass Rate     : {res.get('pass_rate_pct')}%")
        print(f"  Active Pool   : {res.get('active_pool')}")
        print(f"  Loaded Proxies: {res.get('proxies_count')}")
        print(f"  Target URLs   : {res.get('urls_count')}")
        print("=" * 55 + "\n")
        return

    # Fallback to reading live_status.json
    if STATUS_FILE.exists():
        try:
            d = json.loads(STATUS_FILE.read_text(encoding="utf-8"))
            print("\n" + "=" * 55)
            print("  📊 MITYTECH STATUS (Cached)")
            print("=" * 55)
            print(f"  Active Workers: {d.get('active_workers')} / {d.get('configured_workers')}")
            print(f"  Completed     : {d.get('completed')} ({d.get('passed')} passed, {d.get('failed')} failed)")
            print(f"  Throughput    : {d.get('sessions_per_min')} sessions/min")
            print("=" * 55 + "\n")
            return
        except Exception:
            pass

    pid = _get_running_pid()
    if pid:
        print(f"MityTech is running (PID {pid}), but IPC is still initializing.")
    else:
        print("⚪ MityTech is not currently running. Use './ctl.sh start --daemon'")


def cmd_workers(args):
    val = args.count
    res = _send_ipc(f"/api/workers?n={val}", method="POST")
    if "error" not in res:
        print(f"✅ Concurrency updated: Active workers set to {res.get('workers')}")
    else:
        print(f"❌ Failed to update workers: {res.get('error')}")


def cmd_proxy(args):
    if args.action == "reload":
        res = _send_ipc("/api/reload-proxies", method="POST")
        if "error" not in res:
            print(f"✅ Proxies reloaded! Total active: {res.get('proxies_reloaded')}")
        else:
            print(f"❌ Reload failed: {res.get('error')}")
    elif args.action:
        # User passed a file path
        p = Path(args.action)
        if p.exists():
            print(f"Updating proxy file to: {p.resolve()}")
            # Can restart or copy to multi_proxies.txt
            import shutil
            shutil.copyfile(p, BASE_DIR / "multi_proxies.txt")
            _send_ipc("/api/reload-proxies", method="POST")
            print("✅ Copied to multi_proxies.txt and reloaded live pools.")
        else:
            print(f"❌ File not found: {args.action}")


def cmd_urls(args):
    if args.action == "reload":
        res = _send_ipc("/api/reload-urls", method="POST")
        if "error" not in res:
            print(f"✅ URLs reloaded! Count: {res.get('urls_count')}")
        else:
            print(f"❌ Reload failed: {res.get('error')}")
    elif args.action:
        p = Path(args.action)
        if p.exists():
            import shutil
            shutil.copyfile(p, BASE_DIR / "urls.txt")
            _send_ipc("/api/reload-urls", method="POST")
            print(f"✅ Copied {p.name} to urls.txt and reloaded targets.")
        else:
            print(f"❌ File not found: {args.action}")


def cmd_logs(args):
    if not APP_LOG.exists():
        print("No log file found at logs/app.log yet.")
        return
    if sys.platform != "win32":
        subprocess.run(["tail", "-f", str(APP_LOG)])
    else:
        try:
            with open(APP_LOG, "r", encoding="utf-8", errors="ignore") as f:
                f.seek(max(0, APP_LOG.stat().st_size - 4000))
                print(f.read())
        except KeyboardInterrupt:
            pass


def cmd_test_proxy(args):
    from app.config import config
    from app.proxy_manager import multi_pool_manager, proxy_manager
    from app.universal_proxy import verify_proxy_pool, parse_proxy_line

    print("🔍 Testing configured proxy pools...")
    proxies = []
    if multi_pool_manager.total_count > 0:
        for pool in multi_pool_manager._pools:
            for p in pool.proxies:
                parsed = parse_proxy_line(p.url)
                if parsed:
                    proxies.append(parsed)
    else:
        for p in proxy_manager.proxies:
            parsed = parse_proxy_line(p.url)
            if parsed:
                proxies.append(parsed)

    if not proxies:
        print("No proxies loaded to test.")
        return

    print(f"Testing {len(proxies)} proxies across pools (timeout=5s)...")
    working, dead = verify_proxy_pool(proxies, max_workers=10, timeout_s=5.0)
    print(f"\nResults: ✅ {len(working)} working | ❌ {len(dead)} failed")
    for w in working[:5]:
        print(f"  • {w.host}:{w.port} -> Exit IP: {w.exit_ip} (Latency: {w.latency_ms}ms)")


def main():
    p = argparse.ArgumentParser(description="MityTech Control Center")
    sub = p.add_subparsers(dest="cmd", required=True)

    # start
    p_start = sub.add_parser("start", help="Start the automation engine")
    p_start.add_argument("--daemon", "-d", action="store_true", help="Run in background as daemon")
    p_start.add_argument("--workers", "-w", type=str, default=None, help="Workers count or 'auto'")
    p_start.add_argument("--sessions", "-s", type=int, default=None, help="Max sessions (0 = continuous)")
    p_start.add_argument("--continuous", "-c", action="store_true", default=True, help="Continuous non-stop mode")
    p_start.add_argument("--duration", type=int, default=None, help="Duration in minutes (0 = infinite)")
    p_start.add_argument("--proxy-file", type=str, default=None, help="Proxy list path")
    p_start.add_argument("--urls-file", type=str, default=None, help="Target URLs path")

    # stop
    sub.add_parser("stop", help="Stop running engine")

    # status
    sub.add_parser("status", help="Show live status and metrics")

    # workers
    p_workers = sub.add_parser("workers", help="Change worker concurrency on the fly")
    p_workers.add_argument("count", type=str, help="Number of workers (e.g. 40) or 'auto'")

    # proxy
    p_proxy = sub.add_parser("proxy", help="Reload or change proxies")
    p_proxy.add_argument("action", nargs="?", default="reload", help="File path or 'reload'")

    # urls
    p_urls = sub.add_parser("urls", help="Reload or change target URLs")
    p_urls.add_argument("action", nargs="?", default="reload", help="File path or 'reload'")

    # logs
    sub.add_parser("logs", help="Tail live application logs")

    # test-proxy
    sub.add_parser("test-proxy", help="Test live proxy latency and connection")

    args = p.parse_args()

    handlers = {
        "start": cmd_start,
        "stop": cmd_stop,
        "status": cmd_status,
        "workers": cmd_workers,
        "proxy": cmd_proxy,
        "urls": cmd_urls,
        "logs": cmd_logs,
        "test-proxy": cmd_test_proxy,
    }
    handlers[args.cmd](args)


if __name__ == "__main__":
    main()
